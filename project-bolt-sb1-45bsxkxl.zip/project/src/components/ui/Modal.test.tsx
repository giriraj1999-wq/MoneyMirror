import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import Modal from '@/components/ui/Modal'

describe('Modal', () => {
  it('renders title and children when open', () => {
    render(
      <Modal open={true} onClose={() => {}} title="Test Modal">
        <p>Modal content here</p>
      </Modal>
    )
    expect(screen.getByText('Test Modal')).toBeInTheDocument()
    expect(screen.getByText('Modal content here')).toBeInTheDocument()
  })

  it('does not render content when closed', () => {
    render(
      <Modal open={false} onClose={() => {}} title="Hidden Modal">
        <p>Should not appear</p>
      </Modal>
    )
    expect(screen.queryByText('Hidden Modal')).not.toBeInTheDocument()
    expect(screen.queryByText('Should not appear')).not.toBeInTheDocument()
  })

  it('calls onClose when close button is clicked', async () => {
    const onClose = vi.fn()
    const { container } = render(
      <Modal open={true} onClose={onClose} title="Closable">
        <p>Content</p>
      </Modal>
    )
    // Find the close button (X icon button)
    const buttons = container.querySelectorAll('button')
    // The close button should be the one with an SVG or aria-label
    const closeBtn = Array.from(buttons).find((b) => b.getAttribute('aria-label') === 'Close' || b.textContent === '')
    if (closeBtn) {
      closeBtn.click()
      expect(onClose).toHaveBeenCalled()
    }
  })
})
