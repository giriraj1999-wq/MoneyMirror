import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { CURRENCIES, type CurrencyCode } from '@/lib/format';

interface CurrencyPickerProps {
  currency: CurrencyCode;
  onChange: (code: CurrencyCode) => void;
}

export default function CurrencyPicker({ currency, onChange }: CurrencyPickerProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const current = CURRENCIES.find((c) => c.code === currency) ?? CURRENCIES[0];

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex h-9 items-center gap-1.5 rounded-lg px-2.5 text-sm font-semibold text-slate-600 transition-colors hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
        title="Display currency"
      >
        <span className="text-base leading-none">{current.symbol}</span>
        <span className="hidden sm:inline">{current.code}</span>
        <ChevronDown size={15} className="text-slate-400" />
      </button>

      {open && (
        <div className="absolute right-0 top-full z-50 mt-1 w-48 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg dark:border-slate-700 dark:bg-slate-900">
          <div className="border-b border-slate-100 px-3 py-2 dark:border-slate-800">
            <p className="text-xs font-bold text-slate-400 dark:text-slate-500">
              DISPLAY CURRENCY
            </p>
          </div>
          <div className="max-h-64 overflow-y-auto py-1">
            {CURRENCIES.map((c) => (
              <button
                key={c.code}
                onClick={() => {
                  onChange(c.code as CurrencyCode);
                  setOpen(false);
                }}
                className={`flex w-full items-center justify-between px-3 py-2 text-left text-sm transition-colors hover:bg-slate-50 dark:hover:bg-slate-800 ${
                  c.code === currency
                    ? 'font-bold text-blue-600 dark:text-blue-400'
                    : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                <span className="flex items-center gap-2">
                  <span className="w-6 text-center text-sm">{c.symbol}</span>
                  <span>{c.code}</span>
                </span>
                <span className="flex items-center gap-2">
                  <span className="hidden text-xs text-slate-400 sm:inline">{c.label}</span>
                  {c.code === currency && <Check size={15} />}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
