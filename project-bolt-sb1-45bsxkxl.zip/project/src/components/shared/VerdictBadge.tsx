import { CheckCircle2, AlertTriangle, AlertCircle } from 'lucide-react';

interface VerdictBadgeProps {
  verdict: 'PLAN HOLDS' | 'SHORTFALL' | 'WARNING';
  size?: 'sm' | 'lg';
}

export default function VerdictBadge({ verdict, size = 'sm' }: VerdictBadgeProps) {
  const isHold = verdict === 'PLAN HOLDS';
  const isWarning = verdict === 'WARNING';
  const Icon = isHold ? CheckCircle2 : isWarning ? AlertCircle : AlertTriangle;
  const sizeClass = size === 'lg' ? 'px-4 py-2 text-base' : 'px-2.5 py-1 text-xs';
  const badgeClass = isHold ? 'badge-green' : isWarning ? 'badge-amber' : 'badge-red';
  const label = isHold ? 'Plan Holds' : isWarning ? 'Warning' : 'Shortfall';

  return (
    <span
      className={`badge ${badgeClass} ${sizeClass}`}
    >
      <Icon size={size === 'lg' ? 20 : 14} />
      {label}
    </span>
  );
}
