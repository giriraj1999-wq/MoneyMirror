type LogoProps = {
  size?: number;
  className?: string;
};

export function LogoMark({ size = 36, className }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="mm-grad" x1="6" y1="6" x2="42" y2="42" gradientUnits="userSpaceOnUse">
          <stop stopColor="#0EA5E9" />
          <stop offset="0.55" stopColor="#2563EB" />
          <stop offset="1" stopColor="#1E1B4B" />
        </linearGradient>
        <linearGradient id="mm-shine" x1="14" y1="10" x2="26" y2="28" gradientUnits="userSpaceOnUse">
          <stop stopColor="#fff" stopOpacity="0.35" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>

      <rect x="3" y="3" width="42" height="42" rx="13" fill="url(#mm-grad)" />
      <rect x="3" y="3" width="42" height="42" rx="13" fill="url(#mm-shine)" />

      <path
        d="M14 33V18.5L20 26L26 18.5V33"
        stroke="#fff"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M30 33V18.5L36 26"
        stroke="#fff"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity="0.7"
      />
      <circle cx="36" cy="31" r="2" fill="#38BDF8" />
    </svg>
  );
}

export function LogoFull({ size = 36, className }: LogoProps) {
  return (
    <div className={`flex items-center gap-2.5 ${className ?? ''}`}>
      <LogoMark size={size} />
      <div className="leading-none">
        <p className="text-base font-extrabold tracking-tight text-slate-900">
          Money<span className="text-blue-600">Mirror</span>
        </p>
        <p className="text-[11px] font-medium text-slate-400">Plan. Track. Decide.</p>
      </div>
    </div>
  );
}
