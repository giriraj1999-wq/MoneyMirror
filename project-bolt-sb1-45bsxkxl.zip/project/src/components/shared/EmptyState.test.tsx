import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import EmptyState from '@/components/shared/EmptyState'

describe('EmptyState', () => {
  it('renders title and description', () => {
    render(<EmptyState title="No data" description="There's nothing here yet." />)
    expect(screen.getByText('No data')).toBeInTheDocument()
    expect(screen.getByText("There's nothing here yet.")).toBeInTheDocument()
  })

  it('renders action when provided', () => {
    render(
      <EmptyState
        title="No transactions"
        description="Add one to get started."
        action={<button>Add Transaction</button>}
      />
    )
    expect(screen.getByText('Add Transaction')).toBeInTheDocument()
  })

  it('renders without action when not provided', () => {
    render(<EmptyState title="Empty" description="Nothing here." />)
    expect(screen.queryByText('Add Transaction')).not.toBeInTheDocument()
  })
})
