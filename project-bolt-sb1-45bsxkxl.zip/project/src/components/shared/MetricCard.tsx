import type { ReactNode } from 'react';

interface MetricCardProps {
  label: string;
  value: string;
  subtext?: string;
  variant?: 'default' | 'hero' | 'warning' | 'danger';
  icon?: ReactNode;
}

export default function MetricCard({
  label,
  value,
  subtext,
  variant = 'default',
  icon,
}: MetricCardProps) {
  const styles = {
    default: 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900',
    hero: 'border-blue-200 dark:border-blue-800 bg-gradient-to-br from-blue-50 to-white dark:from-blue-950 dark:to-slate-900',
    warning: 'border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950',
    danger: 'border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950',
  };

  const valueColor = {
    default: 'text-slate-900 dark:text-slate-100',
    hero: 'text-blue-900 dark:text-blue-100',
    warning: 'text-amber-900 dark:text-amber-100',
    danger: 'text-red-900 dark:text-red-100',
  };

  return (
    <div className={`card card-hover p-5 ${styles[variant]}`}>
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</p>
        {icon && <span className="text-slate-400 dark:text-slate-500">{icon}</span>}
      </div>
      <p
        className={`mt-2 text-2xl font-bold tracking-tight ${
          valueColor[variant]
        }`}
      >
        {value}
      </p>
      {subtext && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{subtext}</p>}
    </div>
  );
}
