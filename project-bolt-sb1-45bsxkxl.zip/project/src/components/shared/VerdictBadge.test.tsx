import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import VerdictBadge from '@/components/shared/VerdictBadge'

describe('VerdictBadge', () => {
  it('renders "Plan Holds" for PLAN HOLDS verdict', () => {
    render(<VerdictBadge verdict="PLAN HOLDS" />)
    expect(screen.getByText('Plan Holds')).toBeInTheDocument()
  })

  it('renders "Shortfall" for SHORTFALL verdict', () => {
    render(<VerdictBadge verdict="SHORTFALL" />)
    expect(screen.getByText('Shortfall')).toBeInTheDocument()
  })

  it('applies badge-green class for PLAN HOLDS', () => {
    const { container } = render(<VerdictBadge verdict="PLAN HOLDS" />)
    const badge = container.querySelector('.badge')
    expect(badge?.classList.contains('badge-green')).toBe(true)
  })

  it('applies badge-red class for SHORTFALL', () => {
    const { container } = render(<VerdictBadge verdict="SHORTFALL" />)
    const badge = container.querySelector('.badge')
    expect(badge?.classList.contains('badge-red')).toBe(true)
  })

  it('renders "Warning" for WARNING verdict', () => {
    render(<VerdictBadge verdict="WARNING" />)
    expect(screen.getByText('Warning')).toBeInTheDocument()
  })

  it('applies badge-amber class for WARNING', () => {
    const { container } = render(<VerdictBadge verdict="WARNING" />)
    const badge = container.querySelector('.badge')
    expect(badge?.classList.contains('badge-amber')).toBe(true)
  })

  it('supports large size', () => {
    const { container } = render(<VerdictBadge verdict="PLAN HOLDS" size="lg" />)
    const badge = container.querySelector('.badge')
    expect(badge?.classList.contains('px-4')).toBe(true)
    expect(badge?.classList.contains('py-2')).toBe(true)
  })

  it('supports small size (default)', () => {
    const { container } = render(<VerdictBadge verdict="PLAN HOLDS" />)
    const badge = container.querySelector('.badge')
    expect(badge?.classList.contains('px-2.5')).toBe(true)
    expect(badge?.classList.contains('py-1')).toBe(true)
  })
})
