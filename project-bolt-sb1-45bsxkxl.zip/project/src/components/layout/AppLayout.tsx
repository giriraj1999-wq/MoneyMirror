import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  CalendarRange,
  ArrowLeftRight,
  CalendarClock,
  SlidersHorizontal,
  LogOut,
  Users,
  Target,
  CalendarDays,
} from 'lucide-react';
import { LogoMark } from '@/components/shared/Logo';
import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useTheme } from '@/hooks/useTheme';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import CurrencyPicker from '@/components/shared/CurrencyPicker';
import NotificationBell from '@/components/shared/NotificationBell';

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/plan', label: 'Plan', icon: CalendarRange },
  { to: '/transactions', label: 'Transactions', icon: ArrowLeftRight },
  { to: '/commitments', label: 'Commitments', icon: CalendarClock },
  { to: '/goals', label: 'Goals', icon: Target },
  { to: '/shared', label: 'Shared Expenses', icon: Users },
  { to: '/simulator', label: 'Simulator', icon: SlidersHorizontal },
  { to: '/yearly-plan', label: 'Yearly Plan', icon: CalendarDays },
];

function UserMenu() {
  const { session, signOut } = useAuth();
  const [open, setOpen] = useState(false);

  const email = session?.user?.email ?? '';
  const displayName = email.split('@')[0] || 'User';
  const initials = displayName
    .split(/[.\-_]/)
    .filter(Boolean)
    .slice(0, 2)
    .map((s) => s[0]?.toUpperCase())
    .join('') || 'U';

  const handleSignOut = async () => {
    setOpen(false);
    await signOut();
  };

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 transition-colors hover:bg-slate-100"
      >
        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">
          {initials}
        </div>
        <span className="hidden text-sm font-medium text-slate-700 sm:block">
          {displayName}
        </span>
      </button>
      {open && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setOpen(false)}
          />
          <div className="absolute right-0 top-full z-50 mt-1 w-56 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
            <div className="border-b border-slate-100 px-4 py-3">
              <p className="truncate text-sm font-semibold text-slate-900">
                {displayName}
              </p>
              <p className="truncate text-xs text-slate-500">{email}</p>
            </div>
            <button
              onMouseDown={(e) => {
                e.preventDefault();
                handleSignOut();
              }}
              className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50"
            >
              <LogOut size={16} className="text-slate-500" />
              Sign Out
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default function AppLayout({ children }: { children: React.ReactNode }) {
  useTheme();
  const location = useLocation();
  const { currency, changeCurrency } = useDisplayCurrency();

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950">
      <aside className="hidden w-64 flex-col border-r border-slate-200 bg-white md:flex dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <LogoMark size={36} />
          <div>
            <p className="text-base font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              Money<span className="text-blue-600">Mirror</span>
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-500">Plan. Track. Decide.</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 px-3 py-4">
          {navItems.map((item) => {
            const isActive =
              item.to === '/'
                ? location.pathname === '/'
                : location.pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`nav-link ${isActive ? 'nav-link-active' : ''}`}
              >
                <Icon className="h-4.5 w-4.5 shrink-0" size={18} />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>

      <div className="flex flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-5 py-3 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-2 md:hidden">
            <LogoMark size={28} />
            <span className="font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              Money<span className="text-blue-600">Mirror</span>
            </span>
          </div>
          <div className="hidden md:block" />
          <div className="flex items-center gap-1">
            <CurrencyPicker currency={currency} onChange={changeCurrency} />
            <NotificationBell />
            <UserMenu />
          </div>
        </header>

        <div className="flex gap-2 overflow-x-auto border-b border-slate-200 bg-white px-3 py-2 md:hidden dark:border-slate-800 dark:bg-slate-900">
          {navItems.map((item) => {
            const isActive =
              item.to === '/'
                ? location.pathname === '/'
                : location.pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                }`}
              >
                <Icon size={16} />
                {item.label}
              </Link>
            );
          })}
        </div>

        <main className="flex-1 overflow-y-auto p-5 md:p-8">{children}</main>
      </div>
    </div>
  );
}
