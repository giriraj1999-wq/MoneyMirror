import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/layout/AppLayout';
import Auth from '@/pages/Auth';
import Dashboard from '@/pages/Dashboard';
import PlanMonth from '@/pages/PlanMonth';
import Transactions from '@/pages/Transactions';
import Commitments from '@/pages/Commitments';
import Simulator from '@/pages/Simulator';
import Shared from '@/pages/Shared';
import Goals from '@/pages/Goals';
import YearlyPlan from '@/pages/YearlyPlan';

function ProtectedRoutes() {
  const { session, loading, connectionError, retry } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-200 border-t-blue-600" />
          <div className="text-sm text-slate-500">Loading MoneyMirror...</div>
        </div>
      </div>
    );
  }

  if (connectionError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
        <div className="w-full max-w-md text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-red-100">
            <svg className="h-7 w-7 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold text-slate-900">Can't reach the server</h1>
          <p className="mt-2 text-sm text-slate-500">
            The app couldn't connect to its database. This is often caused by an
            ad blocker or network restriction blocking the connection. Try
            disabling ad blockers for this site, then retry.
          </p>
          <button onClick={retry} className="btn btn-primary mt-6">
            Retry connection
          </button>
        </div>
      </div>
    );
  }

  if (!session) {
    return <Auth />;
  }

  // If the user just arrived from an invite email link and is now
  // authenticated, send them to the Shared Expenses page instead of the
  // dashboard so the invite flow feels complete.
  const params = new URLSearchParams(
    location.search || location.hash.replace('#', '?')
  );
  const type = params.get('type');
  if (type === 'invite') {
    return <Navigate to="/shared" replace />;
  }

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/plan" element={<PlanMonth />} />
        <Route path="/transactions" element={<Transactions />} />
        <Route path="/commitments" element={<Commitments />} />
        <Route path="/simulator" element={<Simulator />} />
        <Route path="/shared" element={<Shared />} />
        <Route path="/goals" element={<Goals />} />
        <Route path="/yearly-plan" element={<YearlyPlan />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <ProtectedRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
