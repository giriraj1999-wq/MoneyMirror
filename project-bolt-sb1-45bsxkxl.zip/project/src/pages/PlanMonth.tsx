import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useMonthData } from '@/hooks/useMonthData';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { formatCurrency, getCurrencySymbol } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import { CheckCircle2, Plus, Trash2, Zap, Save, ShieldCheck, Wallet, Lock } from 'lucide-react';
import MonthlyReview from '@/pages/MonthlyReview';

type PlanTab = 'plan' | 'monthly';

const planTabs: { id: PlanTab; label: string; icon: typeof Wallet }[] = [
  { id: 'plan', label: 'Plan My Month', icon: Wallet },
  { id: 'monthly', label: 'Monthly Review', icon: Zap },
];

export default function PlanMonth() {
  const location = useLocation();
  const scenarioApplied = (location.state as { scenarioApplied?: boolean } | null)?.scenarioApplied ?? false;
  const [showToast, setShowToast] = useState(scenarioApplied);

  useEffect(() => {
    if (!scenarioApplied) return;
    const timer = setTimeout(() => setShowToast(false), 4000);
    return () => clearTimeout(timer);
  }, [scenarioApplied]);

  const {
    month,
    loading,
    plan,
    categories,
    budgets,
    transactions,
    refetch,
    ensurePlan,
    setPlan,
    setBudgets,
    setCategories,
  } = useMonthData();
  const { session } = useAuth();
  const { currency } = useDisplayCurrency();
  const currencySymbol = getCurrencySymbol(currency);

  const [activeTab, setActiveTab] = useState<PlanTab>('plan');
  const [planForm, setPlanForm] = useState({ opening_balance: '', expected_income: '', protected_savings: '' });
  const [savingPlan, setSavingPlan] = useState(false);
  const [planError, setPlanError] = useState<string | null>(null);
  const [planSaved, setPlanSaved] = useState(false);
  const [newCategory, setNewCategory] = useState({ name: '', type: 'expense' as 'expense' | 'income', is_essential: false, is_fixed: false });
  const [savingCategory, setSavingCategory] = useState(false);
  const [budgetEdits, setBudgetEdits] = useState<Record<string, string>>({});
  const [savingBudgets, setSavingBudgets] = useState(false);
  const [budgetError, setBudgetError] = useState<string | null>(null);
  const [budgetsSaved, setBudgetsSaved] = useState(false);
  const [deleteCatTarget, setDeleteCatTarget] = useState<string | null>(null);
  const [creatingPlan, setCreatingPlan] = useState(false);
  const [categoryError, setCategoryError] = useState<string | null>(null);

  useEffect(() => {
    if (plan) {
      setPlanForm({
        opening_balance: String(plan.opening_balance ?? 0),
        expected_income: String(plan.expected_income ?? 0),
        protected_savings: String(plan.protected_savings ?? 0),
      });
    }
  }, [plan]);

  useEffect(() => {
    if (loading || plan || creatingPlan || activeTab !== 'plan') return;
    let active = true;
    setCreatingPlan(true);
    ensurePlan()
      .then(async () => {
        if (!active) return;
        await refetch();
      })
      .catch((err) => {
        if (!active) return;
        setPlanError(err instanceof Error ? err.message : 'Failed to create plan');
      })
      .finally(() => {
        if (active) setCreatingPlan(false);
      });
    return () => { active = false; };
  }, [loading, plan, creatingPlan, activeTab, ensurePlan, refetch]);

  useEffect(() => {
    const edits: Record<string, string> = {};
    for (const b of budgets) {
      edits[b.category_id] = String(b.planned_amount);
    }
    setBudgetEdits(edits);
  }, [budgets]);

  const handleSavePlan = async () => {
    if (!plan) return;
    setSavingPlan(true);
    setPlanError(null);
    setPlanSaved(false);
    try {
      const { data, error } = await supabase
        .from('plans')
        .update({
          opening_balance: Number(planForm.opening_balance) || 0,
          expected_income: Number(planForm.expected_income) || 0,
          protected_savings: Number(planForm.protected_savings) || 0,
          updated_at: new Date().toISOString(),
        })
        .eq('id', plan.id)
        .select('*')
        .maybeSingle();
      if (error) throw error;
      if (data) setPlan(data as typeof plan);
      setPlanSaved(true);
      setTimeout(() => setPlanSaved(false), 2500);
    } catch (err) {
      setPlanError(err instanceof Error ? err.message : 'Failed to save plan');
    } finally {
      setSavingPlan(false);
    }
  };

  const handleAddCategory = async () => {
    if (!session?.user || !newCategory.name.trim()) return;
    setSavingCategory(true);
    setCategoryError(null);
    try {
      const { data, error } = await supabase
        .from('categories')
        .insert({
          user_id: session.user.id,
          name: newCategory.name.trim(),
          is_essential: newCategory.is_essential,
          is_fixed: newCategory.type === 'expense' ? newCategory.is_fixed : false,
          type: newCategory.type,
        })
        .select('*')
        .maybeSingle();
      if (error) throw error;
      if (!data) throw new Error('Failed to create category');
      setCategories([...categories, data as typeof categories[number]]);
      setNewCategory({ name: '', type: 'expense', is_essential: false, is_fixed: false });
    } catch (err) {
      const msg = err instanceof Error
        ? err.message
        : (err as any)?.message ?? 'Failed to add category';
      setCategoryError(msg);
    } finally {
      setSavingCategory(false);
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    setDeleteCatTarget(null);
    setCategoryError(null);
    try {
      const { error } = await supabase.from('categories').delete().eq('id', catId);
      if (error) throw error;
      setCategories(categories.filter((c) => c.id !== catId));
    } catch (err) {
      const msg = err instanceof Error
        ? err.message
        : (err as any)?.message ?? 'Failed to delete category';
      setCategoryError(msg);
    }
  };

  const handleToggleEssential = async (catId: string, current: boolean) => {
    setCategoryError(null);
    try {
      const { error } = await supabase
        .from('categories')
        .update({ is_essential: !current })
        .eq('id', catId);
      if (error) throw error;
      setCategories(categories.map((c) => (c.id === catId ? { ...c, is_essential: !current } : c)));
    } catch (err) {
      const msg = err instanceof Error
        ? err.message
        : (err as any)?.message ?? 'Failed to update category';
      setCategoryError(msg);
    }
  };

  const handleToggleFixed = async (catId: string, current: boolean) => {
    setCategoryError(null);
    try {
      const { error } = await supabase
        .from('categories')
        .update({ is_fixed: !current })
        .eq('id', catId);
      if (error) throw error;
      setCategories(categories.map((c) => (c.id === catId ? { ...c, is_fixed: !current } : c)));
    } catch (err) {
      const msg = err instanceof Error
        ? err.message
        : (err as any)?.message ?? 'Failed to update category';
      setCategoryError(msg);
    }
  };

  const handleSaveBudgets = async () => {
    if (!plan) return;
    setSavingBudgets(true);
    setBudgetError(null);
    setBudgetsSaved(false);
    try {
      const upserts = categories
        .filter((c) => c.type === 'expense')
        .map((c) => {
          const existing = budgets.find((b) => b.category_id === c.id);
          const amount = Number(budgetEdits[c.id] ?? 0) || 0;
          if (existing) {
            return supabase.from('budgets').update({ planned_amount: amount }).eq('id', existing.id);
          }
          return supabase.from('budgets').insert({
            plan_id: plan.id,
            category_id: c.id,
            planned_amount: amount,
          });
        });
      const results = await Promise.all(upserts);
      for (const r of results) {
        if (r.error) throw r.error;
      }
      await refetch();
      setBudgetsSaved(true);
      setTimeout(() => setBudgetsSaved(false), 2500);
    } catch (err) {
      setBudgetError(err instanceof Error ? err.message : 'Failed to save budgets');
    } finally {
      setSavingBudgets(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl space-y-6">
      <div className="grid grid-cols-2 gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-sm dark:border-slate-800 dark:bg-slate-900">
        {planTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all sm:text-sm ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
              }`}
              aria-pressed={isActive}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {activeTab === 'plan' && plan && (
        <div className="space-y-6">
          {/* Plan fields */}
          <div className="card p-6">
            <div className="mb-5 flex items-center gap-2">
              <Wallet size={20} className="text-violet-500" />
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">Plan My Month</h2>
            </div>
            <p className="mb-5 text-sm text-slate-500">Set your starting balance, expected income, and protected savings for this month.</p>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label className="label">Opening Balance</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">{getCurrencySymbol(currency)}</span>
                  <input type="number" min="0" value={planForm.opening_balance} onChange={(e) => setPlanForm({ ...planForm, opening_balance: e.target.value })} className="input pl-7" placeholder="0" />
                </div>
              </div>
              <div>
                <label className="label">Expected Income</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">{getCurrencySymbol(currency)}</span>
                  <input type="number" min="0" value={planForm.expected_income} onChange={(e) => setPlanForm({ ...planForm, expected_income: e.target.value })} className="input pl-7" placeholder="0" />
                </div>
              </div>
              <div>
                <label className="label">Protected Savings</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">{getCurrencySymbol(currency)}</span>
                  <input type="number" min="0" value={planForm.protected_savings} onChange={(e) => setPlanForm({ ...planForm, protected_savings: e.target.value })} className="input pl-7" placeholder="0" />
                </div>
              </div>
            </div>
            {planError && <div className="mt-4 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">{planError}</div>}
            <div className="mt-5 flex items-center gap-3">
              <button onClick={handleSavePlan} disabled={savingPlan} className="btn btn-primary">
                <Save size={18} />
                {savingPlan ? 'Saving...' : planSaved ? 'Saved!' : 'Save Plan'}
              </button>
              {planSaved && <CheckCircle2 size={20} className="text-emerald-500" />}
            </div>
          </div>

          {/* Budget and category management */}
          <div className="card p-6">
            <div className="mb-4">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Set budgets</h3>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Add a category here, then set its monthly budget in the same list below.</p>
            </div>
            <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-end">
              <div className="flex-1">
                <label className="label" htmlFor="new-category-name">New category name</label>
                <input id="new-category-name" type="text" value={newCategory.name} onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })} className="input" placeholder="e.g. Petrol" />
              </div>
              <select value={newCategory.type} onChange={(e) => setNewCategory({ ...newCategory, type: e.target.value as 'expense' | 'income', is_fixed: false })} className="input w-32">
                <option value="expense">Expense</option>
                <option value="income">Income</option>
              </select>
              {newCategory.type === 'expense' && (
                <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                  <input type="checkbox" checked={newCategory.is_fixed} onChange={(e) => setNewCategory({ ...newCategory, is_fixed: e.target.checked })} className="h-4 w-4 rounded border-slate-300" />
                  Fixed
                </label>
              )}
              <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400">
                <input type="checkbox" checked={newCategory.is_essential} onChange={(e) => setNewCategory({ ...newCategory, is_essential: e.target.checked })} className="h-4 w-4 rounded border-slate-300" />
                Essential
              </label>
              <button onClick={handleAddCategory} disabled={savingCategory || !newCategory.name.trim()} className="btn btn-primary shrink-0">
                <Plus size={18} />
                {savingCategory ? 'Adding...' : 'Add category'}
              </button>
            </div>
            {categoryError && <div className="mt-2 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700" role="alert">{categoryError}</div>}
            <div className="space-y-2">
              {categories.map((cat) => (
                <div key={cat.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                  <span className="min-w-32 flex-1 text-sm font-medium text-slate-900 dark:text-slate-100">{cat.name}</span>
                  <span className={`badge ${cat.type === 'income' ? 'badge-green' : 'badge-blue'}`}>{cat.type}</span>
                  {cat.type === 'expense' && (
                    <button onClick={() => handleToggleFixed(cat.id, cat.is_fixed)} className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors ${cat.is_fixed ? 'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                      <Lock size={13} />
                      {cat.is_fixed ? 'Fixed' : 'Variable'}
                    </button>
                  )}
                  <button onClick={() => handleToggleEssential(cat.id, cat.is_essential)} className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors ${cat.is_essential ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400'}`}>
                    <ShieldCheck size={13} />
                    {cat.is_essential ? 'Essential' : 'Optional'}
                  </button>
                  {cat.type === 'expense' && (
                    <div className="relative w-32">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">{getCurrencySymbol(currency)}</span>
                      <input type="number" min="0" value={budgetEdits[cat.id] ?? '0'} onChange={(e) => setBudgetEdits({ ...budgetEdits, [cat.id]: e.target.value })} className="input pl-7" placeholder="0" aria-label={`${cat.name} budget`} />
                    </div>
                  )}
                  <button onClick={() => setDeleteCatTarget(cat.id)} className="btn-ghost btn !p-1.5 text-red-500 hover:bg-red-50" title="Delete category" aria-label="Delete category">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </div>
            {deleteCatTarget && (
              <div className="mt-3 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
                <p>Delete this category? This cannot be undone.</p>
                <div className="mt-2 flex gap-2">
                  <button onClick={() => handleDeleteCategory(deleteCatTarget)} className="btn btn-primary !bg-red-600 hover:!bg-red-700 text-xs">Delete</button>
                  <button onClick={() => setDeleteCatTarget(null)} className="btn btn-secondary text-xs">Cancel</button>
                </div>
              </div>
            )}
            <p className="mt-4 text-xs text-slate-500">Set the budget amount beside each expense category. Expense amounts may be pre-filled from your Yearly Plan and can be adjusted for this month.</p>
            {budgetError && <div className="mt-4 rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">{budgetError}</div>}
            <div className="mt-5 flex items-center gap-3">
              <button onClick={handleSaveBudgets} disabled={savingBudgets} className="btn btn-primary">
                <Save size={18} />
                {savingBudgets ? 'Saving...' : budgetsSaved ? 'Saved!' : 'Save Budgets'}
              </button>
              {budgetsSaved && <CheckCircle2 size={20} className="text-emerald-500" />
              }
            </div>
          </div>
        </div>
      )}

      {activeTab === 'plan' && !plan && (
        <div className="card p-8 text-center">
          <div className="flex flex-col items-center gap-3">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-slate-200 border-t-blue-600" />
            <p className="text-sm text-slate-500">{planError ? planError : 'Creating your plan for this month...'}</p>
            {planError && <button onClick={() => { setPlanError(null); refetch(); }} className="btn btn-secondary mt-2 text-xs">Retry</button>}
          </div>
        </div>
      )}

      {activeTab === 'monthly' && (
        <MonthlyReview
          month={month}
          plan={plan}
          categories={categories}
          budgets={budgets}
          transactions={transactions}
          refetch={refetch}
        />
      )}

      {showToast && (
        <div className="simulator-success-toast">
          <CheckCircle2 size={18} />
          Scenario applied to your plan
        </div>
      )}
    </div>
  );
}
