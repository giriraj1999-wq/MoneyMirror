import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Simulator from '@/pages/Simulator'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
  ],
  budgets: [
    { id: 'b-1', plan_id: 'plan-1', category_id: 'cat-1', planned_amount: 15000 },
  ],
  transactions: [],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Simulator', () => {
  it('renders the Simulator heading', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Simulator />)
    expect(screen.getByText('Financial Simulator')).toBeInTheDocument()
  })

  it('shows empty state when no plan exists', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      plan: null,
    })
    render(<Simulator />)
    expect(screen.getByText('Create a monthly plan before running a simulation.')).toBeInTheDocument()
  })

  it('shows loading state', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      loading: true,
    })
    render(<Simulator />)
    expect(screen.getByText('Loading simulator...')).toBeInTheDocument()
  })
})
