import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, fireEvent, waitFor } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Transactions from '@/pages/Transactions'
import Shared from '@/pages/Shared'

const basePlan = {
  id: 'plan-1', user_id: 'user-1', month: '2026-09-01',
  opening_balance: 50000, expected_income: 80000, protected_savings: 10000,
  base_currency: 'INR', created_at: '', updated_at: '',
}

const baseCategories = [
  { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
]

describe('Display currency on Transactions and Shared pages', () => {
  beforeEach(() => {
    localStorage.setItem('mm-currency', 'USD')
  })

  afterEach(() => {
    localStorage.removeItem('mm-currency')
  })

  it('Transactions list converts INR amounts to USD for display', async () => {
    mockUseMonthData.mockReturnValue({
      month: '2026-09-01', loading: false, plan: basePlan,
      categories: baseCategories, budgets: [],
      transactions: [
        { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 1000, type: 'expense' as const, txn_date: '2026-09-01', note: 'Rent', source: 'manual' as const, currency: 'INR', amount_base: 1000, bill_url: null, bill_path: null, commitment_id: null, created_at: '', updated_at: '' },
      ],
      commitments: [], outgoingShares: [], incomingShares: [],
      refetch: vi.fn(), ensurePlan: vi.fn(), setPlan: vi.fn(),
      setCategories: vi.fn(), setBudgets: vi.fn(), setTransactions: vi.fn(),
      setCommitments: vi.fn(), setOutgoingShares: vi.fn(), setIncomingShares: vi.fn(),
    })

    render(<Transactions />)

    // The conversion mock returns amount * 0.012 for INR→USD.
    // 1000 INR → 12 USD. Wait for the async conversion to settle.
    await waitFor(() => {
      const body = document.body.textContent ?? ''
      expect(body).toContain('$12')
    })
  })

  it('Shared page converts INR share amounts to USD for display', async () => {
    mockUseMonthData.mockReturnValue({
      month: '2026-09-01', loading: false, plan: basePlan,
      categories: baseCategories, budgets: [],
      transactions: [
        { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: null, amount: 2000, type: 'expense' as const, txn_date: '2026-09-01', note: 'Dinner', source: 'manual' as const, currency: 'INR', amount_base: 2000, bill_url: null, bill_path: null, commitment_id: null, created_at: '', updated_at: '' },
      ],
      commitments: [],
      outgoingShares: [
        { id: 's-1', transaction_id: 't-1', owner_user_id: 'user-1', partner_email: 'friend@test.com', partner_user_id: 'partner-1', share_amount: 1000, share_currency: 'INR', share_amount_base: 1000, status: 'pending' as const, paid_at: null, acknowledged_at: null, settlement_txn_id: null, created_at: '', updated_at: '' },
      ],
      incomingShares: [
        { id: 's-2', transaction_id: 't-1', owner_user_id: 'other', partner_email: 'user@test.com', partner_user_id: 'user-1', share_amount: 500, share_currency: 'INR', share_amount_base: 500, status: 'accepted' as const, paid_at: null, acknowledged_at: null, settlement_txn_id: null, created_at: '', updated_at: '' },
      ],
      refetch: vi.fn(), ensurePlan: vi.fn(), setPlan: vi.fn(),
      setCategories: vi.fn(), setBudgets: vi.fn(), setTransactions: vi.fn(),
      setCommitments: vi.fn(), setOutgoingShares: vi.fn(), setIncomingShares: vi.fn(),
    })

    render(<Shared />)

    // 1000 INR → 12 USD, 500 INR → 6 USD
    await waitFor(() => {
      const body = document.body.textContent ?? ''
      expect(body).toContain('$12')
      expect(body).toContain('$6')
    })
  })

  it('Transactions Add modal defaults the currency selector to the display currency (USD)', () => {
    mockUseMonthData.mockReturnValue({
      month: '2026-09-01', loading: false, plan: basePlan,
      categories: baseCategories, budgets: [],
      transactions: [],
      commitments: [], outgoingShares: [], incomingShares: [],
      refetch: vi.fn(), ensurePlan: vi.fn(), setPlan: vi.fn(),
      setCategories: vi.fn(), setBudgets: vi.fn(), setTransactions: vi.fn(),
      setCommitments: vi.fn(), setOutgoingShares: vi.fn(), setIncomingShares: vi.fn(),
    })

    render(<Transactions />)

    fireEvent.click(screen.getByText('Add Transaction'))

    const selects = screen.getAllByRole('combobox')
    const currencySelect = selects.find((s) => (s as HTMLSelectElement).value === 'USD')
    expect(currencySelect).toBeTruthy()
  })
})
