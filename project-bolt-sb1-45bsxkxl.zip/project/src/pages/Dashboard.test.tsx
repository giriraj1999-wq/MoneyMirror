import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Dashboard from '@/pages/Dashboard'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
    { id: 'cat-2', user_id: 'user-1', name: 'Groceries', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
    { id: 'cat-3', user_id: 'user-1', name: 'Salary', is_essential: false, type: 'income' as const, created_at: '' },
  ],
  budgets: [
    { id: 'b-1', plan_id: 'plan-1', category_id: 'cat-1', planned_amount: 15000 },
    { id: 'b-2', plan_id: 'plan-1', category_id: 'cat-2', planned_amount: 8000 },
  ],
  transactions: [
    { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-3', amount: 80000, type: 'income' as const, txn_date: '2026-09-01', note: 'Salary', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
    { id: 't-2', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 15000, type: 'expense' as const, txn_date: '2026-09-02', note: 'Rent', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
  ],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Dashboard', () => {
  it('renders the dashboard heading', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Dashboard />)
    expect(screen.getByText('Dashboard')).toBeInTheDocument()
  })

  it('shows Available After Commitments section', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Dashboard />)
    // The text "Available After Commitments" is inside a <p> with an icon
    const allText = document.body.textContent ?? ''
    expect(allText).toContain('Available After Commitments')
  })

  it('renders the four metric cards', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Dashboard />)
    expect(screen.getByText('Current Balance')).toBeInTheDocument()
    expect(screen.getByText('Unpaid Commitments')).toBeInTheDocument()
    expect(screen.getByText('Remaining Essential')).toBeInTheDocument()
    expect(screen.getByText('Protected Savings')).toBeInTheDocument()
  })

  it('renders Plan Holds verdict when AAC is positive', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Dashboard />)
    expect(screen.getByText('Plan Holds')).toBeInTheDocument()
  })

  it('renders Warning verdict when a category is over budget', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      transactions: [
        { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-3', amount: 80000, type: 'income' as const, txn_date: '2026-09-01', note: 'Salary', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
        { id: 't-2', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 15000, type: 'expense' as const, txn_date: '2026-09-02', note: 'Rent', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
        // Groceries: budget 8000, spent 14000 = 175%
        { id: 't-3', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-2', amount: 14000, type: 'expense' as const, txn_date: '2026-09-03', note: 'Groceries', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
      ],
    })
    render(<Dashboard />)
    expect(screen.getByText('Warning')).toBeInTheDocument()
  })

  it('renders Shortfall verdict when AAC is negative', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      commitments: [
        { id: 'c-1', user_id: 'user-1', plan_id: 'plan-1', title: 'Huge bill', amount: 200000, due_date: '2026-09-10', is_paid: false, paid_at: null, created_at: '' },
      ],
    })
    render(<Dashboard />)
    expect(screen.getByText('Shortfall')).toBeInTheDocument()
  })

  it('shows empty state when no plan exists', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      plan: null,
    })
    render(<Dashboard />)
    expect(screen.getByText('No plan for this month yet')).toBeInTheDocument()
  })

  it('shows loading state', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      loading: true,
    })
    render(<Dashboard />)
    expect(screen.getByText(/Loading your dashboard/i)).toBeInTheDocument()
  })

  it('counts reimbursements as expense reductions, not income', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      transactions: [
        { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-3', amount: 80000, type: 'income' as const, txn_date: '2026-09-01', note: 'Salary', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
        { id: 't-2', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 15000, type: 'expense' as const, txn_date: '2026-09-02', note: 'Rent', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
        { id: 't-3', user_id: 'user-1', plan_id: 'plan-1', category_id: null, amount: 5000, type: 'reimbursement' as const, txn_date: '2026-09-03', note: 'Reimbursement from friend', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
      ],
    })
    render(<Dashboard />)
    const allText = document.body.textContent ?? ''
    // Expenses should show 15000 net (15000 expense - 5000 reimbursement), not 15000
    // Income should show 80000 only, not 85000
    expect(allText).toContain('₹80,000')
    expect(allText).not.toContain('₹85,000')
  })

  it('does not duplicate next-due commitment in upcoming renewals', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      commitments: [
        { id: 'c-1', user_id: 'user-1', plan_id: 'plan-1', title: 'Electricity', amount: 2000, due_date: '2026-09-05', is_paid: false, paid_at: null, created_at: '' },
        { id: 'c-2', user_id: 'user-1', plan_id: 'plan-1', title: 'Internet', amount: 1000, due_date: '2026-09-15', is_paid: false, paid_at: null, created_at: '' },
      ],
    })
    render(<Dashboard />)
    // Next due commitment shows Electricity
    expect(screen.getByText('Electricity')).toBeInTheDocument()
    // Upcoming renewals should show Internet but NOT duplicate Electricity
    const electricityElements = screen.getAllByText('Electricity')
    expect(electricityElements).toHaveLength(1)
    expect(screen.getByText('Internet')).toBeInTheDocument()
  })
})
