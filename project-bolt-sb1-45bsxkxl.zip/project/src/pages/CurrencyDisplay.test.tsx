import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Commitments from '@/pages/Commitments'

const basePlan = {
  id: 'plan-1', user_id: 'user-1', month: '2026-09-01',
  opening_balance: 50000, expected_income: 80000, protected_savings: 10000,
  base_currency: 'INR', created_at: '', updated_at: '',
}

const baseCategories = [
  { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
]

describe('Display currency propagation', () => {
  beforeEach(() => {
    localStorage.setItem('mm-currency', 'AED')
  })

  afterEach(() => {
    localStorage.removeItem('mm-currency')
  })

  it('Commitments page uses the display currency (AED) not INR', () => {
    mockUseMonthData.mockReturnValue({
      month: '2026-09-01', loading: false, plan: basePlan,
      categories: baseCategories, budgets: [], transactions: [],
      commitments: [
        { id: 'c1', user_id: 'user-1', plan_id: 'plan-1', title: 'Car EMI', amount: 2500, due_date: '2026-09-15', is_paid: false, paid_at: null },
      ],
      outgoingShares: [], incomingShares: [],
      refetch: vi.fn(), ensurePlan: vi.fn(), setPlan: vi.fn(),
      setCategories: vi.fn(), setBudgets: vi.fn(), setTransactions: vi.fn(),
      setCommitments: vi.fn(), setOutgoingShares: vi.fn(), setIncomingShares: vi.fn(),
    })

    render(<Commitments />)

    const unpaidSummary = screen.getByText(/unpaid/i)
    expect(unpaidSummary.textContent).toContain('AED')
    expect(unpaidSummary.textContent).not.toContain('₹')
  })

  it('Commitments Add modal shows the display currency symbol', () => {
    mockUseMonthData.mockReturnValue({
      month: '2026-09-01', loading: false, plan: basePlan,
      categories: baseCategories, budgets: [], transactions: [],
      commitments: [],
      outgoingShares: [], incomingShares: [],
      refetch: vi.fn(), ensurePlan: vi.fn(), setPlan: vi.fn(),
      setCategories: vi.fn(), setBudgets: vi.fn(), setTransactions: vi.fn(),
      setCommitments: vi.fn(), setOutgoingShares: vi.fn(), setIncomingShares: vi.fn(),
    })

    render(<Commitments />)

    // Open the Add Commitment modal
    fireEvent.click(screen.getByText('Add Commitment'))

    const currencySymbol = screen.getByText('AED')
    expect(currencySymbol).toBeInTheDocument()
  })
})
