import { useMemo, useState } from 'react';
import { AlertTriangle, Check, Loader2, ShieldCheck, Zap } from 'lucide-react';
import { formatCurrency, getMonthLabel } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import { supabase } from '@/lib/supabase';
import type { Budget, Category, Plan, Transaction } from '@/types';

interface MonthlyReviewProps {
  month: string;
  plan: Plan | null;
  categories: Category[];
  budgets: Budget[];
  transactions: Transaction[];
  refetch?: () => Promise<void>;
}

interface CategoryReview {
  id: string;
  name: string;
  budget: number;
  actual: number;
  variance: number;
}

function formatGap(amount: number, currency: string): string {
  return amount < 0 ? `Deficit (${formatCurrency(amount, currency)})` : `Surplus (+${formatCurrency(amount, currency)})`;
}

export default function MonthlyReview({
  month,
  plan,
  categories,
  budgets,
  transactions,
  refetch,
}: MonthlyReviewProps) {
  const { currency } = useDisplayCurrency();
  const [appliedCorrection, setAppliedCorrection] = useState<string | null>(null);
  const [applyingId, setApplyingId] = useState<string | null>(null);
  const [applyError, setApplyError] = useState<string | null>(null);

  const actualIncome = transactions
    .filter((transaction) => transaction.type === 'income')
    .reduce((total, transaction) => total + Number(transaction.amount_base ?? transaction.amount), 0);
  const expectedIncome = Number(plan?.expected_income ?? 0);
  const actualSpend = transactions
    .filter((transaction) => transaction.type === 'expense')
    .reduce((total, transaction) => total + Number(transaction.amount_base ?? transaction.amount), 0);
  const reimbursementTotal = transactions
    .filter((transaction) => transaction.type === 'reimbursement')
    .reduce((total, transaction) => total + Number(transaction.amount_base ?? transaction.amount), 0);
  const netSpend = actualSpend - reimbursementTotal;
  const plannedSavings = Number(plan?.protected_savings ?? 0);
  // Align with Dashboard: gap = expected income - actual spend - planned savings
  // This uses expected income (the plan target) rather than actual income received,
  // so the review tells the same story as the dashboard regardless of when income arrives.
  const gap = expectedIncome - netSpend - plannedSavings;

  const categoryReviews = useMemo<CategoryReview[]>(() => {
    const expenseCategories = categories.filter((category) => category.type === 'expense');
    const actualByCategory = new Map<string, number>();
    transactions
      .filter((transaction) => transaction.type === 'expense' && transaction.category_id)
      .forEach((transaction) => {
        const id = transaction.category_id as string;
        actualByCategory.set(id, (actualByCategory.get(id) ?? 0) + Number(transaction.amount_base ?? transaction.amount));
      });

    const rows = expenseCategories.map((category) => {
      const budget = Number(
        budgets.find((item) => item.category_id === category.id)?.planned_amount ?? 0
      );
      const actual = actualByCategory.get(category.id) ?? 0;
      return {
        id: category.id,
        name: category.name,
        budget,
        actual,
        variance: actual - budget,
      };
    });

    const uncategorisedTotals = new Map<string, number>();
    transactions
      .filter((transaction) => transaction.type === 'expense' && transaction.category_id)
      .filter((transaction) => !expenseCategories.some((category) => category.id === transaction.category_id))
      .forEach((transaction) => {
        const id = transaction.category_id as string;
        uncategorisedTotals.set(id, (uncategorisedTotals.get(id) ?? 0) + Number(transaction.amount_base ?? transaction.amount));
      });

    for (const [id, total] of uncategorisedTotals) {
      rows.push({
        id,
        name: 'Uncategorised',
        budget: 0,
        actual: total,
        variance: total,
      });
    }

    return rows
      .filter((row) => row.budget > 0 || row.actual > 0)
      .sort((a, b) => b.actual - a.actual);
  }, [budgets, categories, transactions]);

  const corrections = useMemo(() => {
    const overages = categoryReviews
      .filter((row) => row.variance > 0)
      .sort((a, b) => {
        // Rank essential categories first (issue 4)
        const aCat = categories.find((c) => c.id === a.id);
        const bCat = categories.find((c) => c.id === b.id);
        const aEssential = aCat?.is_essential ? 1 : 0;
        const bEssential = bCat?.is_essential ? 1 : 0;
        if (bEssential !== aEssential) return bEssential - aEssential;
        return b.variance - a.variance;
      });
    const recommendations = overages.slice(0, 3).map((row, index) => ({
      id: row.id,
      rank: index + 1,
      tag: index === 0 && gap < 0 ? `Fixes ${formatCurrency(Math.abs(gap), currency)} gap` : `Saves ${formatCurrency(row.variance, currency)} total`,
      title: `Tighten ${row.name} budget`,
      description: `Reduce this category by ${formatCurrency(row.variance, currency)} this month to bring actual spending back to its planned limit.`,
    }));

    if (recommendations.length === 0 && gap < 0) {
      recommendations.push({
        id: 'savings-gap',
        rank: 1,
        tag: `Fixes ${formatCurrency(Math.abs(gap), currency)} gap`,
        title: 'Protect your savings target',
        description: 'Review your flexible spending categories and redirect the difference toward your planned savings.',
      });
    }

    if (recommendations.length === 0) {
      recommendations.push({
        id: 'keep-going',
        rank: 1,
        tag: 'Plan holds',
        title: 'Keep your current rhythm',
        description: 'Your spending is within the tracked plan. Keep logging transactions to make this review more useful.',
      });
    }

    return recommendations;
  }, [categoryReviews, gap]);

  const handleApplyCorrection = async (correction: { id: string; title: string }) => {
    if (correction.id === 'savings-gap' || correction.id === 'keep-going') {
      setAppliedCorrection(correction.id);
      return;
    }
    setApplyingId(correction.id);
    setApplyError(null);
    try {
      const budget = budgets.find((b) => b.category_id === correction.id);
      const review = categoryReviews.find((r) => r.id === correction.id);
      if (!budget || !review) {
        setAppliedCorrection(correction.id);
        return;
      }
      const newAmount = Math.max(0, budget.planned_amount - review.variance);
      const { error } = await supabase
        .from('budgets')
        .update({ planned_amount: newAmount })
        .eq('id', budget.id);
      if (error) throw error;
      setAppliedCorrection(correction.id);
      if (refetch) await refetch();
    } catch (err) {
      setApplyError(err instanceof Error ? err.message : 'Failed to apply correction');
    } finally {
      setApplyingId(null);
    }
  };

  return (
    <div className="monthly-review-page">
      <section className="monthly-review-card monthly-review-gap-card">
        <div className="monthly-review-card-heading">
          <div className="flex items-center gap-3">
            <ShieldCheck size={24} className="text-[#a64df2]" />
            <h1>Gap Analysis Formula</h1>
          </div>
          <span className={`monthly-review-gap-badge ${gap < 0 ? 'is-deficit' : 'is-surplus'}`}>
            {formatGap(gap, currency)}
          </span>
        </div>
        <div className="monthly-review-formula">
          Expected Income ({formatCurrency(expectedIncome, currency)}) − Actual Spend ({formatCurrency(actualSpend, currency)}) − Planned Savings ({formatCurrency(plannedSavings, currency)})
        </div>
        <p className="monthly-review-period">{getMonthLabel(month)} review</p>
      </section>

      <section className="monthly-review-card monthly-review-variance-card">
        <h2 className="monthly-review-section-label">Category Variance Table</h2>
        {categoryReviews.length === 0 ? (
          <div className="monthly-review-empty">
            <AlertTriangle size={20} />
            <p>Add a budget or expense category to see your monthly variance here.</p>
          </div>
        ) : (
          <div>
            {categoryReviews.map((row) => {
              const status = row.variance > 0 ? 'Over' : row.variance < 0 ? 'Under' : 'On Track';
              const statusClass = row.variance > 0 ? 'is-over' : 'is-under';
              return (
                <div key={row.id} className="monthly-review-variance-row">
                  <div>
                    <p className="monthly-review-category-name">{row.name}</p>
                    <p className="monthly-review-budgeted">Budgeted: {formatCurrency(row.budget, currency)}</p>
                  </div>
                  <div className="text-right">
                    <p className="monthly-review-actual">{formatCurrency(row.actual, currency)}</p>
                    <span className={`monthly-review-status ${statusClass}`}>
                      {status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="monthly-review-corrections">
        <div className="monthly-review-corrections-heading">
          <div className="flex items-center gap-3">
            <Zap size={26} className="text-amber-500" fill="currentColor" />
            <div>
              <h2>Ranked Course-Correction Cards</h2>
              <p>The one screen that changes behavior — ranked recommendations to instantly fix budget gaps</p>
            </div>
          </div>
        </div>
        <div className="monthly-review-correction-grid">
          {corrections.map((correction) => {
            const isApplied = appliedCorrection === correction.id;
            return (
              <article key={correction.id} className="monthly-review-correction-card">
                <div className="flex items-center justify-between gap-3">
                  <span className="monthly-review-rank">#{correction.rank}</span>
                  <span className="monthly-review-correction-tag">{correction.tag}</span>
                </div>
                <h3>{correction.title}</h3>
                <p>{correction.description}</p>
                <button
                  className="monthly-review-apply"
                  onClick={() => handleApplyCorrection(correction)}
                  disabled={isApplied || applyingId === correction.id}
                >
                  {isApplied ? <Check size={18} /> : applyingId === correction.id ? <Loader2 size={18} className="animate-spin" /> : <Zap size={18} fill="currentColor" />}
                  {isApplied ? 'Correction Applied' : applyingId === correction.id ? 'Applying...' : 'Apply Correction'}
                </button>
              </article>
            );
          })}
        </div>
      </section>
      {applyError && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{applyError}</div>
      )}
    </div>
  );
}
