import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Lightbulb,
  PiggyBank,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  Wallet,
  X,
  Zap,
} from 'lucide-react';
import { useMonthData } from '@/hooks/useMonthData';
import { computeAAC } from '@/lib/moneyEngine';
import { formatCurrency, formatDate } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import EmptyState from '@/components/shared/EmptyState';
import VerdictBadge from '@/components/shared/VerdictBadge';

export default function Dashboard() {
  const { month, loading, plan, categories, budgets, transactions, commitments, outgoingShares, incomingShares } = useMonthData();
  const { currency } = useDisplayCurrency();

  const aacResult = useMemo(
    () => computeAAC(plan, transactions, commitments, categories, budgets),
    [plan, transactions, commitments, categories, budgets]
  );

  const expectedIncome = plan?.expected_income ?? 0;
  const actualIncomeTotal = transactions.filter((t) => t.type === 'income').reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
  const expenseTotal = transactions.filter((t) => t.type === 'expense').reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
  const reimbursementTotal = transactions.filter((t) => t.type === 'reimbursement').reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
  const unpaidCommitments = useMemo(
    () => commitments.filter((commitment) => !commitment.is_paid).sort((a, b) => a.due_date.localeCompare(b.due_date)),
    [commitments]
  );
  const nextDue = unpaidCommitments[0] ?? null;
  const otherUpcomingCommitments = unpaidCommitments.filter((commitment) => commitment.id !== nextDue?.id);
  const protectedSavings = plan?.protected_savings ?? 0;
  const actualSavings = Math.max(0, expectedIncome - expenseTotal + reimbursementTotal);
  const savingsRate = expectedIncome > 0 ? Math.max(0, Math.round((actualSavings / expectedIncome) * 100)) : 0;
  const savingsOnTrack = actualSavings >= protectedSavings;
  const sharedBalance = outgoingShares.reduce((sum, share) => sum + (share.share_amount_base ?? share.share_amount), 0) - incomingShares.reduce((sum, share) => sum + (share.share_amount_base ?? share.share_amount), 0);
  const topGoals = categories
    .filter((category) => category.is_essential)
    .map((category) => {
      const planned = budgets.find((budget) => budget.category_id === category.id)?.planned_amount ?? 0;
      const spent = transactions.filter((transaction) => transaction.category_id === category.id && transaction.type === 'expense').reduce((sum, transaction) => sum + (transaction.amount_base ?? transaction.amount), 0);
      return { name: category.name, planned, spent, progress: planned > 0 ? Math.min(100, Math.round((spent / planned) * 100)) : 0 };
    })
    .filter((goal) => goal.planned > 0)
    .slice(0, 2);

  if (loading) return <div className="flex h-full items-center justify-center text-sm text-slate-500">Loading your dashboard...</div>;

  if (!plan) {
    return (
      <div>
        <PageHeader />
        <EmptyState title="No plan for this month yet" description="Set up your monthly plan to see your available money and financial overview." action={<Link to="/plan" className="btn btn-primary">Create a Plan <ArrowRight size={18} /></Link>} />
      </div>
    );
  }

  return (
    <div className="dashboard-page space-y-5">
      <PageHeader />

      {/* AAC Hero with verdict badge */}
      <section className="dashboard-hero dashboard-panel">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="dashboard-kicker"><Zap size={18} fill="currentColor" /> Available After Commitments</p>
            <div className="mt-1.5 flex items-baseline gap-3">
              <p className="dashboard-hero-value">{formatCurrency(aacResult.aac, currency)}</p>
            </div>
            <p className="mt-1 text-sm text-slate-500">Money left after essentials, commitments, and protected savings.</p>
          </div>
          <VerdictBadge verdict={aacResult.verdict} size="lg" />
        </div>
        <div className="dashboard-rule" />
        <div className="grid gap-3 md:grid-cols-3">
          <SummaryStat label="Expected Income" value={formatCurrency(expectedIncome, currency)} accent="green" />
          <SummaryStat label="Actual Income" value={formatCurrency(actualIncomeTotal, currency)} accent="green" />
          <SummaryStat label="Expenses" value={formatCurrency(expenseTotal, currency)} accent="red" />
          <SummaryStat label="Saved" value={formatCurrency(actualSavings, currency)} accent={savingsOnTrack ? "purple" : "red"} />
          <SummaryStat label="Savings Target" value={formatCurrency(protectedSavings, currency)} accent="purple" />
        </div>
      </section>

      {/* 4 metric cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard icon={<Wallet size={18} />} label="Current Balance" value={formatCurrency(aacResult.currentBalance, currency)} />
        <MetricCard icon={<CalendarDays size={18} />} label="Unpaid Commitments" value={formatCurrency(aacResult.unpaidCommitments, currency)} />
        <MetricCard icon={<ShieldCheck size={18} />} label="Remaining Essential" value={formatCurrency(aacResult.remainingEssential, currency)} />
        <MetricCard icon={<PiggyBank size={18} />} label="Protected Savings" value={formatCurrency(aacResult.protectedSavings, currency)} />
      </div>

      {/* Next due + Savings rate */}
      <div className="grid gap-5 lg:grid-cols-2">
        <section className="dashboard-panel">
          <SectionTitle icon={<CalendarDays size={18} />} title="Next scheduled payment" />
          {nextDue ? (
            <div className="mt-4 flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-50">
                <CalendarDays size={22} className="text-amber-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-slate-900 dark:text-white">{nextDue.title}</p>
                <p className="text-sm text-slate-500">Due {formatDate(nextDue.due_date)}</p>
              </div>
              <p className="font-black text-violet-600">{formatCurrency(nextDue.amount, currency)}</p>
            </div>
          ) : (
            <p className="mt-4 text-sm text-slate-500">No upcoming commitments.</p>
          )}
          <Link to="/commitments" className="dashboard-link mt-4 inline-flex items-center gap-1">View all commitments <ArrowRight size={15} /></Link>
        </section>
        <section className="dashboard-panel flex min-h-[154px] items-center justify-between gap-6">
          <div>
            <SectionTitle icon={<PiggyBank size={18} />} title="Savings rate" />
            <p className="mt-5 text-4xl font-black tracking-tight text-slate-950 dark:text-white">{savingsRate}%</p>
            <p className="mt-2 text-sm text-slate-500">Target: 20% minimum</p>
          </div>
          <ProgressRing value={savingsRate} />
        </section>
      </div>

      {/* Upcoming renewals + Shared balance */}
      <div className="grid gap-5 lg:grid-cols-[2fr_1fr]">
        <section className="dashboard-panel">
          <div className="mb-5 flex items-center justify-between gap-3"><SectionTitle icon={<CalendarDays size={18} />} title="Upcoming renewals" /><Link to="/commitments" className="dashboard-link">Commitments tab <ArrowRight size={16} /></Link></div>
          {otherUpcomingCommitments.length === 0 ? <p className="text-sm text-slate-500">No other upcoming commitments this month.</p> : <div className="grid gap-3 md:grid-cols-3">{otherUpcomingCommitments.slice(0, 3).map((commitment) => <div className="dashboard-mini-card" key={commitment.id}><p className="font-bold text-slate-900 dark:text-white">{commitment.title}</p><div className="mt-2 flex items-center justify-between gap-2"><span className="font-black text-violet-600">{formatCurrency(commitment.amount, currency)}</span><span className="text-xs text-slate-500">{formatDate(commitment.due_date)}</span></div></div>)}</div>}
        </section>
        <section className="dashboard-panel"><div className="mb-4 flex items-center justify-between"><SectionTitle icon={<Users size={18} />} title="Shared balance" /><ArrowRight size={18} className="text-violet-500" /></div><p className={`dashboard-share-pill ${sharedBalance >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>{sharedBalance >= 0 ? `You're owed ${formatCurrency(Math.abs(sharedBalance), currency)} overall` : `You owe ${formatCurrency(Math.abs(sharedBalance), currency)} overall`}</p><Link to="/shared" className="mt-5 block text-sm text-slate-500 hover:text-violet-600">Tap to view groups & settle debts</Link></section>
      </div>

      <section className="dashboard-panel"><div className="mb-5 flex items-center justify-between"><SectionTitle icon={<Target size={18} />} title="Top financial goals" /><Link to="/goals" className="dashboard-link">View all goals <ArrowRight size={16} /></Link></div>{topGoals.length === 0 ? <p className="text-sm text-slate-500">Add planned amounts to your essential categories to see progress here.</p> : <div className="space-y-5">{topGoals.map((goal) => <div key={goal.name}><div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-sm font-bold"><span>{goal.name}</span><span className="text-violet-600">{goal.progress}% <span className="font-medium">({formatCurrency(goal.spent, currency)} / {formatCurrency(goal.planned, currency)})</span></span></div><div className="dashboard-progress"><span style={{ width: `${goal.progress}%` }} /></div></div>)}</div>}</section>

      <section><div className="mb-3 flex items-center justify-between px-1"><SectionTitle icon={<Sparkles size={18} />} title="Smart nudge feed" /><span className="text-sm text-slate-500">Daily automated insights</span></div><div className="space-y-3"><Nudge icon={<Lightbulb size={20} />} title="Your plan is ready to review" text={`${formatCurrency(aacResult.aac, currency)} remains available after commitments this month.`} link="Review your plan" /><Nudge icon={<CheckCircle2 size={20} />} title={savingsOnTrack ? 'Savings rate on track' : 'Savings opportunity' } text={savingsOnTrack ? `You're saving ${formatCurrency(actualSavings, currency)} against a ${formatCurrency(protectedSavings, currency)} target.` : `You've saved ${formatCurrency(actualSavings, currency)} but your protected savings target is ${formatCurrency(protectedSavings, currency)}. Try protecting more income before discretionary spending.`} link="View insights" /></div></section>
    </div>
  );
}

function PageHeader() {
  return <div><p className="dashboard-eyebrow">Your financial command center</p><h1 className="mt-1 text-3xl font-black tracking-tight text-slate-950 dark:text-white">Dashboard</h1><p className="mt-1 text-sm text-slate-500">Stay ahead of your money, one decision at a time.</p></div>;
}

function SectionTitle({ icon, title }: { icon: React.ReactNode; title: string }) { return <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300"><span className="text-violet-500">{icon}</span><h2 className="dashboard-section-title">{title}</h2></div>; }
function SummaryStat({ label, value, accent }: { label: string; value: string; accent: 'green' | 'red' | 'purple' }) {
  const accentClass = { green: 'dashboard-value-green', red: 'dashboard-value-red', purple: 'dashboard-value-purple' }[accent];
  return <div className="dashboard-summary-stat"><span>{label}</span><strong className={accentClass}>{value}</strong></div>;
}
function MetricCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="dashboard-panel">
      <div className="flex items-center gap-2 text-slate-500"><span className="text-violet-500">{icon}</span><span className="text-xs font-bold uppercase tracking-wide">{label}</span></div>
      <p className="mt-3 text-2xl font-black tracking-tight text-slate-950 dark:text-white">{value}</p>
    </div>
  );
}
function ProgressRing({ value }: { value: number }) { const radius = 44; const circumference = 2 * Math.PI * radius; return <div className="relative h-32 w-32"><svg viewBox="0 0 112 112" className="h-full w-full -rotate-90"><circle cx="56" cy="56" r={radius} fill="none" stroke="currentColor" strokeWidth="11" className="text-slate-200" /><circle cx="56" cy="56" r={radius} fill="none" stroke="currentColor" strokeWidth="11" strokeLinecap="round" className="text-violet-500" strokeDasharray={circumference} strokeDashoffset={circumference * (1 - Math.min(value, 100) / 100)} /></svg><span className="absolute inset-0 flex items-center justify-center text-lg font-black text-slate-900 dark:text-white">{value}%</span></div>; }
function Nudge({ icon, title, text, link }: { icon: React.ReactNode; title: string; text: string; link: string }) {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;
  return <div className="dashboard-nudge dashboard-panel flex items-start gap-4"><div className="dashboard-nudge-icon">{icon}</div><div className="flex-1"><h3 className="font-black text-slate-900 dark:text-white">{title}</h3><p className="mt-1 text-sm text-slate-500">{text}</p><Link to="/transactions" className="dashboard-link mt-3">{link} <ArrowRight size={15} /></Link></div><button onClick={() => setDismissed(true)} className="text-slate-400 transition-colors hover:text-slate-700" aria-label="Dismiss"><X size={18} /></button></div>;
}
