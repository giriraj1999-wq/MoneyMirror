import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Transactions from '@/pages/Transactions'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Dining Out', is_essential: false, is_fixed: false, type: 'expense' as const, created_at: '' },
  ],
  budgets: [],
  transactions: [
    {
      id: 't-1',
      user_id: 'user-1',
      plan_id: 'plan-1',
      category_id: 'cat-1',
      amount: 7500,
      type: 'expense' as const,
      txn_date: '2026-09-01',
      note: 'Team dinner',
      source: 'manual' as const,
      currency: 'INR',
      bill_url: null,
      bill_path: null, commitment_id: null, amount_base: 7500, created_at: '', updated_at: '',
    },
  ],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Transactions — Split invite preserves currency', () => {
  beforeEach(() => {
    vi.restoreAllMocks()
    mockUseMonthData.mockReturnValue(defaultProps)
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('sends share_currency and share_amount_base to the split-invite edge function', { timeout: 30000 }, async () => {
    const user = userEvent.setup()


    let capturedBody: any = null

    vi.stubGlobal('fetch', vi.fn().mockImplementation(async (url: string, opts: any) => {
      if (url.includes('split-invite')) {
        capturedBody = JSON.parse(opts.body)

        return {
          ok: true,
          json: async () => ({
            success: true,
            results: [],
            email_sent: true,
            summary: { total: 1, sent: 1, failed: 0 },
          }),
        } as any
      }
      if (url.includes('currency-convert')) {
        return {
          ok: true,
          json: async () => ({ amount: 90, rate: 0.012 }),
        } as any
      }
      return { ok: true, json: async () => ({}) } as any
    }))

    // Mock window.location.origin to a non-localhost URL
    Object.defineProperty(window, 'location', {
      value: { origin: 'https://moneymirror.app', href: 'https://moneymirror.app' },
      writable: true,
    })

    render(<Transactions />)

    // Open the split modal for the expense transaction
    const splitButton = screen.getByText('Split')
    await user.click(splitButton)

    // Fill in partner email
    const emailInput = screen.getByPlaceholderText('friend@example.com')
    await user.type(emailInput, 'partner@test.com')

    // Change partner currency to USD
    const currencySelect = screen.getByTitle("Partner's currency")
    await user.selectOptions(currencySelect, 'USD')

    // Enter amount in USD
    const amountInput = screen.getByPlaceholderText('0')
    await user.type(amountInput, '100')

    // Wait for conversion to complete
    await waitFor(() => {
      expect(screen.getByText(/Convert to/)).toBeInTheDocument()
    }, { timeout: 5000 })

    // Click the convert button
    const convertBtn = screen.getByText(/Convert to/)
    await user.click(convertBtn)

    // Wait for conversion result
    await waitFor(() => {
      expect(screen.getByText(/≈/)).toBeInTheDocument()
    }, { timeout: 5000 })

    // Submit the split
    const sendButton = screen.getByText(/Send 1 Invite/)
    await user.click(sendButton)

    await waitFor(() => {
      expect(capturedBody).not.toBeNull()
    }, { timeout: 5000 })

    // Verify the edge function received currency fields
    expect(capturedBody.partners).toBeDefined()
    expect(capturedBody.partners).toHaveLength(1)
    expect(capturedBody.partners[0].share_currency).toBe('USD')
    expect(capturedBody.partners[0].share_amount_base).toBe(90)
    expect(capturedBody.partners[0].share_amount).toBe(100)
  })

  it('prevents split when total shares exceed the expense amount', async () => {
    const user = userEvent.setup()

    Object.defineProperty(window, 'location', {
      value: { origin: 'https://moneymirror.app', href: 'https://moneymirror.app' },
      writable: true,
    })

    render(<Transactions />)

    const splitButton = screen.getByText('Split')
    await user.click(splitButton)

    const emailInput = screen.getByPlaceholderText('friend@example.com')
    await user.type(emailInput, 'partner@test.com')

    const amountInput = screen.getByPlaceholderText('0')
    await user.type(amountInput, '99999')

    // The send button should be disabled because shares exceed the expense
    const sendButton = screen.getByText(/Send 1 Invite/)
    expect(sendButton).toBeDisabled()
  })
})
