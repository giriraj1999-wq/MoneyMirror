import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Check,
  ChevronRight,
  CircleHelp,
  Crown,
  SlidersHorizontal,
  Sparkles,
  X,
} from 'lucide-react';
import { useMonthData } from '@/hooks/useMonthData';
import { computeAAC, simulateExpense } from '@/lib/moneyEngine';
import { formatCurrency, getCurrencySymbol } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import { supabase } from '@/lib/supabase';
import VerdictBadge from '@/components/shared/VerdictBadge';

const MONTHS = ['Oct 26', 'Nov 26', 'Dec 26', 'Jan 27', 'Feb 27', 'Mar 27'];
const INVESTMENT_MONTHS = ['2026', '2027', '2028', '2029', '2030'];

function formatMoney(value: number, currency: string): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency,
    maximumFractionDigits: 2,
  }).format(Math.max(0, value));
}

function points(values: number[], width = 520, height = 220): string {
  const max = Math.max(...values, 1) * 1.08;
  return values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * width;
      const y = height - (value / max) * height;
      return `${x},${y}`;
    })
    .join(' ');
}

function areaPath(values: number[], width = 520, height = 220): string {
  return `M 0 ${height} L ${points(values, width, height).replace(/ /g, ' L ')} L ${width} ${height} Z`;
}

function SliderRow({
  label,
  value,
  min,
  max,
  step,
  display,
  tone,
  currencySymbol,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display: string;
  tone: 'violet' | 'green' | 'red';
  currencySymbol: string;
  onChange: (value: number) => void;
}) {
  return (
    <div className="simulator-control-row">
      <div className="flex items-center justify-between gap-4">
        <label className="text-sm font-bold text-slate-900 dark:text-slate-100">{label}</label>
        <span className={`simulator-control-value is-${tone}`}>{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-label={label}
        onChange={(event) => onChange(Number(event.target.value))}
        className={`simulator-range is-${tone}`}
      />
      <div className="flex justify-between text-[11px] font-semibold text-slate-400">
        <span>{min === 0 ? `${currencySymbol}0` : `${currencySymbol}${min.toLocaleString('en-IN')}`}</span>
        <span>{currencySymbol}{max.toLocaleString('en-IN')}</span>
      </div>
    </div>
  );
}

function TrajectoryChart({ current, simulated, currency }: { current: number[]; simulated: number[]; currency: string }) {
  const width = 520;
  const height = 220;
  const max = Math.max(...current, ...simulated, 1) * 1.08;
  const yLabel = (ratio: number) => formatMoney((max * ratio) / 100, currency).replace('.00', '');

  return (
    <div className="simulator-chart-wrap">
      <svg viewBox={`0 0 ${width} ${height + 38}`} className="simulator-chart" role="img" aria-label="Before and after savings trajectory">
        {[0, 25, 50, 75, 100].map((ratio) => {
          const y = height - (ratio / 100) * height;
          return (
            <g key={ratio}>
              <line x1="0" y1={y} x2={width} y2={y} className="simulator-chart-grid" />
              <text x="0" y={Math.max(11, y - 6)} className="simulator-chart-label">{yLabel(ratio)}</text>
            </g>
          );
        })}
        <path d={areaPath(simulated, width, height)} className="simulator-chart-area" />
        <polyline points={points(current, width, height)} className="simulator-chart-line is-current" />
        <polyline points={points(simulated, width, height)} className="simulator-chart-line is-simulated" />
        {MONTHS.map((month, index) => {
          const x = (index / (MONTHS.length - 1)) * width;
          return <text key={month} x={x} y={height + 24} textAnchor={index === 0 ? 'start' : index === MONTHS.length - 1 ? 'end' : 'middle'} className="simulator-chart-month">{month}</text>;
        })}
      </svg>
      <div className="simulator-chart-legend">
        <span><i className="is-current" />Current plan</span>
        <span><i className="is-simulated" />Simulated plan</span>
      </div>
    </div>
  );
}

function InvestmentChart({ currencySymbol }: { currencySymbol: string }) {
  const best = [12000, 34000, 62000, 98000, 148000];
  const median = [12000, 29000, 50000, 72000, 108000];
  const worst = [12000, 24000, 39000, 55000, 83000];
  const width = 520;
  const height = 190;
  const max = 165000;

  const line = (values: number[]) => values.map((value, index) => `${(index / 4) * width},${height - (value / max) * height}`).join(' ');

  return (
    <div className="simulator-investment-chart">
      <svg viewBox={`0 0 ${width} ${height + 34}`} className="simulator-chart" role="img" aria-label="Five year investment growth projection">
        {[0, 40000, 80000, 120000, 160000].map((value) => {
          const y = height - (value / max) * height;
          return <g key={value}><line x1="0" y1={y} x2={width} y2={y} className="simulator-chart-grid" /><text x="0" y={Math.max(11, y - 5)} className="simulator-chart-label">{currencySymbol}{value / 1000}k</text></g>;
        })}
        <polyline points={line(best)} className="investment-line is-best" />
        <polyline points={line(median)} className="investment-line is-median" />
        <polyline points={line(worst)} className="investment-line is-worst" />
        {INVESTMENT_MONTHS.map((year, index) => <text key={year} x={(index / 4) * width} y={height + 24} textAnchor={index === 0 ? 'start' : index === 4 ? 'end' : 'middle'} className="simulator-chart-month">{year}</text>)}
      </svg>
      <div className="simulator-chart-legend investment-legend">
        <span><i className="is-best" />Best 90th</span>
        <span><i className="is-median" />Median 50th</span>
        <span><i className="is-worst" />Worst 10th</span>
      </div>
    </div>
  );
}

export default function Simulator() {
  const navigate = useNavigate();
  const { loading, plan, categories, budgets, transactions, commitments } = useMonthData();
  const { currency } = useDisplayCurrency();
  const currencySymbol = getCurrencySymbol(currency);
  const [incomeChange, setIncomeChange] = useState(0);
  const [diningCut, setDiningCut] = useState(25);
  const [largeExpense, setLargeExpense] = useState(0);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [showApplyConfirm, setShowApplyConfirm] = useState(false);
  const [applying, setApplying] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [purchaseResult, setPurchaseResult] = useState<ReturnType<typeof simulateExpense> | null>(null);

  const aacResult = useMemo(
    () => computeAAC(plan, transactions, commitments, categories, budgets),
    [plan, transactions, commitments, categories, budgets]
  );

  const actualSavingsBase = useMemo(() => {
    const expectedIncome = plan?.expected_income ?? 0;
    const expenses = transactions.filter((t) => t.type === 'expense').reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
    const reimbursements = transactions.filter((t) => t.type === 'reimbursement').reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
    return Math.max(0, expectedIncome - expenses + reimbursements);
  }, [plan, transactions]);

  const diningBudget = useMemo(() => {
    const diningCategory = categories.find((category) => category.name.toLowerCase().includes('dining'));
    return diningCategory ? budgets.find((budget) => budget.category_id === diningCategory.id)?.planned_amount ?? 0 : 450;
  }, [categories, budgets]);

  const monthlyBenefit = incomeChange + (diningBudget * diningCut) / 100;
  const currentTrajectory = useMemo(() => MONTHS.map((_, index) => Math.max(0, aacResult.aac + index * Math.max(0, aacResult.aac * 0.06))), [aacResult.aac]);
  const simulatedTrajectory = useMemo(() => MONTHS.map((_, index) => Math.max(0, aacResult.aac + index * (Math.max(0, aacResult.aac * 0.06) + monthlyBenefit) - (index === 0 ? largeExpense : 0))), [aacResult.aac, largeExpense, monthlyBenefit]);
  const goalShift = Math.max(0, largeExpense - monthlyBenefit * 3);
  const monthsMoved = goalShift > 0 ? Math.ceil(goalShift / Math.max(1, monthlyBenefit + 1)) : 0;
  const simulatedSavingsRate = plan && plan.expected_income > 0
    ? Math.max(0, Math.round(((actualSavingsBase + monthlyBenefit) / plan.expected_income) * 100))
    : 0;
  const currentSavingsRate = plan && plan.expected_income > 0
    ? Math.max(0, Math.round((actualSavingsBase / plan.expected_income) * 100))
    : 0;

  const diningCategory = categories.find((category) => category.name.toLowerCase().includes('dining'));
  const diningBudgetRow = diningCategory ? budgets.find((budget) => budget.category_id === diningCategory.id) : undefined;

  const handlePurchaseCheck = () => {
    const proposed = Number(amount);
    if (proposed > 0) setPurchaseResult(simulateExpense(aacResult.aac, proposed));
  };

  const handleApplyScenario = async () => {
    if (!plan) return;
    setApplying(true);
    setApplyError(null);

    const { error: planError } = await supabase
      .from('plans')
      .update({
        expected_income: plan.expected_income + incomeChange,
        opening_balance: Math.max(0, plan.opening_balance - largeExpense),
        updated_at: new Date().toISOString(),
      })
      .eq('id', plan.id);

    if (planError) {
      setApplyError(planError.message);
      setApplying(false);
      return;
    }

    if (diningBudgetRow) {
      const { error: budgetError } = await supabase
        .from('budgets')
        .update({
          planned_amount: Math.max(0, diningBudgetRow.planned_amount - (diningBudget * diningCut) / 100),
        })
        .eq('id', diningBudgetRow.id);

      if (budgetError) {
        setApplyError(budgetError.message);
        setApplying(false);
        return;
      }
    }

    setApplying(false);
    setShowApplyConfirm(false);
    navigate('/plan', { state: { scenarioApplied: true } });
  };

  if (loading) return <div className="flex h-full items-center justify-center text-sm text-slate-500">Loading simulator...</div>;

  if (!plan) {
    return <div className="max-w-2xl"><h1 className="mb-6 text-xl font-bold text-slate-900 dark:text-slate-100">Financial Simulator</h1><div className="card p-8 text-center"><p className="text-sm text-slate-500 dark:text-slate-400">Create a monthly plan before running a simulation.</p><Link to="/plan" className="btn btn-primary mt-4">Create a Plan <ArrowRight size={18} /></Link></div></div>;
  }

  return (
    <div className="simulator-page">
      <section className="simulator-hero">
        <div className="simulator-eyebrow"><SlidersHorizontal size={16} /> Tactile planning sandbox</div>
        <h1>Financial Simulator</h1>
        <p>Test "what-if" scenarios live with instant trajectory overlays before modifying your actual plan.</p>
      </section>

      <section className="simulator-insight">
        <div className="simulator-insight-icon"><Sparkles size={22} /></div>
        <div className="min-w-0 flex-1"><p className="simulator-insight-label">Goal impact prediction</p><p className="simulator-insight-copy">{`This scenario ${monthsMoved ? `moves your next goal target by ${monthsMoved} month${monthsMoved > 1 ? 's' : ''}` : 'keeps your next goal target on schedule'}. Savings rate shifts from ${currentSavingsRate}% to ${simulatedSavingsRate}%.`}</p></div>
        <button onClick={() => setShowApplyConfirm(true)} className="simulator-black-button">Apply to Plan <ArrowRight size={17} /></button>
      </section>

      <div className="simulator-workspace">
        <section className="simulator-panel simulator-controls">
          <div className="simulator-panel-heading"><div><p className="simulator-panel-kicker"><SlidersHorizontal size={16} /> "What if..." live controls</p><h2>Shape the month</h2></div><span className="simulator-live-dot">Live</span></div>
          <SliderRow label="Change income" value={incomeChange} min={0} max={30000} step={500} display={`+${formatCurrency(incomeChange, currency)}/mo`} tone="violet" currencySymbol={currencySymbol} onChange={setIncomeChange} />
          <SliderRow label="Cut dining out budget" value={diningCut} min={0} max={50} step={5} display={`-${diningCut}%  (${formatMoney((diningBudget * diningCut) / 100, currency)}/mo)`} tone="green" currencySymbol={currencySymbol} onChange={setDiningCut} />
          <SliderRow label="One-time large expense" value={largeExpense} min={0} max={200000} step={5000} display={formatMoney(largeExpense, currency)} tone="red" currencySymbol={currencySymbol} onChange={setLargeExpense} />
          <div className="simulator-control-summary"><span>Scenario improvement</span><strong>{formatMoney(monthlyBenefit, currency)} <small>per month</small></strong></div>
        </section>

        <section className="simulator-panel simulator-trajectory">
          <div className="simulator-panel-heading"><div><p className="simulator-panel-kicker">Before / after trajectory overlay</p><h2>Available money over time</h2></div><span className="simulator-live-badge">Live simulation</span></div>
          <TrajectoryChart current={currentTrajectory} simulated={simulatedTrajectory} currency={currency} />
        </section>
      </div>

      <section className="simulator-investment-panel">
        <div className="simulator-investment-header"><div className="flex items-start gap-3"><div className="simulator-crown"><Crown size={22} /></div><div><div className="flex flex-wrap items-center gap-2"><h2>Investment Projection</h2><span className="simulator-plus-badge">Plus</span></div><p>1,000 statistical market scenario simulations</p></div></div><button onClick={() => setShowUpgrade(true)} className="simulator-purple-button">Upgrade settings <ChevronRight size={17} /></button></div>
        <div className="simulator-investment-content"><div><p className="simulator-chart-title">5-year growth percentile range</p><InvestmentChart currencySymbol={currencySymbol} /></div><div className="simulator-allocation"><p className="simulator-chart-title">Target asset allocation</p><div className="simulator-donut" /><div className="simulator-allocation-legend"><span><i className="is-bonds" />Bonds &amp; Cash</span><span><i className="is-index" />Global Index</span><span><i className="is-tech" />Tech Growth</span></div></div></div>
      </section>

      <section className="simulator-purchase card">
        <div className="simulator-purchase-heading"><div><p className="simulator-panel-kicker"><CircleHelp size={16} /> Existing safety check</p><h2>Can I spend this?</h2><p>Run one purchase against your current available money, without changing this scenario.</p></div><div className="simulator-purchase-aac"><span>Available after commitments</span><strong>{formatCurrency(aacResult.aac, currency)}</strong></div></div>
        <div className="flex flex-col gap-3 sm:flex-row"><div className="relative flex-1"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">{currencySymbol}</span><input type="number" min="1" value={amount} onChange={(event) => setAmount(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && handlePurchaseCheck()} className="input pl-7" placeholder="Enter an amount" /></div><button onClick={handlePurchaseCheck} disabled={!amount || Number(amount) <= 0} className="btn btn-primary">Check <ArrowRight size={18} /></button></div>
        {purchaseResult && <div className={`simulator-purchase-result ${purchaseResult.verdict === 'SHORTFALL' ? 'is-danger' : 'is-safe'}`}><div><strong>{purchaseResult.verdict === 'SHORTFALL' ? 'Shortfall' : 'Plan holds'}</strong><p>Before {formatCurrency(purchaseResult.before, currency)} · After {formatCurrency(purchaseResult.after, currency)}</p></div><VerdictBadge verdict={purchaseResult.verdict} size="lg" /></div>}
      </section>

      {showApplyConfirm && <div className="simulator-modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && !applying && setShowApplyConfirm(false)}><div className="simulator-confirm-modal"><button onClick={() => setShowApplyConfirm(false)} disabled={applying} className="simulator-close-button" aria-label="Close"><X size={20} /></button><div className="simulator-confirm-icon"><SlidersHorizontal size={24} /></div><span className="simulator-modal-tag">Update your existing plan</span><h2>Apply this scenario?</h2><p>This will update the current month’s plan with the values from your simulation.</p><div className="simulator-confirm-summary"><div><span>Monthly income</span><strong>{formatCurrency(plan.expected_income, currency)} → {formatCurrency(plan.expected_income + incomeChange, currency)}</strong></div><div><span>Dining budget</span><strong>{formatCurrency(diningBudget, currency)} → {formatCurrency(Math.max(0, diningBudget - (diningBudget * diningCut) / 100), currency)}</strong></div><div><span>Opening balance</span><strong>{formatCurrency(plan.opening_balance, currency)} → {formatCurrency(Math.max(0, plan.opening_balance - largeExpense), currency)}</strong></div></div>{applyError && <div className="simulator-confirm-error">Could not apply the scenario. Please try again.</div>}<div className="simulator-confirm-actions"><button onClick={() => setShowApplyConfirm(false)} disabled={applying} className="simulator-cancel-button">Keep simulation</button><button onClick={handleApplyScenario} disabled={applying} className="simulator-trial-button">{applying ? 'Applying...' : 'Yes, apply to plan'} <ArrowRight size={17} /></button></div></div></div>}
      {showUpgrade && <div className="simulator-modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && setShowUpgrade(false)}><div className="simulator-upgrade-modal"><button onClick={() => setShowUpgrade(false)} className="simulator-close-button" aria-label="Close"><X size={20} /></button><div className="simulator-modal-crown"><Crown size={32} /></div><span className="simulator-modal-tag">Plus feature</span><h2>Upgrade your planning sandbox</h2><p>Unlock deeper market scenarios and automated rebalancing tools.</p><div className="simulator-feature-list">{['Full Monte Carlo 10,000 iteration simulations', 'Unlimited shared expense groups', 'Automated subscription cancellation concierge'].map((feature) => <div key={feature}><Check size={18} /> <span>{feature}</span></div>)}</div><button onClick={() => setShowUpgrade(false)} className="simulator-trial-button">Start 14-day free trial</button></div></div>}
    </div>
  );
}
