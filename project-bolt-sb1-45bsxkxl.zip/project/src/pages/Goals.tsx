import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { formatCurrency, formatDate } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import type { FinancialGoal } from '@/types';
import Modal from '@/components/ui/Modal';
import {
  Target,
  Plus,
  Trash2,
  Pencil,
  TrendingUp,
  Calendar,
  CheckCircle2,
  AlertTriangle,
  Clock,
} from 'lucide-react';

type GoalStatus = 'on-track' | 'behind' | 'achieved' | 'at-risk';

function getGoalStatus(goal: FinancialGoal): {
  status: GoalStatus;
  label: string;
  pct: number;
  monthsLeft: number;
  requiredPace: number;
} {
  const now = new Date();
  const target = new Date(goal.target_date + 'T00:00:00');
  const monthsLeft = Math.max(
    0,
    (target.getFullYear() - now.getFullYear()) * 12 +
      (target.getMonth() - now.getMonth())
  );
  const remaining = Math.max(0, goal.target_amount - goal.current_amount);
  const requiredPace = monthsLeft > 0 ? remaining / monthsLeft : remaining;
  const pct = Math.min(
    100,
    goal.target_amount > 0
      ? Math.round((goal.current_amount / goal.target_amount) * 100)
      : 0
  );

  if (pct >= 100) return { status: 'achieved', label: 'Achieved', pct, monthsLeft, requiredPace };

  const daysLeft = Math.ceil((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

  if (monthsLeft === 0 && remaining > 0)
    return { status: 'at-risk', label: 'At risk', pct, monthsLeft, requiredPace };
  if (daysLeft <= 15 && goal.actual_pace < requiredPace)
    return { status: 'at-risk', label: 'At risk', pct, monthsLeft, requiredPace };
  if (goal.actual_pace >= requiredPace && goal.actual_pace > 0)
    return { status: 'on-track', label: 'On track', pct, monthsLeft, requiredPace };
  return { status: 'behind', label: 'Behind', pct, monthsLeft, requiredPace };
}

const statusConfig: Record<
  GoalStatus,
  { badge: string; dot: string; icon: typeof CheckCircle2 }
> = {
  'on-track': {
    badge: 'badge badge-green',
    dot: 'bg-emerald-500',
    icon: TrendingUp,
  },
  behind: {
    badge: 'badge badge-blue',
    dot: 'bg-blue-500',
    icon: Clock,
  },
  achieved: {
    badge: 'badge badge-green',
    dot: 'bg-emerald-600',
    icon: CheckCircle2,
  },
  'at-risk': {
    badge: 'badge badge-red',
    dot: 'bg-red-500',
    icon: AlertTriangle,
  },
};

interface GoalFormState {
  title: string;
  target_date: string;
  target_amount: string;
  current_amount: string;
  actual_pace: string;
}

const emptyForm: GoalFormState = {
  title: '',
  target_date: '',
  target_amount: '',
  current_amount: '0',
  actual_pace: '0',
};

export default function Goals() {
  const { session } = useAuth();
  const { currency } = useDisplayCurrency();
  const [goals, setGoals] = useState<FinancialGoal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<GoalFormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<FinancialGoal | null>(null);

  const fetchGoals = useCallback(async () => {
    if (!session?.user) return;
    setLoading(true);
    const { data, error: err } = await supabase
      .from('financial_goals')
      .select('*')
      .order('target_date', { ascending: true });
    if (err) {
      setError(err.message);
    } else {
      setGoals((data as FinancialGoal[]) ?? []);
    }
    setLoading(false);
  }, [session?.user]);

  useEffect(() => {
    fetchGoals();
  }, [fetchGoals]);

  const openCreate = () => {
    setEditingId(null);
    setForm(emptyForm);
    setError(null);
    setModalOpen(true);
  };

  const openEdit = (goal: FinancialGoal) => {
    setEditingId(goal.id);
    setForm({
      title: goal.title,
      target_date: goal.target_date,
      target_amount: String(goal.target_amount),
      current_amount: String(goal.current_amount),
      actual_pace: String(goal.actual_pace),
    });
    setError(null);
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!session?.user) return;
    const title = form.title.trim();
    if (!title) {
      setError('Goal name is required');
      return;
    }
    if (!form.target_date) {
      setError('Target date is required');
      return;
    }
    const targetAmount = Number(form.target_amount);
    if (!targetAmount || targetAmount <= 0) {
      setError('Target amount must be greater than zero');
      return;
    }
    setSaving(true);
    setError(null);

    const payload = {
      title,
      target_date: form.target_date,
      target_amount: targetAmount,
      current_amount: Number(form.current_amount) || 0,
      actual_pace: Number(form.actual_pace) || 0,
      updated_at: new Date().toISOString(),
    };

    try {
      if (editingId) {
        const { error: updateErr } = await supabase
          .from('financial_goals')
          .update(payload)
          .eq('id', editingId);
        if (updateErr) throw updateErr;
      } else {
        const { error: insertErr } = await supabase
          .from('financial_goals')
          .insert({ ...payload, user_id: session.user.id })
          .select('*')
          .single();
        if (insertErr) throw insertErr;
      }
      setModalOpen(false);
      await fetchGoals();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save goal');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    const { error: deleteErr } = await supabase
      .from('financial_goals')
      .delete()
      .eq('id', id);
    if (deleteErr) {
      setError(deleteErr.message);
      return;
    }
    setGoals(goals.filter((g) => g.id !== id));
    setDeleteTarget(null);
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">Loading goals...</div>
      </div>
    );
  }

  const totalTarget = goals.reduce((s, g) => s + g.target_amount, 0);
  const totalSaved = goals.reduce((s, g) => s + g.current_amount, 0);
  const overallPct =
    totalTarget > 0 ? Math.min(100, Math.round((totalSaved / totalTarget) * 100)) : 0;

  return (
    <div className="space-y-6">
      {/* Summary header */}
      <div className="card p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400">
              <Target size={24} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                Your Financial Goals
              </h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                {goals.length} {goals.length === 1 ? 'goal' : 'goals'} ·{' '}
                {formatCurrency(totalSaved, currency)} of {formatCurrency(totalTarget, currency)} saved
              </p>
            </div>
          </div>
          <button onClick={openCreate} className="btn btn-primary w-fit">
            <Plus size={18} />
            New Goal
          </button>
        </div>

        {goals.length > 0 && (
          <div className="mt-5">
            <div className="mb-1.5 flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
              <span>Overall progress</span>
              <span>{overallPct}%</span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-blue-600 transition-all duration-500"
                style={{ width: `${overallPct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
      )}

      {/* Empty state */}
      {goals.length === 0 ? (
        <div className="card flex flex-col items-center justify-center p-12 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400 dark:bg-slate-800">
            <Target size={32} />
          </div>
          <h3 className="mt-4 text-base font-semibold text-slate-900 dark:text-slate-100">
            No goals yet
          </h3>
          <p className="mt-1 max-w-sm text-sm text-slate-500 dark:text-slate-400">
            Set a savings target — like an emergency fund, a vacation, or a down payment —
            and track your progress over time.
          </p>
          <button onClick={openCreate} className="btn btn-primary mt-5">
            <Plus size={18} />
            Add your first goal
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {goals.map((goal) => {
            const info = getGoalStatus(goal);
            const cfg = statusConfig[info.status];
            const StatusIcon = cfg.icon;
            return (
              <div
                key={goal.id}
                className="card card-hover group relative flex flex-col p-5"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate text-base font-bold text-slate-900 dark:text-slate-100">
                      {goal.title}
                    </h3>
                    <p className="mt-0.5 flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                      <Calendar size={13} />
                      {formatDate(goal.target_date)}
                    </p>
                  </div>
                  <span className={`${cfg.badge} shrink-0`}>
                    <StatusIcon size={13} />
                    {info.label}
                  </span>
                </div>

                {/* Amount */}
                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <p className="text-2xl font-black tracking-tight text-slate-900 dark:text-slate-100">
                      {formatCurrency(goal.current_amount, currency)}
                    </p>
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      of {formatCurrency(goal.target_amount, currency)}
                    </p>
                  </div>
                  <p className="text-2xl font-black tracking-tight text-slate-400 dark:text-slate-600">
                    {info.pct}%
                  </p>
                </div>

                {/* Progress bar */}
                <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      info.status === 'at-risk'
                        ? 'bg-red-500'
                        : info.status === 'achieved'
                        ? 'bg-emerald-600'
                        : 'bg-blue-600'
                    }`}
                    style={{ width: `${info.pct}%` }}
                  />
                </div>

                {/* Footer stats */}
                <div className="mt-4 grid grid-cols-2 gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
                  <div>
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      Monthly pace
                    </p>
                    <p className="mt-0.5 text-sm font-bold text-slate-900 dark:text-slate-100">
                      {formatCurrency(goal.actual_pace, currency)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                      Required pace
                    </p>
                    <p
                      className={`mt-0.5 text-sm font-bold ${
                        goal.actual_pace >= info.requiredPace
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}
                    >
                      {formatCurrency(info.requiredPace, currency)}
                    </p>
                  </div>
                </div>

                {/* Actions */}
                <div className="mt-4 flex items-center gap-2">
                  <button
                    onClick={() => openEdit(goal)}
                    className="btn btn-secondary flex-1 !py-2 text-xs"
                  >
                    <Pencil size={14} />
                    Edit
                  </button>
                  <button
                    onClick={() => setDeleteTarget(goal)}
                    className="btn-ghost btn !p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                    title="Delete goal"
                    aria-label="Delete goal"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create / Edit modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingId ? 'Edit Goal' : 'New Goal'}
      >
        <div className="space-y-4">
          {error && (
            <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
          )}
          <div>
            <label className="label" htmlFor="goal-title">
              Goal name
            </label>
            <input
              id="goal-title"
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="input"
              placeholder="e.g. Emergency Fund"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label" htmlFor="goal-date">
                Target date
              </label>
              <input
                id="goal-date"
                type="date"
                value={form.target_date}
                onChange={(e) => setForm({ ...form, target_date: e.target.value })}
                className="input"
              />
            </div>
            <div>
              <label className="label" htmlFor="goal-target">
                Target amount
              </label>
              <input
                id="goal-target"
                type="number"
                min="0"
                value={form.target_amount}
                onChange={(e) => setForm({ ...form, target_amount: e.target.value })}
                className="input"
                placeholder="50000"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label" htmlFor="goal-current">
                Already saved
              </label>
              <input
                id="goal-current"
                type="number"
                min="0"
                value={form.current_amount}
                onChange={(e) => setForm({ ...form, current_amount: e.target.value })}
                className="input"
                placeholder="0"
              />
            </div>
            <div>
              <label className="label" htmlFor="goal-pace">
                Monthly contribution
              </label>
              <input
                id="goal-pace"
                type="number"
                min="0"
                value={form.actual_pace}
                onChange={(e) => setForm({ ...form, actual_pace: e.target.value })}
                className="input"
                placeholder="5000"
              />
            </div>
          </div>
          <button
            onClick={handleSave}
            disabled={saving}
            className="btn btn-primary w-full"
          >
            {saving ? 'Saving...' : editingId ? 'Save Changes' : 'Create Goal'}
          </button>
        </div>
      </Modal>

      {deleteTarget && (
        <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete goal?">
          <div className="space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              This will permanently delete "{deleteTarget.title}" and all its progress. This cannot be undone.
            </p>
            {error && <div className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}
            <div className="flex gap-2">
              <button onClick={() => setDeleteTarget(null)} className="btn btn-secondary flex-1">
                Cancel
              </button>
              <button onClick={() => handleDelete(deleteTarget.id)} className="btn btn-primary flex-1 !bg-red-600 hover:!bg-red-700">
                <Trash2 size={18} /> Delete
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
