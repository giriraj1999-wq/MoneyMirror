import { useState } from 'react';
import { useMonthData } from '@/hooks/useMonthData';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { formatCurrency, formatDate, getCurrencySymbol } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import Modal from '@/components/ui/Modal';
import EmptyState from '@/components/shared/EmptyState';
import { Link } from 'react-router-dom';
import {
  Plus,
  Pencil,
  Trash2,
  CalendarClock,
  Check,
  X,
  ArrowRight,
} from 'lucide-react';
import type { Commitment } from '@/types';

export default function Commitments() {
  const { session } = useAuth();
  const { currency } = useDisplayCurrency();
  const {
    month,
    loading,
    plan,
    commitments,
    refetch,
    ensurePlan,
    setCommitments,
  } = useMonthData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Commitment | null>(null);
  const [form, setForm] = useState({
    title: '',
    amount: '',
    due_date: new Date().toISOString().slice(0, 10),
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Commitment | null>(null);

  const openAdd = () => {
    setEditing(null);
    setForm({ title: '', amount: '', due_date: new Date().toISOString().slice(0, 10) });
    setModalOpen(true);
  };

  const openEdit = (c: Commitment) => {
    setEditing(c);
    setForm({ title: c.title, amount: String(c.amount), due_date: c.due_date });
    setModalOpen(true);
  };

  const handleSave = async () => {
    const amount = Number(form.amount);
    if (!form.amount || isNaN(amount) || amount <= 0) {
      setError('Amount must be greater than zero');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const currentPlan = plan ?? (await ensurePlan());
      if (!currentPlan || !session?.user) throw new Error('No plan found');

      const payload = {
        user_id: session.user.id,
        plan_id: currentPlan.id,
        title: form.title.trim(),
        amount,
        due_date: form.due_date,
      };

      if (editing) {
        const { error: updateErr } = await supabase
          .from('commitments')
          .update(payload)
          .eq('id', editing.id);
        if (updateErr) throw updateErr;
      } else {
        const { error: insertErr } = await supabase
          .from('commitments')
          .insert(payload);
        if (insertErr) throw insertErr;
      }

      await refetch();
      setModalOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (c: Commitment) => {
    const { error: deleteErr } = await supabase
      .from('commitments')
      .delete()
      .eq('id', c.id);
    if (deleteErr) {
      setError(deleteErr.message);
      return;
    }
    setCommitments(commitments.filter((x) => x.id !== c.id));
    setDeleteTarget(null);
  };

  const handleTogglePaid = async (c: Commitment) => {
    if (!session?.user) return;
    const newPaid = !c.is_paid;
    try {
      if (newPaid) {
        // Mark as paid: create an expense transaction linked to this commitment
        // so that currentBalance reflects the actual cash outflow (issue 8)
        // and the amount is not double-counted in AAC (issue 6).
        const { error: insertErr } = await supabase
          .from('transactions')
          .insert({
            user_id: session.user.id,
            plan_id: c.plan_id,
            category_id: null,
            amount: c.amount,
            amount_base: c.amount,
            type: 'expense',
            txn_date: c.due_date,
            note: `${c.title} (commitment payment)`,
            source: 'manual',
            currency: plan?.base_currency ?? currency,
            commitment_id: c.id,
          });

        if (insertErr) throw insertErr;

        const { error: updateErr } = await supabase
          .from('commitments')
          .update({
            is_paid: true,
            paid_at: new Date().toISOString(),
          })
          .eq('id', c.id);
        if (updateErr) throw updateErr;

        await refetch();
      } else {
        // Unmark: find and delete the linked expense transaction
        const { data: linkedTxns } = await supabase
          .from('transactions')
          .select('id')
          .eq('commitment_id', c.id)
          .eq('type', 'expense');

        if (linkedTxns && linkedTxns.length > 0) {
          for (const t of linkedTxns) {
            await supabase.from('transactions').delete().eq('id', t.id);
          }
        }

        const { error: updateErr } = await supabase
          .from('commitments')
          .update({
            is_paid: false,
            paid_at: null,
          })
          .eq('id', c.id);
        if (updateErr) throw updateErr;

        await refetch();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update commitment');
    }
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">Loading...</div>
      </div>
    );
  }

  if (!plan) {
    return (
      <div>
        <h1 className="mb-6 text-xl font-bold text-slate-900 dark:text-slate-100">Commitments</h1>
        <EmptyState
          title="No plan for this month yet"
          description="Create a monthly plan first to start tracking your commitments."
          action={
            <Link to="/plan" className="btn btn-primary">
              Create a Plan <ArrowRight size={18} />
            </Link>
          }
        />
      </div>
    );
  }

  const unpaid = commitments.filter((c) => !c.is_paid);
  const paid = commitments.filter((c) => c.is_paid);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Commitments</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {unpaid.length} unpaid · {formatCurrency(unpaid.reduce((s, c) => s + c.amount, 0), currency)}
          </p>
        </div>
        <button onClick={openAdd} className="btn btn-primary w-fit">
          <Plus size={18} />
          Add Commitment
        </button>
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}

      {commitments.length === 0 ? (
        <EmptyState
          title="No commitments yet"
          description="Add upcoming payments like rent, EMI, or insurance premiums to see how they affect your available money."
        />
      ) : (
        <div className="space-y-4">
          {unpaid.length > 0 && (
            <div>
              <h2 className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-300">
                Upcoming
              </h2>
              <div className="space-y-2">
                {unpaid.map((c) => (
                  <div
                    key={c.id}
                    className="card card-hover flex items-center gap-3 p-4"
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-50">
                      <CalendarClock size={20} className="text-amber-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {c.title}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Due {formatDate(c.due_date)}
                      </p>
                    </div>
                    <p className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {formatCurrency(c.amount, currency)}
                    </p>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleTogglePaid(c)}
                        className="btn-ghost btn !p-1.5 text-emerald-600 hover:bg-emerald-50"
                        title="Mark as paid"
                        aria-label="Mark as paid"
                      >
                        <Check size={16} />
                      </button>
                      <button
                        onClick={() => openEdit(c)}
                        className="btn-ghost btn !p-1.5"
                        aria-label="Edit commitment"
                      >
                        <Pencil size={16} />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(c)}
                        className="btn-ghost btn !p-1.5 text-red-500 hover:bg-red-50"
                        aria-label="Delete commitment"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {paid.length > 0 && (
            <div>
              <h2 className="mb-2 text-sm font-semibold text-slate-500 dark:text-slate-400">
                Paid
              </h2>
              <div className="space-y-2">
                {paid.map((c) => (
                  <div
                    key={c.id}
                    className="card flex items-center gap-3 p-4 opacity-60"
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-50">
                      <Check size={20} className="text-emerald-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-700 dark:text-slate-300 line-through">
                        {c.title}
                      </p>
                      <p className="text-xs text-slate-400 dark:text-slate-500">
                        Paid {c.paid_at ? formatDate(c.paid_at.slice(0, 10)) : ''}
                      </p>
                    </div>
                    <p className="text-sm font-bold text-slate-500 dark:text-slate-400">
                      {formatCurrency(c.amount, currency)}
                    </p>
                    <div className="flex gap-1">
                      <button
                        onClick={() => handleTogglePaid(c)}
                        className="btn-ghost btn !p-1.5"
                        title="Mark as unpaid"
                        aria-label="Mark as unpaid"
                      >
                        <X size={16} />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(c)}
                        className="btn-ghost btn !p-1.5 text-red-500 hover:bg-red-50"
                        aria-label="Delete commitment"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <Modal
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        title="Delete commitment?"
      >
        <div className="space-y-4">
          <p className="text-sm text-slate-600 dark:text-slate-400">
            This will permanently delete "{deleteTarget?.title}" ({formatCurrency(deleteTarget?.amount ?? 0, currency)}). This cannot be undone.
          </p>
          {error && <div className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}
          <div className="flex gap-2">
            <button onClick={() => setDeleteTarget(null)} className="btn btn-secondary flex-1">
              <X size={18} /> Cancel
            </button>
            <button onClick={() => deleteTarget && handleDelete(deleteTarget)} className="btn btn-primary flex-1 !bg-red-600 hover:!bg-red-700">
              <Trash2 size={18} /> Delete
            </button>
          </div>
        </div>
      </Modal>

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editing ? 'Edit Commitment' : 'Add Commitment'}
      >
        <div className="space-y-4">
          <div>
            <label className="label">Title</label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="input"
              placeholder="e.g. Car EMI, House Rent"
            />
          </div>
          <div>
            <label className="label">Amount</label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">
                {getCurrencySymbol(currency)}
              </span>
              <input
                type="number"
                min="1"
                value={form.amount}
                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                className="input pl-7"
                placeholder="0"
              />
            </div>
          </div>
          <div>
            <label className="label">Due Date</label>
            <input
              type="date"
              value={form.due_date}
              onChange={(e) => setForm({ ...form, due_date: e.target.value })}
              className="input"
            />
          </div>

          {error && (
            <div className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">
              {error}
            </div>
          )}

          <div className="flex gap-2">
            <button
              onClick={() => setModalOpen(false)}
              className="btn btn-secondary flex-1"
            >
              <X size={18} /> Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving || !form.title || !form.amount}
              className="btn btn-primary flex-1"
            >
              <Check size={18} />
              {saving ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
