import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

vi.mock('@/pages/YearlyPlan', () => ({
  default: () => <div data-testid="yearly-plan-mock">Yearly Plan</div>,
}))
vi.mock('@/pages/Goals', () => ({
  default: () => <div data-testid="goals-mock">Goals</div>,
}))
vi.mock('@/pages/MonthlyReview', () => ({
  default: () => <div data-testid="monthly-review-mock">Monthly Review</div>,
}))

import { supabase } from '@/lib/supabase'
import PlanMonth from '@/pages/PlanMonth'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
  ],
  budgets: [],
  transactions: [],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

function makeInsertChain(data: any, error: any) {
  const chain: any = {
    insert: vi.fn(() => chain),
    select: vi.fn(() => chain),
    maybeSingle: vi.fn(() => Promise.resolve({ data, error })),
  }
  return chain
}

describe('PlanMonth — Add Category', () => {
  beforeEach(() => {
    mockUseMonthData.mockReturnValue(defaultProps)
  })

  afterEach(() => {
    vi.restoreAllMocks()
    mockUseMonthData.mockReturnValue(defaultProps)
  })

  it('creates a category and clears the input on success', async () => {
    const user = userEvent.setup()
    const setCategories = vi.fn()
    mockUseMonthData.mockReturnValue({ ...defaultProps, setCategories })

    const chain = makeInsertChain(
      { id: 'cat-new', user_id: 'user-1', name: 'Check', is_essential: false, type: 'expense', created_at: '' },
      null
    )
    vi.mocked(supabase.from).mockImplementation(() => chain)

    render(<PlanMonth />)

    const input = screen.getByPlaceholderText('e.g. Petrol')
    await user.type(input, 'Check')

    const addButton = screen.getByText('Add category')
    await user.click(addButton)

    await waitFor(() => {
      expect(setCategories).toHaveBeenCalled()
    })

    await waitFor(() => {
      expect(input).toHaveValue('')
    })
  })

  it('shows an error in the categories section when insert fails with duplicate name', async () => {
    const user = userEvent.setup()
    mockUseMonthData.mockReturnValue({ ...defaultProps, setCategories: vi.fn() })

    const chain = makeInsertChain(null, {
      message: 'duplicate key value violates unique constraint',
    })
    vi.mocked(supabase.from).mockImplementation(() => chain)

    render(<PlanMonth />)

    const input = screen.getByPlaceholderText('e.g. Petrol')
    await user.type(input, 'Rent')

    const addButton = screen.getByText('Add category')
    await user.click(addButton)

    await waitFor(() => {
      expect(screen.getByText(/duplicate key/i)).toBeInTheDocument()
    })

    // Input should NOT be cleared on error
    expect(input).toHaveValue('Rent')
  })

  it('shows error when maybeSingle returns no data and no error', async () => {
    const user = userEvent.setup()
    mockUseMonthData.mockReturnValue({ ...defaultProps, setCategories: vi.fn() })

    const chain = makeInsertChain(null, null)
    vi.mocked(supabase.from).mockImplementation(() => chain)

    render(<PlanMonth />)

    const input = screen.getByPlaceholderText('e.g. Petrol')
    await user.type(input, 'TestCat')

    const addButton = screen.getByText('Add category')
    await user.click(addButton)

    await waitFor(() => {
      expect(screen.getByText('Failed to create category')).toBeInTheDocument()
    })
  })

  it('disables the Add button when category name is empty', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)

    const addButton = screen.getByText('Add category')
    expect(addButton).toBeDisabled()
  })

  it('enables the Add button when a name is entered', async () => {
    const user = userEvent.setup()
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)

    const input = screen.getByPlaceholderText('e.g. Petrol')
    await user.type(input, 'NewCat')

    const addButton = screen.getByText('Add category')
    expect(addButton).not.toBeDisabled()
  })
})
