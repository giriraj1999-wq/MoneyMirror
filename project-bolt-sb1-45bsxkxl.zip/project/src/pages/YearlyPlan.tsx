import { useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { formatCurrency, getCurrencySymbol } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import { getCarryForward } from '@/lib/carryForward';
import type { YearlyPlanSettings, VariableBudget } from '@/types';
import {
  Wallet,
  PiggyBank,
  Layers3,
  CalendarCheck,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Check,
  Plus,
  Trash2,
  TrendingUp,
  AlertTriangle,
} from 'lucide-react';

const STEPS = [
  { id: 1, label: 'Income', icon: Wallet },
  { id: 2, label: 'Savings', icon: PiggyBank },
  { id: 3, label: 'Variable Budgets', icon: Layers3 },
  { id: 4, label: 'Review', icon: CalendarCheck },
  { id: 5, label: 'Generate', icon: Sparkles },
];

const DEFAULT_VARIABLE_CATEGORIES = [
  'Groceries',
  'Dining Out',
  'Entertainment',
  'Transport',
  'Shopping',
  'Health',
];

const currentYear = new Date().getFullYear();

function formatPct(value: number): string {
  return `${Math.round(value)}%`;
}

export default function YearlyPlan() {
  const { session } = useAuth();
  const { currency } = useDisplayCurrency();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [settings, setSettings] = useState<YearlyPlanSettings | null>(null);
  const [step, setStep] = useState(1);
  const [monthlyIncome, setMonthlyIncome] = useState('0');
  const [savingsTarget, setSavingsTarget] = useState('0');
  const [variableBudgets, setVariableBudgets] = useState<VariableBudget[]>([]);
  const [newCategoryName, setNewCategoryName] = useState('');

  const fetchSettings = useCallback(async () => {
    if (!session?.user) return;
    setLoading(true);
    const { data, error: err } = await supabase
      .from('yearly_plan_settings')
      .select('*')
      .eq('user_id', session.user.id)
      .eq('plan_year', currentYear)
      .maybeSingle();

    if (err) {
      setError(err.message);
      setLoading(false);
      return;
    }

    if (data) {
      const s = data as YearlyPlanSettings;
      setSettings(s);
      setStep(s.current_step);
      setMonthlyIncome(String(s.monthly_income));
      setSavingsTarget(String(s.savings_target));
      setVariableBudgets(
        Array.isArray(s.variable_budgets) ? (s.variable_budgets as VariableBudget[]) : []
      );
    } else {
      const { data: created, error: createErr } = await supabase
        .from('yearly_plan_settings')
        .insert({
          user_id: session.user.id,
          plan_year: currentYear,
          current_step: 1,
          monthly_income: 0,
          savings_target: 0,
          variable_budgets: DEFAULT_VARIABLE_CATEGORIES.map((c) => ({
            category: c,
            amount: 0,
          })) as any,
          generated: false,
        })
        .select('*')
        .maybeSingle();

      if (createErr) {
        setError(createErr.message);
      } else if (created) {
        const s = created as YearlyPlanSettings;
        setSettings(s);
        setVariableBudgets(
          Array.isArray(s.variable_budgets) ? (s.variable_budgets as VariableBudget[]) : []
        );
      }
    }
    setLoading(false);
  }, [session?.user]);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  const persist = useCallback(
    async (patch: Partial<YearlyPlanSettings>) => {
      if (!session?.user || !settings) return;
      setSaving(true);
      setError(null);
      const { data, error: err } = await supabase
        .from('yearly_plan_settings')
        .update({
          ...patch,
          updated_at: new Date().toISOString(),
        })
        .eq('id', settings.id)
        .select('*')
        .maybeSingle();
      if (err) {
        setError(err.message);
      } else if (data) {
        setSettings(data as YearlyPlanSettings);
      }
      setSaving(false);
    },
    [session?.user, settings]
  );

  const incomeNum = Number(monthlyIncome) || 0;
  const savingsNum = Number(savingsTarget) || 0;
  const variableTotal = variableBudgets.reduce((s, v) => s + (Number(v.amount) || 0), 0);
  const annualIncome = incomeNum * 12;
  const annualSavings = savingsNum * 12;
  const annualVariable = variableTotal * 12;
  const annualFixed = Math.max(0, annualIncome - annualSavings - annualVariable);
  const monthlyFixed = annualFixed / 12;
  const savingsPct = incomeNum > 0 ? (savingsNum / incomeNum) * 100 : 0;
  const variablePct = incomeNum > 0 ? (variableTotal / incomeNum) * 100 : 0;
  const fixedPct = incomeNum > 0 ? (monthlyFixed / incomeNum) * 100 : 0;
  const isBalanced = incomeNum > 0 && savingsNum + variableTotal + monthlyFixed <= incomeNum;

  const handleAddCategory = () => {
    const name = newCategoryName.trim();
    if (!name) return;
    if (variableBudgets.some((v) => v.category.toLowerCase() === name.toLowerCase())) return;
    setVariableBudgets([...variableBudgets, { category: name, amount: 0 }]);
    setNewCategoryName('');
  };

  const handleRemoveCategory = (idx: number) => {
    setVariableBudgets(variableBudgets.filter((_, i) => i !== idx));
  };

  const handleAmountChange = (idx: number, amount: string) => {
    setVariableBudgets(
      variableBudgets.map((v, i) => (i === idx ? { ...v, amount: Number(amount) || 0 } : v))
    );
  };

  const goNext = () => {
    const next = Math.min(5, step + 1);
    setStep(next);
    persist({ current_step: next });
  };

  const goBack = () => {
    const prev = Math.max(1, step - 1);
    setStep(prev);
    persist({ current_step: prev });
  };

  const handleSaveStep = (patch: Partial<YearlyPlanSettings>, next?: boolean) => {
    if (next) {
      const nextStep = Math.min(5, step + 1);
      setStep(nextStep);
      persist({ ...patch, current_step: nextStep });
    } else {
      persist(patch);
    }
  };

  const [generating, setGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!session?.user || !settings) return;
    setGenerating(true);
    setError(null);
    try {
      // Ensure all variable-budget categories exist as expense categories
      const { data: existingCats } = await supabase
        .from('categories')
        .select('id, name, type')
        .eq('user_id', session.user.id)
        .eq('type', 'expense');

      const catMap = new Map<string, string>();
      for (const c of (existingCats as { id: string; name: string }[]) ?? []) {
        catMap.set(c.name.toLowerCase(), c.id);
      }

      const toCreate = variableBudgets.filter(
        (v) => !catMap.has(v.category.toLowerCase())
      );

      if (toCreate.length > 0) {
        const { data: newCats } = await supabase
          .from('categories')
          .insert(
            toCreate.map((v) => ({
              user_id: session.user.id,
              name: v.category,
              is_essential: false,
              is_fixed: false,
              type: 'expense',
            }))
          )
          .select('id, name');

        for (const c of (newCats as { id: string; name: string }[]) ?? []) {
          catMap.set(c.name.toLowerCase(), c.id);
        }
      }

      // Build a lookup of category id -> planned amount from yearly variable budgets
      const budgetByCategoryName = new Map<string, number>();
      for (const v of variableBudgets) {
        budgetByCategoryName.set(v.category.toLowerCase(), v.amount);
      }

      // Create 12 monthly plans for the year
      const months = Array.from({ length: 12 }, (_, i) => {
        const m = String(i + 1).padStart(2, '0');
        return `${currentYear}-${m}-01`;
      });

      for (const monthStr of months) {
        // Check if plan already exists
        const { data: existing } = await supabase
          .from('plans')
          .select('id')
          .eq('user_id', session.user.id)
          .eq('month', monthStr)
          .maybeSingle();

        let planId: string;

        if (existing) {
          planId = existing.id;
          // Update existing plan with yearly settings (keep opening_balance)
          await supabase
            .from('plans')
            .update({
              expected_income: incomeNum,
              protected_savings: savingsNum,
              updated_at: new Date().toISOString(),
            })
            .eq('id', existing.id);
        } else {
          // Carry forward opening balance from previous month
          const carry = await getCarryForward(session.user.id, monthStr);
          const { data: newPlan } = await supabase.from('plans').insert({
            user_id: session.user.id,
            month: monthStr,
            opening_balance: carry.opening_balance,
            expected_income: incomeNum,
            protected_savings: savingsNum,
          })
          .select('id')
          .maybeSingle();
          if (!newPlan) throw new Error('Failed to create plan for ' + monthStr);
          planId = (newPlan as { id: string }).id;
        }

        // Sync budgets from yearly variable budgets into this month's plan
        const { data: existingBudgets } = await supabase
          .from('budgets')
          .select('id, category_id')
          .eq('plan_id', planId);

        const existingBudgetMap = new Map<string, string>();
        for (const b of (existingBudgets as { id: string; category_id: string }[]) ?? []) {
          existingBudgetMap.set(b.category_id, b.id);
        }

        for (const v of variableBudgets) {
          const catId = catMap.get(v.category.toLowerCase());
          if (!catId) continue;
          const amount = v.amount;
          const existingBudgetId = existingBudgetMap.get(catId);
          let result;
          if (existingBudgetId) {
            result = await supabase.from('budgets').update({ planned_amount: amount }).eq('id', existingBudgetId);
          } else {
            result = await supabase.from('budgets').insert({
              plan_id: planId,
              category_id: catId,
              planned_amount: amount,
            });
          }
          if (result.error) throw new Error(result.error.message);
        }
      }

      // Mark settings as generated
      await persist({
        monthly_income: incomeNum,
        savings_target: savingsNum,
        variable_budgets: variableBudgets as any,
        generated: true,
        current_step: 5,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate yearly plan');
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">Loading yearly plan...</div>
      </div>
    );
  }

  return (
    <div className="yearly-plan-page">
      {/* Stepper */}
      <div className="yearly-plan-stepper">
        {STEPS.map((s, idx) => {
          const Icon = s.icon;
          const isActive = step === s.id;
          const isComplete = step > s.id;
          return (
            <div key={s.id} className="yearly-plan-step-wrapper">
              <button
                onClick={() => setStep(s.id)}
                className={`yearly-plan-step ${isActive ? 'is-active' : ''} ${isComplete ? 'is-complete' : ''}`}
              >
                <span className="yearly-plan-step-circle">
                  {isComplete ? <Check size={18} /> : <Icon size={18} />}
                </span>
                <span className="yearly-plan-step-label">{s.label}</span>
              </button>
              {idx < STEPS.length - 1 && (
                <span className={`yearly-plan-step-connector ${isComplete ? 'is-complete' : ''}`} />
              )}
            </div>
          );
        })}
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>
      )}

      {/* Step 1: Income */}
      {step === 1 && (
        <div className="yearly-plan-card animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="yearly-plan-step-icon">
              <Wallet size={22} />
            </div>
            <div>
              <h2 className="yearly-plan-card-title">What's your monthly income?</h2>
              <p className="yearly-plan-card-subtitle">
                Enter your net take-home pay. We'll annualize it to build your yearly envelope.
              </p>
            </div>
          </div>
          <div className="mt-6">
            <label className="label" htmlFor="monthly-income">Monthly net income</label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-slate-400">
                {getCurrencySymbol(currency)}
              </span>
              <input
                id="monthly-income"
                type="number"
                min="0"
                value={monthlyIncome}
                onChange={(e) => setMonthlyIncome(e.target.value)}
                className="input pl-8 text-lg font-semibold"
                placeholder="50000"
              />
            </div>
          </div>
          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="yearly-plan-stat">
              <span>Monthly income</span>
              <strong>{formatCurrency(incomeNum, currency)}</strong>
            </div>
            <div className="yearly-plan-stat yearly-plan-stat-accent">
              <span>Annualized income</span>
              <strong>{formatCurrency(annualIncome, currency)}</strong>
            </div>
          </div>
          <YearlyPlanFooter
            onNext={() => handleSaveStep({ monthly_income: incomeNum }, true)}
            saving={saving}
          />
        </div>
      )}

      {/* Step 2: Savings */}
      {step === 2 && (
        <div className="yearly-plan-card animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="yearly-plan-step-icon">
              <PiggyBank size={22} />
            </div>
            <div>
              <h2 className="yearly-plan-card-title">How much do you want to save?</h2>
              <p className="yearly-plan-card-subtitle">
                Set a monthly savings target. This is reserved before any spending.
              </p>
            </div>
          </div>
          <div className="mt-6">
            <label className="label" htmlFor="savings-target">Monthly savings target</label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-slate-400">
                {getCurrencySymbol(currency)}
              </span>
              <input
                id="savings-target"
                type="number"
                min="0"
                value={savingsTarget}
                onChange={(e) => setSavingsTarget(e.target.value)}
                className="input pl-8 text-lg font-semibold"
                placeholder="10000"
              />
            </div>
          </div>
          <div className="mt-5">
            <div className="mb-1.5 flex items-center justify-between text-xs font-medium text-slate-500 dark:text-slate-400">
              <span>Savings rate</span>
              <span className="font-bold text-slate-900 dark:text-slate-100">{formatPct(savingsPct)}</span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                style={{ width: `${Math.min(100, savingsPct)}%` }}
              />
            </div>
            <p className="mt-1.5 text-xs text-slate-400">
              {savingsPct >= 20
                ? 'Great rate — above the 20% benchmark.'
                : 'Aim for at least 20% of your income.'}
            </p>
          </div>
          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="yearly-plan-stat">
              <span>Monthly savings</span>
              <strong>{formatCurrency(savingsNum, currency)}</strong>
            </div>
            <div className="yearly-plan-stat yearly-plan-stat-accent">
              <span>Annual savings</span>
              <strong>{formatCurrency(annualSavings, currency)}</strong>
            </div>
          </div>
          <YearlyPlanFooter
            onBack={goBack}
            onNext={() => handleSaveStep({ savings_target: savingsNum }, true)}
            saving={saving}
          />
        </div>
      )}

      {/* Step 3: Variable Budgets */}
      {step === 3 && (
        <div className="yearly-plan-card animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="yearly-plan-step-icon">
              <Layers3 size={22} />
            </div>
            <div>
              <h2 className="yearly-plan-card-title">Set your variable budgets</h2>
              <p className="yearly-plan-card-subtitle">
                These are flexible monthly categories. Anything not covered here becomes your fixed envelope.
              </p>
            </div>
          </div>
          <div className="mt-5 flex gap-2">
            <input
              type="text"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddCategory()}
              className="input"
              placeholder="Add a category (e.g. Subscriptions)"
            />
            <button onClick={handleAddCategory} className="btn btn-secondary shrink-0">
              <Plus size={18} />
            </button>
          </div>
          <div className="mt-4 space-y-2">
            {variableBudgets.length === 0 && (
              <p className="text-sm text-slate-400 dark:text-slate-500">
                No variable categories yet. Add one above.
              </p>
            )}
            {variableBudgets.map((v, idx) => (
              <div
                key={idx}
                className="flex items-center gap-3 rounded-lg border border-slate-200 p-3 dark:border-slate-800"
              >
                <span className="flex-1 text-sm font-medium text-slate-900 dark:text-slate-100">
                  {v.category}
                </span>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">{getCurrencySymbol(currency)}</span>
                  <input
                    type="number"
                    min="0"
                    value={v.amount || ''}
                    onChange={(e) => handleAmountChange(idx, e.target.value)}
                    className="input w-32 pl-7"
                    placeholder="0"
                  />
                </div>
                <button
                  onClick={() => handleRemoveCategory(idx)}
                  className="btn-ghost btn !p-1.5 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}
          </div>
          <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="yearly-plan-stat">
              <span>Monthly variable total</span>
              <strong>{formatCurrency(variableTotal, currency)}</strong>
            </div>
            <div className="yearly-plan-stat yearly-plan-stat-accent">
              <span>Annual variable total</span>
              <strong>{formatCurrency(annualVariable, currency)}</strong>
            </div>
          </div>
          <YearlyPlanFooter
            onBack={goBack}
            onNext={() => handleSaveStep({ variable_budgets: variableBudgets as any }, true)}
            saving={saving}
          />
        </div>
      )}

      {/* Step 4: Review */}
      {step === 4 && (
        <div className="yearly-plan-card animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="yearly-plan-step-icon">
              <CalendarCheck size={22} />
            </div>
            <div>
              <h2 className="yearly-plan-card-title">Review your yearly envelope</h2>
              <p className="yearly-plan-card-subtitle">
                Here's how your income splits across savings, variable spending, and fixed costs.
              </p>
            </div>
          </div>

          {/* Allocation bar */}
          <div className="mt-6">
            <div className="mb-2 flex h-4 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="bg-emerald-500 transition-all duration-500"
                style={{ width: `${Math.min(100, savingsPct)}%` }}
                title="Savings"
              />
              <div
                className="bg-blue-500 transition-all duration-500"
                style={{ width: `${Math.min(100, variablePct)}%` }}
                title="Variable"
              />
              <div
                className="bg-slate-400 transition-all duration-500"
                style={{ width: `${Math.min(100, fixedPct)}%` }}
                title="Fixed"
              />
            </div>
            <div className="flex flex-wrap gap-4 text-xs font-medium text-slate-500 dark:text-slate-400">
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /> Savings {formatPct(savingsPct)}
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-blue-500" /> Variable {formatPct(variablePct)}
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-slate-400" /> Fixed {formatPct(fixedPct)}
              </span>
            </div>
          </div>

          {/* Summary grid */}
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="yearly-plan-stat">
              <span>Annual income</span>
              <strong>{formatCurrency(annualIncome, currency)}</strong>
            </div>
            <div className="yearly-plan-stat">
              <span>Annual savings</span>
              <strong className="text-emerald-600 dark:text-emerald-400">{formatCurrency(annualSavings, currency)}</strong>
            </div>
            <div className="yearly-plan-stat">
              <span>Annual variable</span>
              <strong className="text-blue-600 dark:text-blue-400">{formatCurrency(annualVariable, currency)}</strong>
            </div>
            <div className="yearly-plan-stat">
              <span>Annual fixed</span>
              <strong>{formatCurrency(annualFixed, currency)}</strong>
            </div>
          </div>

          {!isBalanced && incomeNum > 0 && (
            <div className="mt-4 flex items-start gap-2.5 rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-700 dark:bg-amber-900/20 dark:text-amber-400">
              <AlertTriangle size={18} className="mt-0.5 shrink-0" />
              <span>
                Your savings and variable budgets exceed your income. Adjust them before generating your plan.
              </span>
            </div>
          )}

          <YearlyPlanFooter
            onBack={goBack}
            onNext={goNext}
            saving={saving}
            nextLabel="Continue"
          />
        </div>
      )}

      {/* Step 5: Generate */}
      {step === 5 && (
        <div className="yearly-plan-card animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="yearly-plan-step-icon yearly-plan-step-icon-gold">
              <Sparkles size={22} />
            </div>
            <div>
              <h2 className="yearly-plan-card-title">Generate your yearly plan</h2>
              <p className="yearly-plan-card-subtitle">
                We'll create 12 monthly envelopes based on your inputs.
              </p>
            </div>
          </div>

          {/* Monthly envelope preview */}
          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {Array.from({ length: 12 }, (_, i) => {
              const monthName = new Date(currentYear, i, 1).toLocaleDateString('en-IN', { month: 'short' });
              return (
                <div key={i} className="yearly-plan-envelope">
                  <span className="yearly-plan-envelope-month">{monthName}</span>
                  <span className="yearly-plan-envelope-amount">{formatCurrency(monthlyFixed, currency)}</span>
                  <span className="yearly-plan-envelope-tag">Fixed</span>
                  <span className="yearly-plan-envelope-amount-secondary">{formatCurrency(savingsNum, currency)}</span>
                  <span className="yearly-plan-envelope-tag-secondary">Save</span>
                </div>
              );
            })}
          </div>

          <div className="mt-5 flex items-center gap-2.5 rounded-lg bg-emerald-50 px-4 py-3 text-sm text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400">
            <TrendingUp size={18} className="shrink-0" />
            <span>
              Projected year-end savings: <strong>{formatCurrency(annualSavings, currency)}</strong>
            </span>
          </div>

          <div className="mt-6 flex items-center justify-between gap-3">
            <button onClick={goBack} className="btn btn-secondary">
              <ChevronLeft size={18} />
              Back
            </button>
            <button
              onClick={handleGenerate}
              disabled={generating || saving}
              className="btn btn-primary"
            >
              <Sparkles size={18} />
              {generating ? 'Generating...' : settings?.generated ? 'Regenerate Yearly Plan' : 'Generate Yearly Plan'}
            </button>
          </div>

          {settings?.generated && (
            <div className="mt-4 flex items-center gap-2.5 rounded-lg bg-blue-50 px-4 py-3 text-sm text-blue-700 dark:bg-blue-900/20 dark:text-blue-400">
              <Check size={18} className="shrink-0" />
              <span>Your yearly plan for {currentYear} has been generated. Use Monthly Review to track each month.</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function YearlyPlanFooter({
  onBack,
  onNext,
  saving,
  nextLabel = 'Continue',
}: {
  onBack?: () => void;
  onNext: () => void;
  saving: boolean;
  nextLabel?: string;
}) {
  return (
    <div className="mt-6 flex items-center justify-between gap-3">
      {onBack ? (
        <button onClick={onBack} className="btn btn-secondary">
          <ChevronLeft size={18} />
          Back
        </button>
      ) : (
        <span />
      )}
      <button onClick={onNext} disabled={saving} className="btn btn-primary">
        {nextLabel}
        <ChevronRight size={18} />
      </button>
    </div>
  );
}
