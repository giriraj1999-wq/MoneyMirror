import { describe, it, expect, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Shared from '@/pages/Shared'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [],
  budgets: [],
  transactions: [
    { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: null, amount: 2000, type: 'expense' as const, txn_date: '2026-09-01', note: 'Dinner', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
  ],
  commitments: [],
  outgoingShares: [
    { id: 's-1', transaction_id: 't-1', owner_user_id: 'user-1', partner_email: 'friend@test.com', partner_user_id: 'partner-1', share_amount: 1000, share_currency: 'INR', share_amount_base: 1000, status: 'pending' as const, paid_at: null, acknowledged_at: null, settlement_txn_id: null, created_at: '', updated_at: '' },
  ],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Shared', () => {
  it('renders the Shared Expenses heading', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Shared />)
    expect(screen.getByText('Shared Expenses')).toBeInTheDocument()
  })

  it('renders outgoing shares section', async () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Shared />)
    await waitFor(() => {
      const allText = document.body.textContent ?? ''
      expect(allText).toContain('friend@test.com')
    })
  })

  it('shows loading state', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      loading: true,
    })
    render(<Shared />)
    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })

  it('shows empty state when no plan exists', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      plan: null,
    })
    render(<Shared />)
    expect(screen.getByText('No plan for this month yet')).toBeInTheDocument()
  })
})
