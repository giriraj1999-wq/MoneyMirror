import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Commitments from '@/pages/Commitments'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [],
  budgets: [],
  transactions: [],
  commitments: [
    { id: 'c-1', user_id: 'user-1', plan_id: 'plan-1', title: 'Electricity bill', amount: 2500, due_date: '2026-09-10', is_paid: false, paid_at: null, created_at: '' },
    { id: 'c-2', user_id: 'user-1', plan_id: 'plan-1', title: 'Credit card', amount: 5000, due_date: '2026-09-15', is_paid: true, paid_at: '2026-09-14T00:00:00Z', created_at: '' },
  ],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Commitments', () => {
  it('renders the Commitments heading', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Commitments />)
    expect(screen.getByText('Commitments')).toBeInTheDocument()
  })

  it('renders the Add Commitment button', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Commitments />)
    expect(screen.getByText('Add Commitment')).toBeInTheDocument()
  })

  it('renders unpaid commitments', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Commitments />)
    expect(screen.getByText('Electricity bill')).toBeInTheDocument()
  })

  it('renders paid commitments', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Commitments />)
    expect(screen.getByText('Credit card')).toBeInTheDocument()
  })

  it('shows empty state when no plan exists', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      plan: null,
    })
    render(<Commitments />)
    expect(screen.getByText('No plan for this month yet')).toBeInTheDocument()
  })

  it('shows loading state', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      loading: true,
    })
    render(<Commitments />)
    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })
})
