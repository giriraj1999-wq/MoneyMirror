import { describe, it, expect, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'

// The global setup already mocks @/lib/supabase with chainable queries.
import Goals from '@/pages/Goals'

describe('Goals', () => {
  it('renders the Goals heading', async () => {
    render(<Goals />)
    await waitFor(() => expect(screen.getByText('Your Financial Goals')).toBeInTheDocument())
  })

  it('renders the New Goal button', async () => {
    render(<Goals />)
    await waitFor(() => expect(screen.getByText('New Goal')).toBeInTheDocument())
  })

  it('renders empty state when no goals exist', async () => {
    render(<Goals />)
    await waitFor(() => expect(screen.getByText('No goals yet')).toBeInTheDocument())
  })

  it('renders "Add your first goal" button in empty state', async () => {
    render(<Goals />)
    await waitFor(() => expect(screen.getByText('Add your first goal')).toBeInTheDocument())
  })
})
