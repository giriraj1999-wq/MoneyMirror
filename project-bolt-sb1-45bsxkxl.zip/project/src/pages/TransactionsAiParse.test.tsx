import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Transactions from '@/pages/Transactions'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Salary', is_essential: false, type: 'income' as const, created_at: '' },
    { id: 'cat-2', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
    { id: 'cat-3', user_id: 'user-1', name: 'Dining Out', is_essential: false, is_fixed: false, type: 'expense' as const, created_at: '' },
    { id: 'cat-4', user_id: 'user-1', name: 'Groceries', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
    { id: 'cat-5', user_id: 'user-1', name: 'Transport', is_essential: false, is_fixed: false, type: 'expense' as const, created_at: '' },
  ],
  budgets: [],
  transactions: [],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Transactions — AI Parse fallback', () => {
  beforeEach(() => {
    vi.restoreAllMocks()
    mockUseMonthData.mockReturnValue(defaultProps)
  })

  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('fills the form from a bank SMS using the regex fallback when AI is unavailable', async () => {
    const user = userEvent.setup()

    // Simulate the edge function's regex fallback (no OpenAI key → fallback parse)
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        amount: 500,
        currency: 'INR',
        merchant_or_description: 'swiggy@axisb',
        type: 'expense',
        suggested_category: 'Dining Out',
        confidence: 0.6,
      }),
    }) as any)

    render(<Transactions />)

    const textarea = screen.getByPlaceholderText('Paste a bank SMS or UPI message here...')
    await user.type(textarea, '₹500 debited to swiggy@axisb')

    const parseButton = screen.getByText('Parse')
    await user.click(parseButton)

    // The form should open with the parsed amount and category pre-filled
    await waitFor(() => {
      expect(screen.getByDisplayValue('500')).toBeInTheDocument()
    })

    // Category should be auto-selected to Dining Out
    const categorySelect = screen.getByDisplayValue('Dining Out')
    expect(categorySelect).toBeInTheDocument()
  })

  it('shows error when parse returns no amount', async () => {
    const user = userEvent.setup()

    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        amount: null,
        currency: 'INR',
        merchant_or_description: null,
        type: 'expense',
        suggested_category: null,
        confidence: 0,
      }),
    }) as any)

    render(<Transactions />)

    const textarea = screen.getByPlaceholderText('Paste a bank SMS or UPI message here...')
    await user.type(textarea, 'random text with no amount')

    const parseButton = screen.getByText('Parse')
    await user.click(parseButton)

    // Modal opens but amount field is empty
    await waitFor(() => {
      expect(screen.getAllByText('Add Transaction').length).toBeGreaterThan(1)
    })
    const amountInput = screen.getByRole('spinbutton') as HTMLInputElement
    await waitFor(() => {
      expect(amountInput.value).toBe('')
    })
  })
})
