import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/lib/supabase';
import { Mail, Lock, ArrowRight, ArrowLeft, Users, CheckCircle2 } from 'lucide-react';
import { LogoMark } from '@/components/shared/Logo';

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" width="20" height="20">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}

export default function Auth() {
  const { signIn, signUp } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [inviteEmail, setInviteEmail] = useState<string | null>(null);
  const [inviteMode, setInviteMode] = useState(false);
  const [inviteDone, setInviteDone] = useState(false);
  const [recoveryMode, setRecoveryMode] = useState(false);
  const [recoveryEmail, setRecoveryEmail] = useState<string | null>(null);
  const [recoveryDone, setRecoveryDone] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSending, setForgotSending] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const [forgotError, setForgotError] = useState<string | null>(null);

  // Detect invite flow: Supabase redirect with type=invite or recovery.
  // The token may arrive in the hash fragment (PKCE) or as a query param.
  useEffect(() => {
    const hashParams = new URLSearchParams(window.location.hash.replace('#', '?'));
    const type = searchParams.get('type') || hashParams.get('type');
    const accessToken = hashParams.get('access_token');
    const refreshToken = hashParams.get('refresh_token');
    const tokenHash = searchParams.get('token_hash') || hashParams.get('token_hash');
    const errorDescription = searchParams.get('error_description') || hashParams.get('error_description');
    const emailParam = searchParams.get('email') || hashParams.get('email');

    if (errorDescription) {
      setError(errorDescription);
      return;
    }

    if (type === 'invite') {
      setInviteMode(true);

      const loadInviteSession = async () => {
        if (tokenHash) {
          await supabase.auth.verifyOtp({
            type: 'invite',
            token_hash: tokenHash,
          });
        }

        const { data } = await supabase.auth.getSession();
        if (data.session?.user?.email) {
          setInviteEmail(data.session.user.email);
          setEmail(data.session.user.email);
        } else if (emailParam) {
          setInviteEmail(emailParam);
          setEmail(emailParam);
        }
      };

      void loadInviteSession();

      // If there are no tokens at all, the user opened the link in a
      // different browser. Fall back to the normal sign-in form so they
      // can authenticate and still reach the Shared Expenses page.
      if (!accessToken && !refreshToken) {
        setInviteMode(false);
      }
    } else if (type === 'recovery' || type === 'reset_password') {
      // Password reset flow — distinct from the invite flow.
      // Supabase auto-detects the session from the URL hash (detectSessionInUrl: true),
      // so by the time this effect runs the session is already established.
      // We just need to show the password-set form.
      setRecoveryMode(true);

      const loadRecoverySession = async () => {
        const { data } = await supabase.auth.getSession();
        if (data.session?.user?.email) {
          setRecoveryEmail(data.session.user.email);
          setEmail(data.session.user.email);
        } else if (emailParam) {
          setRecoveryEmail(emailParam);
          setEmail(emailParam);
        }
      };
      void loadRecoverySession();
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const fn = mode === 'signin' ? signIn : signUp;
    const { error: err } = await fn(email.trim(), password);

    if (err) {
      setError(err);
      setLoading(false);
      return;
    }

    if (mode === 'signup') {
      const { error: signInErr } = await signIn(email.trim(), password);
      if (signInErr) {
        setError(signInErr);
        setLoading(false);
        return;
      }
    }

    // If the user arrived from an invite link, send them to Shared Expenses
    // after signing in, instead of the dashboard.
    const hashParams = new URLSearchParams(window.location.hash.replace('#', '?'));
    const type = searchParams.get('type') || hashParams.get('type');
    navigate(type === 'invite' ? '/shared' : '/');
  };

  const handleSetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    const { error: updateErr } = await supabase.auth.updateUser({ password });
    if (updateErr) {
      setError(updateErr.message);
      setLoading(false);
      return;
    }

    if (recoveryMode) {
      setRecoveryDone(true);
    } else {
      setInviteDone(true);
    }
    setLoading(false);
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    const redirectTo = `${window.location.origin}/`;
    const { error: oauthErr } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo },
    });
    if (oauthErr) {
      setError(oauthErr.message);
    }
  };

  // Invite flow: user clicked email link, needs to set a password
  if (inviteMode && !inviteDone) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-600 shadow-lg shadow-blue-600/20">
              <Users className="h-7 w-7 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              You've Been Invited
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Set a password to access your shared expenses.
            </p>
          </div>

          <div className="card p-8">
            {inviteEmail && (
              <div className="mb-4 rounded-lg bg-blue-50 px-4 py-3 text-sm text-blue-700">
                <Mail size={16} className="mr-1.5 inline" />
                {inviteEmail}
              </div>
            )}
            <form onSubmit={handleSetPassword} className="space-y-4">
              <div>
                <label className="label" htmlFor="password">
                  Set Your Password
                </label>
                <div className="relative">
                  <Lock
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    id="password"
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input pl-10"
                    placeholder="At least 6 characters"
                  />
                </div>
              </div>

              <div>
                <label className="label" htmlFor="confirmPassword">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    id="confirmPassword"
                    type="password"
                    required
                    minLength={6}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="input pl-10"
                    placeholder="Re-enter your password"
                  />
                </div>
              </div>

              {error && (
                <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
                  {error}
                </div>
              )}

              <button type="submit" disabled={loading} className="btn btn-primary w-full">
                {loading ? 'Setting up...' : 'Set Password & Continue'}
                {!loading && <ArrowRight size={18} />}
              </button>
            </form>

            <div className="mt-6 flex items-center gap-3">
              <div className="h-px flex-1 bg-slate-200" />
              <span className="text-xs font-medium text-slate-400">or</span>
              <div className="h-px flex-1 bg-slate-200" />
            </div>

            <button
              onClick={handleGoogleSignIn}
              className="mt-4 flex w-full items-center justify-center gap-3 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition-all hover:bg-slate-50 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <GoogleIcon />
              Continue with Google
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Invite flow: password set successfully
  if (inviteMode && inviteDone) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="w-full max-w-md text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100">
            <CheckCircle2 className="h-8 w-8 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            You're All Set!
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            Your password has been set. You can now view and manage shared
            expenses that have been split with you.
          </p>
          <button
            onClick={() => navigate('/shared')}
            className="btn btn-primary mt-6 w-full"
          >
            Go to Shared Expenses <ArrowRight size={18} />
          </button>
        </div>
      </div>
    );
  }

  // Recovery flow: user clicked password-reset email link, needs to set a new password
  if (recoveryMode && !recoveryDone) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-blue-600 shadow-lg shadow-blue-600/20">
              <Lock className="h-7 w-7 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Set a New Password
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Choose a new password for your account.
            </p>
          </div>

          <div className="card p-8">
            {recoveryEmail && (
              <div className="mb-4 rounded-lg bg-blue-50 px-4 py-3 text-sm text-blue-700">
                <Mail size={16} className="mr-1.5 inline" />
                {recoveryEmail}
              </div>
            )}
            <form onSubmit={handleSetPassword} className="space-y-4">
              <div>
                <label className="label" htmlFor="password">
                  New Password
                </label>
                <div className="relative">
                  <Lock
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    id="password"
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input pl-10"
                    placeholder="At least 6 characters"
                  />
                </div>
              </div>

              <div>
                <label className="label" htmlFor="confirmPassword">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock
                    size={18}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    id="confirmPassword"
                    type="password"
                    required
                    minLength={6}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="input pl-10"
                    placeholder="Re-enter your password"
                  />
                </div>
              </div>

              {error && (
                <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
                  {error}
                </div>
              )}

              <button type="submit" disabled={loading} className="btn btn-primary w-full">
                {loading ? 'Setting up...' : 'Set New Password'}
                {!loading && <ArrowRight size={18} />}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // Recovery flow: password set successfully
  if (recoveryMode && recoveryDone) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="w-full max-w-md text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100">
            <CheckCircle2 className="h-8 w-8 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Password Updated!
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            Your password has been changed. You can now sign in with your new password.
          </p>
          <button
            onClick={() => navigate('/')}
            className="btn btn-primary mt-6 w-full"
          >
            Go to Dashboard <ArrowRight size={18} />
          </button>
        </div>
      </div>
    );
  }

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError(null);
    setForgotSending(true);
    try {
      const { error: resetErr } = await supabase.auth.resetPasswordForEmail(
        forgotEmail.trim(),
        { redirectTo: `${window.location.origin}/?type=recovery` }
      );
      if (resetErr) throw resetErr;
      setForgotSent(true);
    } catch (err) {
      setForgotError(err instanceof Error ? err.message : 'Failed to send reset link');
    } finally {
      setForgotSending(false);
    }
  };

  const openForgot = () => {
    setForgotOpen(true);
    setForgotEmail(email);
    setForgotSent(false);
    setForgotError(null);
  };

  const closeForgot = () => {
    setForgotOpen(false);
    setForgotError(null);
    setForgotSent(false);
  };

  // Normal sign-in / sign-up flow
  if (forgotOpen) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center">
              <LogoMark size={56} />
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
              Reset your password
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Enter your email and we'll send you a reset link.
            </p>
          </div>

          <div className="card p-8">
            {forgotSent ? (
              <div className="text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-100">
                  <CheckCircle2 className="h-8 w-8 text-emerald-600" />
                </div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  Check your inbox
                </h2>
                <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
                  We've sent a password reset link to <strong className="text-slate-700 dark:text-slate-300">{forgotEmail}</strong>. Click the link in the email to set a new password.
                </p>
                <button onClick={closeForgot} className="btn btn-primary mt-6 w-full">
                  <ArrowLeft size={18} />
                  Back to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-4">
                <div>
                  <label className="label" htmlFor="forgot-email">
                    Email
                  </label>
                  <div className="relative">
                    <Mail
                      size={18}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                    />
                    <input
                      id="forgot-email"
                      type="email"
                      required
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      className="input pl-10"
                      placeholder="you@example.com"
                    />
                  </div>
                </div>

                {forgotError && (
                  <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
                    {forgotError}
                  </div>
                )}

                <button type="submit" disabled={forgotSending} className="btn btn-primary w-full">
                  {forgotSending ? 'Sending...' : 'Send Reset Link'}
                  {!forgotSending && <ArrowRight size={18} />}
                </button>

                <button
                  type="button"
                  onClick={closeForgot}
                  className="flex w-full items-center justify-center gap-1.5 text-sm font-medium text-slate-500 transition-colors hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                >
                  <ArrowLeft size={16} />
                  Back to Sign In
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-4 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center">
            <LogoMark size={56} />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-slate-100">
            Money<span className="text-blue-600">Mirror</span>
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Plan, Track &amp; Decide
          </p>
        </div>

        <div className="card p-8">
          <div className="mb-6 flex gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            <button
              onClick={() => setMode('signin')}
              className={`flex-1 rounded-md py-2 text-sm font-semibold transition-all ${
                mode === 'signin'
                  ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-slate-100'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('signup')}
              className={`flex-1 rounded-md py-2 text-sm font-semibold transition-all ${
                mode === 'signup'
                  ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-700 dark:text-slate-100'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              Sign Up
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label" htmlFor="email">
                Email
              </label>
              <div className="relative">
                <Mail
                  size={18}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input pl-10"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div>
              <label className="label" htmlFor="password">
                Password
              </label>
              <div className="relative">
                <Lock
                  size={18}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
                />
                <input
                  id="password"
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input pl-10"
                  placeholder="At least 6 characters"
                />
              </div>
            </div>

            {mode === 'signin' && (
              <div className="flex justify-end -mt-2">
                <button
                  type="button"
                  onClick={openForgot}
                  className="text-xs font-semibold text-blue-600 transition-colors hover:text-blue-700 dark:text-blue-400"
                >
                  Forgot password?
                </button>
              </div>
            )}

            {error && (
              <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn btn-primary w-full">
              {loading ? 'Please wait...' : mode === 'signin' ? 'Sign In' : 'Create Account'}
              {!loading && <ArrowRight size={18} />}
            </button>
          </form>

          <div className="mt-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-slate-200" />
            <span className="text-xs font-medium text-slate-400">or</span>
            <div className="h-px flex-1 bg-slate-200" />
          </div>

          <button
            onClick={handleGoogleSignIn}
            className="mt-4 flex w-full items-center justify-center gap-3 rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition-all hover:bg-slate-50 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
          >
            <GoogleIcon />
            Continue with Google
          </button>
        </div>

        <p className="mt-6 text-center text-xs text-slate-400">
          By signing up you agree to keep your financial data private.
        </p>
      </div>
    </div>
  );
}
