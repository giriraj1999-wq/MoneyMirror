import { useState, useMemo } from 'react';
import { useMonthData } from '@/hooks/useMonthData';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { formatCurrency, formatDate, getCurrencySymbol } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import { useCurrencyConversions } from '@/hooks/useCurrencyConversions';
import EmptyState from '@/components/shared/EmptyState';
import { Link } from 'react-router-dom';
import {
  Users,
  Check,
  Clock,
  ArrowRight,
  ArrowDownLeft,
  ArrowUpRight,
  Mail,
  CheckCircle2,
  HandCoins,
} from 'lucide-react';
import type { TransactionShare } from '@/types';

const STATUS_LABELS: Record<string, { text: string; class: string }> = {
  pending: { text: 'Awaiting acceptance', class: 'badge-amber' },
  accepted: { text: 'Accepted', class: 'badge-blue' },
  paid: { text: 'Paid — awaiting confirmation', class: 'badge-blue' },
  acknowledged: { text: 'Settled', class: 'badge-green' },
};

export default function Shared() {
  const { session } = useAuth();
  const {
    loading,
    plan,
    transactions,
    outgoingShares,
    incomingShares,
    refetch,
    setOutgoingShares,
    setIncomingShares,
  } = useMonthData();

  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const { currency: displayCurrency } = useDisplayCurrency();

  const conversionRequests = useMemo(
    () => [...outgoingShares, ...incomingShares].map((share) => ({
      key: share.id,
      amount: share.share_amount,
      from: share.share_currency ?? displayCurrency,
    })),
    [outgoingShares, incomingShares, displayCurrency]
  );
  const displayConversions = useCurrencyConversions(conversionRequests, displayCurrency);

  const txnMap = useMemo(() => {
    const map = new Map<string, { amount: number; note: string | null; txn_date: string; category_id: string | null; currency: string }>();
    for (const t of transactions) {
      map.set(t.id, { amount: t.amount, note: t.note, txn_date: t.txn_date, category_id: t.category_id, currency: t.currency ?? displayCurrency });
    }
    return map;
  }, [transactions]);

  const handleMarkPaid = async (share: TransactionShare) => {
    setBusyId(share.id);
    setError(null);
    try {
      const { error: rpcErr } = await supabase.rpc('mark_share_paid', {
        share_uuid: share.id,
      });
      if (rpcErr) throw rpcErr;

      setIncomingShares(
        incomingShares.map((s) =>
          s.id === share.id ? { ...s, status: 'paid', paid_at: new Date().toISOString() } : s
        )
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update');
    } finally {
      setBusyId(null);
    }
  };

  const handleAcknowledge = async (share: TransactionShare) => {
    setBusyId(share.id);
    setError(null);
    try {
      const { data: settlementTxnId, error: rpcErr } = await supabase.rpc('acknowledge_share', {
        share_uuid: share.id,
      });
      if (rpcErr) throw rpcErr;

      setOutgoingShares(
        outgoingShares.map((s) =>
          s.id === share.id
            ? { ...s, status: 'acknowledged', acknowledged_at: new Date().toISOString(), settlement_txn_id: settlementTxnId as string }
            : s
        )
      );

      await refetch();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to acknowledge');
    } finally {
      setBusyId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">Loading...</div>
      </div>
    );
  }

  if (!plan) {
    return (
      <div>
        <h1 className="mb-6 text-xl font-bold text-slate-900 dark:text-slate-100">Shared Expenses</h1>
        <EmptyState
          title="No plan for this month yet"
          description="Create a monthly plan first to start splitting expenses with others."
          action={
            <Link to="/plan" className="btn btn-primary">
              Create a Plan <ArrowRight size={18} />
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Shared Expenses</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Split transactions with family or friends and track settlements.
          </p>
        </div>
        <Link to="/transactions" className="btn btn-primary w-fit">
          <Users size={18} />
          Split an Expense
        </Link>
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}

      {/* How it works callout */}
      {outgoingShares.length === 0 && incomingShares.length === 0 && (
        <div className="card border-blue-200 bg-blue-50/50 p-5">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-100">
              <Users size={20} className="text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                How Splitting Works
              </h3>
              <ol className="mt-2 space-y-1.5 text-sm text-slate-600 dark:text-slate-400">
                <li className="flex gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">1</span>
                  Go to the Transactions page and find an expense you paid for someone else.
                </li>
                <li className="flex gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">2</span>
                  Click the <span className="font-semibold text-blue-600">Split</span> button on that expense.
                </li>
                <li className="flex gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">3</span>
                  Enter their email and how much they owe. We send them an email invite.
                </li>
                <li className="flex gap-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-600 text-xs font-bold text-white">4</span>
                  They sign up, mark it as paid, and you confirm receipt. Done!
                </li>
              </ol>
              <Link
                to="/transactions"
                className="btn btn-primary mt-4"
              >
                Go to Transactions <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Outgoing shares — expenses the user split with others */}
      <div>
        <div className="mb-3 flex items-center gap-2">
          <ArrowUpRight size={18} className="text-blue-600" />
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Expenses You Shared
          </h2>
          <span className="text-xs text-slate-400 dark:text-slate-500">
            ({outgoingShares.length})
          </span>
        </div>

        {outgoingShares.length === 0 ? (
          <div className="card p-5 text-center">
            <Users className="mx-auto mb-2 h-8 w-8 text-slate-300" />
            <p className="text-sm text-slate-500 dark:text-slate-400">
              You haven't split any expenses yet. Go to the Transactions page and
              click "Split" on any expense to share it with someone.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {outgoingShares.map((share) => {
              const txn = txnMap.get(share.transaction_id);
              const statusInfo = STATUS_LABELS[share.status];
              return (
                <div
                  key={share.id}
                  className="card card-hover flex flex-col gap-3 p-4 sm:flex-row sm:items-center"
                >
                  <div className="flex flex-1 items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-50">
                      <Users size={20} className="text-blue-600" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {txn?.note ?? 'Shared expense'}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        <Mail size={11} className="mr-1 inline" />
                        {share.partner_email}
                        {txn && ` · ${formatDate(txn.txn_date)}`}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-xs text-slate-500 dark:text-slate-400">Owed to you</p>
                      <p className="text-sm font-bold text-emerald-600">
                        {formatCurrency(
                          displayConversions[share.id]?.amount ?? share.share_amount_base ?? share.share_amount,
                          displayCurrency
                        )}
                      </p>
                    </div>
                    <span className={`badge ${statusInfo.class}`}>
                      {statusInfo.text}
                    </span>
                    {share.status === 'paid' && (
                      <button
                        onClick={() => handleAcknowledge(share)}
                        disabled={busyId === share.id}
                        className="btn btn-primary !py-1.5 !px-3 text-xs"
                        title="Confirm you received this payment"
                        aria-label="Confirm you received this payment"
                      >
                        {busyId === share.id ? (
                          'Confirming...'
                        ) : (
                          <>
                            <HandCoins size={14} />
                            Confirm Received
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Incoming shares — expenses shared with this user */}
      <div>
        <div className="mb-3 flex items-center gap-2">
          <ArrowDownLeft size={18} className="text-amber-600" />
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Expenses Shared With You
          </h2>
          <span className="text-xs text-slate-400 dark:text-slate-500">
            ({incomingShares.length})
          </span>
        </div>

        {incomingShares.length === 0 ? (
          <div className="card p-5 text-center">
            <Clock className="mx-auto mb-2 h-8 w-8 text-slate-300" />
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No one has shared an expense with you yet. When someone invites you
              to split a transaction, it will appear here.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {incomingShares.map((share) => {
              const statusInfo = STATUS_LABELS[share.status];
              return (
                <div
                  key={share.id}
                  className="card card-hover flex flex-col gap-3 p-4 sm:flex-row sm:items-center"
                >
                  <div className="flex flex-1 items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-50">
                      <ArrowDownLeft size={20} className="text-amber-600" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        You owe {formatCurrency(
                          displayConversions[share.id]?.amount ?? share.share_amount_base ?? share.share_amount,
                          displayCurrency
                        )}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        <Mail size={11} className="mr-1 inline" />
                        {share.partner_email === session?.user?.email
                          ? 'Shared with you'
                          : share.partner_email}
                        {share.created_at && ` · ${formatDate(share.created_at.slice(0, 10))}`}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className={`badge ${statusInfo.class}`}>
                      {statusInfo.text}
                    </span>
                    {share.status === 'accepted' && (
                      <button
                        onClick={() => handleMarkPaid(share)}
                        disabled={busyId === share.id}
                        className="btn btn-primary !py-1.5 !px-3 text-xs"
                        title="Mark this as paid"
                        aria-label="Mark this as paid"
                      >
                        {busyId === share.id ? (
                          'Updating...'
                        ) : (
                          <>
                            <Check size={14} />
                            Mark Paid
                          </>
                        )}
                      </button>
                    )}
                    {share.status === 'paid' && (
                      <span className="flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
                        <Clock size={14} />
                        Waiting for confirmation
                      </span>
                    )}
                    {share.status === 'acknowledged' && (
                      <span className="flex items-center gap-1 text-xs text-emerald-600">
                        <CheckCircle2 size={14} />
                        Settled
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
