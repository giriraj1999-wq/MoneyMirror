import { useState, useMemo, useEffect } from 'react';
import { useMonthData } from '@/hooks/useMonthData';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useNotifications } from '@/hooks/useNotifications';
import { formatCurrency, formatDate, CURRENCIES, getCurrencySymbol, getMonthStart, getMonthLabel } from '@/lib/format';
import { useDisplayCurrency } from '@/hooks/useDisplayCurrency';
import { useCurrencyConversions } from '@/hooks/useCurrencyConversions';
import Modal from '@/components/ui/Modal';
import EmptyState from '@/components/shared/EmptyState';
import { Link } from 'react-router-dom';
import {
  Plus,
  Pencil,
  Trash2,
  ArrowDownCircle,
  ArrowUpCircle,
  Sparkles,
  Check,
  X,
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Users,
  Paperclip,
  FileText,
  Loader2,
} from 'lucide-react';
import type { Transaction, TransactionType } from '@/types';

export default function Transactions() {
  const { session } = useAuth();
  const { addNotification } = useNotifications();
  const [selectedMonth, setSelectedMonth] = useState(getMonthStart());
  const {
    month,
    loading,
    plan,
    categories,
    transactions,
    refetch,
    ensurePlan,
    setCategories,
    setTransactions,
  } = useMonthData(selectedMonth);

  const [filter, setFilter] = useState<'all' | 'income' | 'expense'>('all');
  const { currency: displayCurrency } = useDisplayCurrency();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTxn, setEditingTxn] = useState<Transaction | null>(null);
  const [aiText, setAiText] = useState('');
  const [aiParsing, setAiParsing] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [form, setForm] = useState({
    amount: '',
    type: 'expense' as TransactionType,
    category_id: '',
    txn_date: new Date().toISOString().slice(0, 10),
    note: '',
    currency: displayCurrency,
  });
  const [billFile, setBillFile] = useState<File | null>(null);
  const [billUrl, setBillUrl] = useState<string | null>(null);
  const [billPath, setBillPath] = useState<string | null>(null);
  const [uploadingBill, setUploadingBill] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [billPreviewTxn, setBillPreviewTxn] = useState<Transaction | null>(null);
  const [splitTxn, setSplitTxn] = useState<Transaction | null>(null);
  const [splitRows, setSplitRows] = useState<{ email: string; amount: string; currency: string }[]>([
    { email: '', amount: '', currency: displayCurrency },
  ]);
  const [splitConversions, setSplitConversions] = useState<Record<number, { base: number | null; rate: number | null; loading: boolean }>>({});
  const [splitting, setSplitting] = useState(false);
  const [splitError, setSplitError] = useState<string | null>(null);
  const [splitSuccess, setSplitSuccess] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Transaction | null>(null);
  const [formConversion, setFormConversion] = useState<{ base: number | null; rate: number | null; loading: boolean }>({ base: null, rate: null, loading: false });
  const [newCategoryName, setNewCategoryName] = useState('');
  const [addingCategory, setAddingCategory] = useState(false);

  const shiftMonth = (offset: number) => {
    const current = new Date(`${selectedMonth}T00:00:00`);
    current.setMonth(current.getMonth() + offset);
    setSelectedMonth(getMonthStart(current));
  };

  const filteredTxns = useMemo(
    () =>
      filter === 'all'
        ? transactions
        : transactions.filter((t) => t.type === filter),
    [transactions, filter]
  );

  const conversionRequests = useMemo(
    () => transactions.map((txn) => ({ key: txn.id, amount: txn.amount, from: txn.currency })),
    [transactions]
  );
  const displayConversions = useCurrencyConversions(conversionRequests, displayCurrency);

  const filteredTotal = useMemo(() => {
    return filteredTxns.reduce((total, txn) => {
      const convertedAmount = displayConversions[txn.id]?.amount;
      const amount = convertedAmount ?? (
        txn.currency === displayCurrency
          ? txn.amount
          : (txn.amount_base ?? txn.amount)
      );
      if (txn.type === 'income') return total + amount;
      if (txn.type === 'reimbursement') return total + amount;
      return total - amount;
    }, 0);
  }, [displayConversions, displayCurrency, filteredTxns]);

  const totalLabel = filter === 'all' ? 'Net balance' : filter === 'income' ? 'Income total' : 'Expense total';
  const totalDescription = filter === 'all'
    ? 'Income minus expenses this month'
    : filter === 'income'
      ? 'Income recorded this month'
      : 'Expenses recorded this month';

  const fetchFormConversion = async (amount: number, from: string, to: string) => {
    if (from === to || amount <= 0) {
      setFormConversion({ base: from === to ? amount : null, rate: from === to ? 1 : null, loading: false });
      return;
    }
    setFormConversion({ base: null, rate: null, loading: true });
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/currency-convert`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount, from, to }),
      });
      if (!response.ok) throw new Error('Conversion failed');
      const data = await response.json();
      setFormConversion({ base: data.amount, rate: data.rate, loading: false });
    } catch {
      setFormConversion({ base: null, rate: null, loading: false });
    }
  };

  useEffect(() => {
    const amt = Number(form.amount);
    if (amt > 0) {
      fetchFormConversion(amt, form.currency, plan?.base_currency ?? 'INR');
    } else {
      setFormConversion({ base: null, rate: null, loading: false });
    }
  }, [form.amount, form.currency, plan?.base_currency]);

  const openAdd = () => {
    setEditingTxn(null);
    setForm({
      amount: '',
      type: 'expense',
      category_id: '',
      txn_date: month,
      note: '',
      currency: displayCurrency,
    });
    setFormConversion({ base: null, rate: null, loading: false });
    setBillFile(null);
    setBillUrl(null);
    setBillPath(null);
    setModalOpen(true);
  };

  const openEdit = (txn: Transaction) => {
    setEditingTxn(txn);
    setForm({
      amount: String(txn.amount),
      type: txn.type,
      category_id: txn.category_id ?? '',
      txn_date: txn.txn_date,
      note: txn.note ?? '',
      currency: (txn.currency ?? displayCurrency) as typeof form.currency,
    });
    setFormConversion({
      base: txn.amount_base ?? (txn.currency === displayCurrency ? txn.amount : null),
      rate: null,
      loading: false,
    });
    setBillFile(null);
    setBillUrl(txn.bill_url ?? null);
    setBillPath(txn.bill_path ?? null);
    setModalOpen(true);
  };

  const handleBillUpload = async (file: File) => {
    if (!session?.user) return;
    setUploadingBill(true);
    setError(null);
    try {
      const ext = file.name.split('.').pop() ?? 'jpg';
      const filePath = `${session.user.id}/${Date.now()}.${ext}`;
      const { error: uploadErr } = await supabase.storage
        .from('transaction-bills')
        .upload(filePath, file, { cacheControl: '3600', upsert: false });
      if (uploadErr) throw uploadErr;
      const { data: pub } = supabase.storage
        .from('transaction-bills')
        .getPublicUrl(filePath);
      setBillFile(file);
      setBillUrl(pub.publicUrl);
      setBillPath(filePath);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload bill');
    } finally {
      setUploadingBill(false);
    }
  };

  const removeBill = async () => {
    if (billPath && session?.user) {
      await supabase.storage.from('transaction-bills').remove([billPath]);
    }
    setBillFile(null);
    setBillUrl(null);
    setBillPath(null);
  };

  const handleAddTransactionCategory = async () => {
    const name = newCategoryName.trim();
    if (!name || !session?.user) return;
    setAddingCategory(true);
    setError(null);
    try {
      const { data, error: insertError } = await supabase
        .from('categories')
        .insert({
          user_id: session.user.id,
          name,
          type: form.type,
          is_essential: false,
          is_fixed: false,
        })
        .select('*')
        .maybeSingle();
      if (insertError) throw insertError;
      if (!data) throw new Error('Failed to create category');
      setCategories([...categories, data as typeof categories[number]]);
      setForm((current) => ({ ...current, category_id: data.id }));
      setNewCategoryName('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create category');
    } finally {
      setAddingCategory(false);
    }
  };

  const handleSave = async () => {
    const amount = Number(form.amount);
    if (!form.amount || isNaN(amount) || amount <= 0) {
      setError('Amount must be greater than zero');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const currentPlan = plan ?? (await ensurePlan());
      if (!currentPlan || !session?.user) throw new Error('No plan found');

      const baseCurrency = currentPlan.base_currency ?? 'INR';
      const amountBase = form.currency === baseCurrency
        ? amount
        : (formConversion.base ?? amount);

      const payload = {
        user_id: session.user.id,
        plan_id: currentPlan.id,
        category_id: form.category_id || null,
        amount,
        amount_base: amountBase,
        type: form.type,
        txn_date: form.txn_date,
        note: form.note || null,
        source: editingTxn?.source ?? 'manual',
        currency: form.currency,
        bill_url: billUrl,
        bill_path: billPath,
      };

      if (editingTxn) {
        const { error: updateErr } = await supabase
          .from('transactions')
          .update(payload)
          .eq('id', editingTxn.id);
        if (updateErr) throw updateErr;
        await addNotification(
          'transaction_updated',
          'Transaction updated',
          `${form.type === 'income' ? 'Income' : 'Expense'} of ${formatCurrency(Number(form.amount), form.currency)} was updated.`,
          editingTxn.id
        );
      } else {
        const { data: inserted, error: insertErr } = await supabase
          .from('transactions')
          .insert(payload)
          .select('id')
          .maybeSingle();
        if (insertErr) throw insertErr;
        await addNotification(
          'transaction_new',
          'New transaction added',
          `${form.type === 'income' ? 'Income' : 'Expense'} of ${formatCurrency(Number(form.amount), form.currency)} was recorded.`,
          inserted?.id ?? null
        );
      }

      await refetch();
      setModalOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (txn: Transaction) => {
    if (txn.bill_path) {
      await supabase.storage.from('transaction-bills').remove([txn.bill_path]);
    }
    const { error: deleteErr } = await supabase
      .from('transactions')
      .delete()
      .eq('id', txn.id);
    if (deleteErr) {
      setError(deleteErr.message);
      return;
    }
    setTransactions(transactions.filter((t) => t.id !== txn.id));
    setDeleteTarget(null);
  };

  const handleAIParse = async () => {
    if (!aiText.trim()) return;
    setAiParsing(true);
    setAiError(null);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-parse`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: aiText }),
      });

      if (!response.ok) throw new Error('Parse failed');

      const draft = await response.json();
      setForm((prev) => ({
        ...prev,
        amount: draft.amount ? String(draft.amount) : '',
        type: draft.type ?? 'expense',
        currency: draft.currency ?? prev.currency,
        category_id:
          categories.find(
            (c) =>
              c.name.toLowerCase() ===
              (draft.suggested_category ?? '').toLowerCase()
          )?.id ?? '',
        txn_date: month,
        note: draft.merchant_or_description ?? aiText,
      }));
      setModalOpen(true);
    } catch {
      setAiError('Could not parse. Please enter manually instead.');
    } finally {
      setAiParsing(false);
    }
  };

  const openSplit = (txn: Transaction) => {
    setSplitTxn(txn);
    setSplitRows([{ email: '', amount: '', currency: txn.currency ?? displayCurrency }]);
    setSplitConversions({});
    setSplitError(null);
    setSplitSuccess(null);
  };

  const splitEqually = () => {
    if (!splitTxn) return;
    const count = splitRows.length || 1;
    const per = (splitTxn.amount / count).toFixed(2);
    setSplitRows(splitRows.map((r) => ({ ...r, amount: per })));
  };

  const addSplitRow = () => {
    setSplitRows([...splitRows, { email: '', amount: '', currency: splitTxn?.currency ?? displayCurrency }]);
  };

  const removeSplitRow = (idx: number) => {
    setSplitRows(splitRows.filter((_, i) => i !== idx));
    setSplitConversions((prev) => {
      const next: typeof prev = {};
      for (const key of Object.keys(prev)) {
        const n = Number(key);
        if (n < idx) next[n] = prev[n];
        else if (n > idx) next[n - 1] = prev[n];
      }
      return next;
    });
  };

  const updateSplitRow = (idx: number, field: 'email' | 'amount' | 'currency', value: string) => {
    setSplitRows(splitRows.map((r, i) => (i === idx ? { ...r, [field]: value } : r)));
  };

  const fetchConversion = async (idx: number, amount: number, from: string, to: string) => {
    if (from === to) {
      setSplitConversions((prev) => ({ ...prev, [idx]: { base: amount, rate: 1, loading: false } }));
      return;
    }
    setSplitConversions((prev) => ({ ...prev, [idx]: { base: null, rate: null, loading: true } }));
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/currency-convert`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ amount, from, to }),
      });
      if (!response.ok) throw new Error('Conversion failed');
      const data = await response.json();
      setSplitConversions((prev) => ({ ...prev, [idx]: { base: data.amount, rate: data.rate, loading: false } }));
    } catch {
      setSplitConversions((prev) => ({ ...prev, [idx]: { base: null, rate: null, loading: false } }));
    }
  };

  const totalShares = splitRows.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
  const totalSharesBase = splitRows.reduce((sum, r, i) => {
    const conv = splitConversions[i];
    if (conv?.base != null) return sum + conv.base;
    return sum + (Number(r.amount) || 0);
  }, 0);
  const validRows = splitRows.filter((r) => r.email.trim() && Number(r.amount) > 0);

  const handleSplit = async () => {
    if (!splitTxn || validRows.length === 0) return;
    setSplitting(true);
    setSplitError(null);
    setSplitSuccess(null);
    try {
      const appOrigin = window.location.origin;
      if (/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(appOrigin)) {
        throw new Error(
          'Please open the published app before sending an invite. Preview links use localhost and cannot be opened by the recipient.'
        );
      }

      const partners = validRows.map((r) => ({
        partner_email: r.email.trim(),
        share_amount: Number(r.amount),
        share_currency: r.currency,
        share_amount_base: splitConversions[splitRows.indexOf(r)]?.base ?? Number(r.amount),
      }));

      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/split-invite`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          transaction_id: splitTxn.id,
          partners,
          note: splitTxn.note,
          app_url: window.location.origin,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error ?? 'Failed to split');
      }

      const result = await response.json().catch(() => ({}));
      if (result.success === false) {
        const failedResult = result.results?.find((item: { error?: string }) => item.error);
        throw new Error(failedResult?.error ?? 'This expense could not be split');
      }
      const summary = result.summary;
      if (summary && summary.sent === summary.total) {
        setSplitSuccess(
          `Invite emails sent to all ${summary.total} recipient${summary.total > 1 ? 's' : ''}. They'll be able to see this shared expense once they sign up or log in.`
        );
      } else if (summary && summary.sent > 0) {
        setSplitSuccess(
          `Sent ${summary.sent} of ${summary.total} invite emails. The remaining ${summary.failed} split${summary.failed > 1 ? 's were' : ' was'} recorded — ask them to sign up and this expense will appear on their Shared Expenses page.`
        );
      } else {
        setSplitSuccess(
          `Split recorded for ${summary?.total ?? validRows.length} recipient${(summary?.total ?? validRows.length) > 1 ? 's' : ''}. Invite emails couldn't be sent automatically, so please ask them to sign up — this expense will appear on their Shared Expenses page once they do.`
        );
      }
      setSplitRows([{ email: '', amount: '', currency: displayCurrency }]);
      setSplitConversions({});
      await refetch();
    } catch (err) {
      setSplitError(err instanceof Error ? err.message : 'Failed to split');
    } finally {
      setSplitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <div className="text-sm text-slate-500 dark:text-slate-400">Loading...</div>
      </div>
    );
  }

  if (!plan) {
    return (
      <div>
        <h1 className="mb-6 text-xl font-bold text-slate-900 dark:text-slate-100">Transactions</h1>
        <EmptyState
          title="No plan for this month yet"
          description="Create a monthly plan first to start tracking your transactions."
          action={
            <Link to="/plan" className="btn btn-primary">
              Create a Plan <ArrowRight size={18} />
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Transactions</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            {transactions.length} total in {getMonthLabel(month)}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center rounded-lg border border-slate-200 bg-white p-1 dark:border-slate-800 dark:bg-slate-900">
            <button onClick={() => shiftMonth(-1)} className="btn-ghost btn !p-2" aria-label="Previous month">
              <ChevronLeft size={18} />
            </button>
            <label className="flex items-center gap-2 px-2 text-sm font-semibold text-slate-700 dark:text-slate-200">
              <CalendarDays size={16} className="text-blue-600" />
              <span>{getMonthLabel(month)}</span>
              <input
                type="month"
                value={month.slice(0, 7)}
                onChange={(e) => e.target.value && setSelectedMonth(`${e.target.value}-01`)}
                className="absolute h-0 w-0 opacity-0"
                aria-label="Select transaction month"
              />
            </label>
            <button onClick={() => shiftMonth(1)} className="btn-ghost btn !p-2" aria-label="Next month">
              <ChevronRight size={18} />
            </button>
          </div>
          <button onClick={openAdd} className="btn btn-primary w-fit">
            <Plus size={18} />
            Add Transaction
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </div>
      )}

      <div className="card p-5">
        <div className="mb-3 flex items-center gap-2">
          <Sparkles size={18} className="text-blue-600" />
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            AI Parse from Bank SMS
          </h2>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <textarea
            value={aiText}
            onChange={(e) => setAiText(e.target.value)}
            className="input min-h-[60px] flex-1 resize-none"
            placeholder="Paste a bank SMS or UPI message here..."
            rows={2}
          />
          <button
            onClick={handleAIParse}
            disabled={aiParsing || !aiText.trim()}
            className="btn btn-secondary shrink-0"
          >
            {aiParsing ? 'Parsing...' : 'Parse'}
          </button>
        </div>
        {aiError && (
          <p className="mt-2 text-xs text-red-600">{aiError}</p>
        )}
        <p className="mt-2 text-xs text-slate-400 dark:text-slate-500">
          AI reads the text and fills a draft. You review and confirm before anything is saved.
        </p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
          {(['all', 'income', 'expense'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-md px-3 py-1.5 text-sm font-medium capitalize transition-all ${
                filter === f
                  ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-baseline justify-between gap-6">
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{totalLabel}</p>
              <p className="text-xs text-slate-400 dark:text-slate-500">{totalDescription}</p>
            </div>
            <p className={`text-lg font-bold ${filteredTotal >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
              {formatCurrency(filteredTotal, displayCurrency)}
            </p>
          </div>
        </div>
      </div>

      {filteredTxns.length === 0 ? (
        <EmptyState
          title="No transactions yet"
          description="Add your first transaction manually or paste a bank SMS to let AI help you."
        />
      ) : (
        <div className="space-y-2">
          {filteredTxns.map((txn) => {
            const cat = categories.find((c) => c.id === txn.category_id);
            const isIncome = txn.type === 'income' || txn.type === 'reimbursement';
            return (
              <div
                key={txn.id}
                className="card card-hover flex items-center gap-3 p-4"
              >
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${
                    isIncome
                      ? 'bg-emerald-50 text-emerald-600'
                      : 'bg-red-50 text-red-500'
                  }`}
                >
                  {isIncome ? (
                    <ArrowDownCircle size={20} />
                  ) : (
                    <ArrowUpCircle size={20} />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {cat?.name ?? (txn.type === 'reimbursement' ? 'Reimbursement' : 'Uncategorized')}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {formatDate(txn.txn_date)}
                    {txn.note ? ` · ${txn.note}` : ''}
                    {txn.source === 'ai' && (
                      <span className="ml-1.5 inline-flex items-center gap-0.5 text-blue-600">
                        <Sparkles size={12} /> AI
                      </span>
                    )}
                    {txn.bill_url && (
                      <button
                        onClick={() => setBillPreviewTxn(txn)}
                        className="ml-1.5 inline-flex items-center gap-0.5 text-blue-600 hover:underline"
                        title="View attached bill"
                      >
                        <Paperclip size={12} /> Bill
                      </button>
                    )}
                  </p>
                </div>
                <p
                  className={`text-sm font-bold ${
                    isIncome ? 'text-emerald-600' : 'text-slate-900 dark:text-slate-100'
                  }`}
                >
                  {isIncome ? '+' : '−'}
                  {displayConversions[txn.id]
                    ? formatCurrency(displayConversions[txn.id].amount, displayCurrency)
                    : txn.currency === displayCurrency
                      ? formatCurrency(txn.amount, txn.currency)
                      : getCurrencySymbol(displayCurrency)}
                  {!displayConversions[txn.id] && txn.currency && txn.currency !== displayCurrency && (
                    <span className="ml-1 text-xs font-normal text-slate-400">
                      {txn.currency}
                    </span>
                  )}
                </p>
                <div className="flex items-center gap-1">
                  {txn.type === 'expense' && (
                    <button
                      onClick={() => openSplit(txn)}
                      className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs font-semibold text-blue-600 transition-colors hover:bg-blue-50"
                      title="Split this expense with someone"
                      aria-label="Split this expense with someone"
                    >
                      <Users size={15} />
                      <span className="hidden sm:inline">Split</span>
                    </button>
                  )}
                  <button
                    onClick={() => openEdit(txn)}
                    className="btn-ghost btn !p-1.5"
                    aria-label="Edit transaction"
                  >
                    <Pencil size={16} />
                  </button>
                  <button
                    onClick={() => setDeleteTarget(txn)}
                    className="btn-ghost btn !p-1.5 text-red-500 hover:bg-red-50"
                    aria-label="Delete transaction"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingTxn ? 'Edit Transaction' : 'Add Transaction'}
      >
        <div className="space-y-4">
          <div className="flex gap-1 rounded-lg bg-slate-100 dark:bg-slate-800 p-1">
            {(['expense', 'income'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setForm({ ...form, type: t, category_id: '' })}
                className={`flex-1 rounded-md py-2 text-sm font-semibold capitalize transition-all ${
                  form.type === t
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                    : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <div>
            <label className="label">Amount</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">
                  {getCurrencySymbol(form.currency)}
                </span>
                <input
                  type="number"
                  min="1"
                  value={form.amount}
                  onChange={(e) => setForm({ ...form, amount: e.target.value })}
                  className="input pl-7"
                  placeholder="0"
                />
              </div>
              <select
                value={form.currency}
                onChange={(e) => setForm({ ...form, currency: e.target.value as typeof form.currency })}
                className="input w-28 shrink-0"
              >
                {CURRENCIES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code}
                  </option>
                ))}
              </select>
            </div>
            {form.currency !== (plan?.base_currency ?? 'INR') && Number(form.amount) > 0 && (
              <div className="mt-2 flex items-center justify-between rounded-md bg-blue-50 dark:bg-blue-900/20 px-3 py-2 text-xs">
                {formConversion.loading ? (
                  <span className="flex items-center gap-1.5 text-blue-600">
                    <Loader2 size={12} className="animate-spin" /> Converting...
                  </span>
                ) : formConversion.base != null ? (
                  <span className="text-slate-600 dark:text-slate-400">
                    ≈ {formatCurrency(formConversion.base, plan?.base_currency ?? 'INR')} in {plan?.base_currency ?? 'INR'}
                    {formConversion.rate != null && (
                      <span className="ml-1 text-slate-400">· 1 {form.currency} = {formConversion.rate.toFixed(2)} {plan?.base_currency ?? 'INR'}</span>
                    )}
                  </span>
                ) : (
                  <button
                    onClick={() => fetchFormConversion(Number(form.amount), form.currency, plan?.base_currency ?? 'INR')}
                    className="text-blue-600 hover:underline"
                  >
                    Convert to {plan?.base_currency ?? 'INR'}
                  </button>
                )}
              </div>
            )}
          </div>

          <div>
            <label className="label" htmlFor="transaction-category">Category</label>
            <select
              id="transaction-category"
              value={form.category_id}
              onChange={(e) => setForm({ ...form, category_id: e.target.value })}
              className="input"
            >
              <option value="">Uncategorized</option>
              {categories
                .filter((c) => c.type === form.type || c.id === form.category_id)
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
            </select>
            <div className="mt-2 flex gap-2">
              <input
                type="text"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                className="input flex-1 text-sm"
                placeholder={`Add ${form.type} category`}
                aria-label={`New ${form.type} category name`}
              />
              <button
                type="button"
                onClick={handleAddTransactionCategory}
                disabled={addingCategory || !newCategoryName.trim()}
                className="btn btn-secondary shrink-0 text-sm"
              >
                {addingCategory ? 'Adding...' : 'Add'}
              </button>
            </div>
          </div>

          <div>
            <label className="label">Date</label>
            <input
              type="date"
              value={form.txn_date}
              onChange={(e) => setForm({ ...form, txn_date: e.target.value })}
              className="input"
            />
          </div>

          <div>
            <label className="label">Note (optional)</label>
            <input
              type="text"
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
              className="input"
              placeholder="Add a note..."
            />
          </div>

          <div>
            <label className="label">Bill / Invoice (optional)</label>
            {billUrl ? (
              <div className="flex items-center gap-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2.5">
                <FileText size={18} className="shrink-0 text-blue-600" />
                <a
                  href={billUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 truncate text-sm font-medium text-blue-600 hover:underline"
                >
                  {billFile?.name ?? 'View attached bill'}
                </a>
                <button
                  onClick={removeBill}
                  className="btn-ghost btn shrink-0 !px-2 text-red-500 hover:bg-red-50"
                  title="Remove bill"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ) : (
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 px-3.5 py-2.5 text-sm text-slate-500 dark:text-slate-400 transition-colors hover:border-blue-400 hover:bg-blue-50/30 hover:text-blue-600">
                {uploadingBill ? (
                  <Loader2 size={18} className="animate-spin" />
                ) : (
                  <Paperclip size={18} />
                )}
                {uploadingBill ? 'Uploading...' : 'Attach bill or invoice'}
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleBillUpload(file);
                  }}
                />
              </label>
            )}
          </div>

          {error && (
            <div className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">
              {error}
            </div>
          )}

          <div className="flex gap-2">
            <button
              onClick={() => setModalOpen(false)}
              className="btn btn-secondary flex-1"
            >
              <X size={18} /> Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={saving || !form.amount}
              className="btn btn-primary flex-1"
            >
              <Check size={18} />
              {saving ? 'Saving...' : 'Save'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Split Transaction Modal */}
      {splitTxn && (
        <Modal
          open={!!splitTxn}
          onClose={() => {
            setSplitTxn(null);
            setSplitError(null);
            setSplitSuccess(null);
          }}
          title="Split This Expense"
        >
          <div className="space-y-4">
            {splitSuccess ? (
              <div className="space-y-4">
                <div className="rounded-lg bg-emerald-50 px-4 py-3 text-sm text-emerald-700">
                  {splitSuccess}
                </div>
                <button
                  onClick={() => {
                    setSplitTxn(null);
                    setSplitSuccess(null);
                  }}
                  className="btn btn-primary w-full"
                >
                  <Check size={18} /> Done
                </button>
              </div>
            ) : (
              <>
                <div className="rounded-lg bg-slate-50 dark:bg-slate-950 p-3">
                  <p className="text-xs text-slate-500 dark:text-slate-400">Original expense</p>
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {formatCurrency(splitTxn.amount, splitTxn.currency)}
                    {splitTxn.note ? ` — ${splitTxn.note}` : ''}
                  </p>
                </div>

                <div>
                  <div className="flex items-center justify-between">
                    <label className="label mb-0">Split with</label>
                    <button
                      onClick={splitEqually}
                      className="text-xs font-semibold text-blue-600 hover:underline"
                    >
                      Split equally
                    </button>
                  </div>

                  <div className="mt-2 space-y-2">
                    {splitRows.map((row, idx) => (
                      <div key={idx} className="space-y-1.5">
                        <div className="flex gap-2">
                          <input
                            type="email"
                            value={row.email}
                            onChange={(e) => updateSplitRow(idx, 'email', e.target.value)}
                            className="input flex-1"
                            placeholder="friend@example.com"
                          />
                          <div className="relative w-24 shrink-0">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">
                              {getCurrencySymbol(row.currency)}
                            </span>
                            <input
                              type="number"
                              min="1"
                              value={row.amount}
                              onChange={(e) => updateSplitRow(idx, 'amount', e.target.value)}
                              className="input pl-7"
                              placeholder="0"
                            />
                          </div>
                          <select
                            value={row.currency}
                            onChange={(e) => {
                              updateSplitRow(idx, 'currency', e.target.value);
                              const amt = Number(splitRows[idx].amount);
                              if (amt > 0) {
                                fetchConversion(idx, amt, e.target.value, splitTxn.currency ?? 'INR');
                              }
                            }}
                            className="input w-20 shrink-0"
                            title="Partner's currency"
                          >
                            {CURRENCIES.map((c) => (
                              <option key={c.code} value={c.code}>
                                {c.code}
                              </option>
                            ))}
                          </select>
                          {splitRows.length > 1 && (
                            <button
                              onClick={() => removeSplitRow(idx)}
                              className="btn-ghost btn shrink-0 !px-2 text-red-500 hover:bg-red-50"
                              title="Remove"
                            >
                              <Trash2 size={16} />
                            </button>
                          )}
                        </div>
                        {row.currency !== (splitTxn.currency ?? 'INR') && Number(row.amount) > 0 && (
                          <div className="flex items-center justify-between rounded-md bg-blue-50 dark:bg-blue-900/20 px-2.5 py-1.5 text-xs">
                            {splitConversions[idx]?.loading ? (
                              <span className="flex items-center gap-1.5 text-blue-600">
                                <Loader2 size={12} className="animate-spin" /> Converting...
                              </span>
                            ) : splitConversions[idx]?.base != null ? (
                              <>
                                <span className="text-slate-500 dark:text-slate-400">
                                  ≈ {formatCurrency(splitConversions[idx].base!, splitTxn.currency)} in {splitTxn.currency}
                                </span>
                                <button
                                  onClick={() => fetchConversion(idx, Number(row.amount), row.currency, splitTxn.currency ?? 'INR')}
                                  className="text-blue-600 hover:underline"
                                >
                                  Refresh
                                </button>
                              </>
                            ) : (
                              <button
                                onClick={() => fetchConversion(idx, Number(row.amount), row.currency, splitTxn.currency ?? 'INR')}
                                className="text-blue-600 hover:underline"
                              >
                                Convert to {splitTxn.currency}
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={addSplitRow}
                    className="mt-2 flex items-center gap-1 text-xs font-semibold text-blue-600 hover:underline"
                  >
                    <Plus size={14} /> Add another person
                  </button>
                </div>

                <div className="flex items-center justify-between rounded-lg bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs">
                  <span className="text-slate-500 dark:text-slate-400">Total shares (in {splitTxn.currency ?? 'INR'})</span>
                  <span
                    className={`font-semibold ${
                      totalSharesBase > splitTxn.amount
                        ? 'text-red-600'
                        : 'text-slate-900 dark:text-slate-100'
                    }`}
                  >
                    {formatCurrency(totalSharesBase, splitTxn.currency)} / {formatCurrency(splitTxn.amount, splitTxn.currency)}
                  </span>
                </div>
                {totalSharesBase > splitTxn.amount && (
                  <p className="text-xs text-red-600">
                    Total shares exceed the expense amount.
                  </p>
                )}

                {splitError && (
                  <div className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">
                    {splitError}
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => setSplitTxn(null)}
                    className="btn btn-secondary flex-1"
                  >
                    <X size={18} /> Cancel
                  </button>
                  <button
                    onClick={handleSplit}
                    disabled={splitting || validRows.length === 0 || totalSharesBase > splitTxn.amount}
                    className="btn btn-primary flex-1"
                  >
                    <Users size={18} />
                    {splitting ? 'Sending...' : `Send ${validRows.length || ''} Invite${validRows.length > 1 ? 's' : ''}`}
                  </button>
                </div>
              </>
            )}
          </div>
        </Modal>
      )}

      {deleteTarget && (
        <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete transaction?">
          <div className="space-y-4">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              This will permanently delete the {deleteTarget.type} of {formatCurrency(deleteTarget.amount, deleteTarget.currency)}{deleteTarget.note ? ` (${deleteTarget.note})` : ''}. This cannot be undone.
            </p>
            {error && <div className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}
            <div className="flex gap-2">
              <button onClick={() => setDeleteTarget(null)} className="btn btn-secondary flex-1">
                <X size={18} /> Cancel
              </button>
              <button onClick={() => handleDelete(deleteTarget)} className="btn btn-primary flex-1 !bg-red-600 hover:!bg-red-700">
                <Trash2 size={18} /> Delete
              </button>
            </div>
          </div>
        </Modal>
      )}

      {billPreviewTxn && billPreviewTxn.bill_url && (
        <Modal
          open={!!billPreviewTxn}
          onClose={() => setBillPreviewTxn(null)}
          title="Attached Bill"
        >
          <div className="space-y-3">
            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 p-3">
              <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                {formatCurrency(billPreviewTxn.amount, billPreviewTxn.currency)}
                {billPreviewTxn.note ? ` — ${billPreviewTxn.note}` : ''}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{formatDate(billPreviewTxn.txn_date)}</p>
            </div>
            {billPreviewTxn.bill_url.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? (
              <img
                src={billPreviewTxn.bill_url}
                alt="Bill"
                className="w-full rounded-lg border border-slate-200 dark:border-slate-800"
              />
            ) : (
              <div className="flex flex-col items-center gap-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 py-8">
                <FileText size={40} className="text-slate-400 dark:text-slate-500" />
                <a
                  href={billPreviewTxn.bill_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-semibold text-blue-600 hover:underline"
                >
                  Open bill in new tab
                </a>
              </div>
            )}
            <button
              onClick={() => setBillPreviewTxn(null)}
              className="btn btn-primary w-full"
            >
              <Check size={18} /> Close
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
