import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

import Transactions from '@/pages/Transactions'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Salary', is_essential: false, type: 'income' as const, created_at: '' },
    { id: 'cat-2', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
  ],
  budgets: [],
  transactions: [
    { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 80000, type: 'income' as const, txn_date: '2026-09-01', note: 'Salary', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
    { id: 't-2', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-2', amount: 15000, type: 'expense' as const, txn_date: '2026-09-02', note: 'Rent', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
  ],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('Transactions', () => {
  it('renders the Transactions heading', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Transactions />)
    expect(screen.getByText('Transactions')).toBeInTheDocument()
  })

  it('renders the Add Transaction button', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Transactions />)
    expect(screen.getByText('Add Transaction')).toBeInTheDocument()
  })

  it('renders the AI Parse section', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Transactions />)
    expect(screen.getByText('AI Parse from Bank SMS')).toBeInTheDocument()
  })

  it('renders transaction list with entries', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Transactions />)
    expect(screen.getByText('Salary')).toBeInTheDocument()
    expect(screen.getByText('Rent')).toBeInTheDocument()
  })

  it('shows empty state when no plan exists', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      plan: null,
    })
    render(<Transactions />)
    expect(screen.getByText('No plan for this month yet')).toBeInTheDocument()
  })

  it('shows loading state', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      loading: true,
    })
    render(<Transactions />)
    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })

  it('renders filter buttons (all, income, expense)', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<Transactions />)
    expect(screen.getByText('all')).toBeInTheDocument()
    expect(screen.getByText('income')).toBeInTheDocument()
    expect(screen.getByText('expense')).toBeInTheDocument()
  })

  it('renders reimbursement transactions with Reimbursement label and no split button on the reimbursement row', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      transactions: [
        { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 80000, type: 'income' as const, txn_date: '2026-09-01', note: 'Salary', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
        { id: 't-2', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-2', amount: 15000, type: 'expense' as const, txn_date: '2026-09-02', note: 'Rent', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
        { id: 't-3', user_id: 'user-1', plan_id: 'plan-1', category_id: null, amount: 5000, type: 'reimbursement' as const, txn_date: '2026-09-03', note: 'Reimbursement from friend', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
      ],
    })
    render(<Transactions />)
    expect(screen.getByText('Reimbursement')).toBeInTheDocument()
    // Only the expense row should have a split button; there should be exactly 1 split button
    const splitButtons = screen.getAllByLabelText(/split this expense/i)
    expect(splitButtons).toHaveLength(1)
  })
})
