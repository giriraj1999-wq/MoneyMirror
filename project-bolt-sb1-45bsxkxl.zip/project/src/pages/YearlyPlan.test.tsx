import { describe, it, expect, vi } from 'vitest'
import { render, screen, waitFor } from '@testing-library/react'

import YearlyPlan from '@/pages/YearlyPlan'

describe('YearlyPlan', () => {
  it('renders the stepper with 5 steps', async () => {
    render(<YearlyPlan />)
    await waitFor(() => {
      expect(screen.getByText('Income')).toBeInTheDocument()
      expect(screen.getByText('Savings')).toBeInTheDocument()
      expect(screen.getByText('Variable Budgets')).toBeInTheDocument()
      expect(screen.getByText('Review')).toBeInTheDocument()
      expect(screen.getByText('Generate')).toBeInTheDocument()
    })
  })

  it('renders the monthly income question on step 1', async () => {
    render(<YearlyPlan />)
    await waitFor(() => expect(screen.getByText("What's your monthly income?")).toBeInTheDocument())
  })

  it('renders the monthly income input field', async () => {
    render(<YearlyPlan />)
    await waitFor(() => expect(screen.getByLabelText('Monthly net income')).toBeInTheDocument())
  })

  it('renders the Continue button', async () => {
    render(<YearlyPlan />)
    await waitFor(() => expect(screen.getByText('Continue')).toBeInTheDocument())
  })
})
