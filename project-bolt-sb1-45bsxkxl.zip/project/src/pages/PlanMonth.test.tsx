import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'

const mockUseMonthData = vi.fn()
vi.mock('@/hooks/useMonthData', () => ({
  useMonthData: () => mockUseMonthData(),
}))

vi.mock('@/pages/MonthlyReview', () => ({
  default: () => <div data-testid="monthly-review-mock">Monthly Review</div>,
}))

import PlanMonth from '@/pages/PlanMonth'

const defaultProps = {
  month: '2026-09-01',
  loading: false,
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
    { id: 'cat-2', user_id: 'user-1', name: 'Salary', is_essential: false, type: 'income' as const, created_at: '' },
  ],
  budgets: [
    { id: 'b-1', plan_id: 'plan-1', category_id: 'cat-1', planned_amount: 15000 },
  ],
  transactions: [],
  commitments: [],
  outgoingShares: [],
  incomingShares: [],
  refetch: vi.fn(),
  ensurePlan: vi.fn(),
  setPlan: vi.fn(),
  setCategories: vi.fn(),
  setBudgets: vi.fn(),
  setTransactions: vi.fn(),
  setCommitments: vi.fn(),
  setOutgoingShares: vi.fn(),
  setIncomingShares: vi.fn(),
}

describe('PlanMonth', () => {
  it('renders the Plan My Month tab', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getAllByText('Plan My Month').length).toBeGreaterThan(0)
  })

  it('renders the two Plan tabs', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getAllByText('Plan My Month').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Monthly Review').length).toBeGreaterThan(0)
    expect(screen.queryByText('Yearly Plan')).not.toBeInTheDocument()
    expect(screen.queryByText('Goals')).not.toBeInTheDocument()
  })

  it('renders plan fields', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getByText('Opening Balance')).toBeInTheDocument()
    expect(screen.getByText('Expected Income')).toBeInTheDocument()
    expect(screen.getByText('Protected Savings')).toBeInTheDocument()
  })

  it('renders the Save Plan button', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getByText('Save Plan')).toBeInTheDocument()
  })

  it('renders the Set budgets section', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getByText('Set budgets')).toBeInTheDocument()
  })

  it('renders the Save Budgets button', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getByText('Save Budgets')).toBeInTheDocument()
  })

  it('renders existing categories', () => {
    mockUseMonthData.mockReturnValue(defaultProps)
    render(<PlanMonth />)
    expect(screen.getAllByText('Rent').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Salary').length).toBeGreaterThan(0)
  })

  it('shows loading state', () => {
    mockUseMonthData.mockReturnValue({
      ...defaultProps,
      loading: true,
    })
    render(<PlanMonth />)
    expect(screen.getByText('Loading...')).toBeInTheDocument()
  })
})
