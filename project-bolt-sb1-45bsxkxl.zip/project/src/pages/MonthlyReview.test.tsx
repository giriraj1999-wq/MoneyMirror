import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import MonthlyReview from '@/pages/MonthlyReview'

const defaultProps = {
  month: '2026-09-01',
  plan: {
    id: 'plan-1',
    user_id: 'user-1',
    month: '2026-09-01',
    opening_balance: 50000,
    expected_income: 80000,
    protected_savings: 10000,
    base_currency: 'INR',
    created_at: '',
    updated_at: '',
  },
  categories: [
    { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
    { id: 'cat-2', user_id: 'user-1', name: 'Groceries', is_essential: true, is_fixed: true, type: 'expense' as const, created_at: '' },
  ],
  budgets: [
    { id: 'b-1', plan_id: 'plan-1', category_id: 'cat-1', planned_amount: 15000 },
    { id: 'b-2', plan_id: 'plan-1', category_id: 'cat-2', planned_amount: 8000 },
  ],
  transactions: [
    { id: 't-1', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-1', amount: 15000, type: 'expense' as const, txn_date: '2026-09-02', note: 'Rent', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
    { id: 't-2', user_id: 'user-1', plan_id: 'plan-1', category_id: 'cat-2', amount: 4000, type: 'expense' as const, txn_date: '2026-09-03', note: 'Groceries', source: 'manual' as const, currency: 'INR', bill_url: null, bill_path: null, commitment_id: null, amount_base: null, created_at: '', updated_at: '' },
  ],
}

describe('MonthlyReview', () => {
  it('renders the Gap Analysis Formula heading', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText('Gap Analysis Formula')).toBeInTheDocument()
  })

  it('renders the Category Variance Table heading', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText('Category Variance Table')).toBeInTheDocument()
  })

  it('renders the Ranked Course-Correction Cards heading', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText('Ranked Course-Correction Cards')).toBeInTheDocument()
  })

  it('renders category names in the variance table', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText('Rent')).toBeInTheDocument()
    expect(screen.getByText('Groceries')).toBeInTheDocument()
  })

  it('renders the month label', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText(/September 2026 review/i)).toBeInTheDocument()
  })

  it('renders budgeted amounts', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText('Budgeted: ₹15,000')).toBeInTheDocument()
    expect(screen.getByText('Budgeted: ₹8,000')).toBeInTheDocument()
  })

  it('renders actual spent amounts', () => {
    render(<MonthlyReview {...defaultProps} />)
    expect(screen.getByText('₹15,000')).toBeInTheDocument()
    expect(screen.getByText('₹4,000')).toBeInTheDocument()
  })

  it('renders with empty categories', () => {
    render(
      <MonthlyReview
        {...defaultProps}
        categories={[]}
        budgets={[]}
        transactions={[]}
      />
    )
    expect(screen.getByText('Gap Analysis Formula')).toBeInTheDocument()
  })
})
