import { describe, it, expect } from 'vitest'
import { regexParse } from '@/lib/smsParser'

describe('regexParse — SMS fallback parser', () => {
  it('extracts amount from UPI debit message with ₹ symbol', () => {
    const result = regexParse('₹500.00 debited from your account to swiggy@axisb')
    expect(result.amount).toBe(500)
    expect(result.type).toBe('expense')
    expect(result.currency).toBe('INR')
    expect(result.merchant_or_description).toBe('swiggy@axisb')
    expect(result.suggested_category).toBe('Dining Out')
    expect(result.confidence).toBeGreaterThan(0)
  })

  it('extracts amount from Rs prefix', () => {
    const result = regexParse('Rs 1500 paid to BIGBASKET')
    expect(result.amount).toBe(1500)
    expect(result.type).toBe('expense')
    expect(result.suggested_category).toBe('Groceries')
  })

  it('detects income from credited keyword', () => {
    const result = regexParse('INR 50000 credited to your account. Salary from EMPLOYER CORP')
    expect(result.amount).toBe(50000)
    expect(result.type).toBe('income')
    expect(result.suggested_category).toBe('Salary')
  })

  it('handles comma-separated amounts', () => {
    const result = regexParse('₹1,50,000 debited for rent payment to landlord')
    expect(result.amount).toBe(150000)
    expect(result.suggested_category).toBe('Rent')
  })

  it('detects USD currency', () => {
    const result = regexParse('$25.99 paid at Starbucks')
    expect(result.amount).toBe(25.99)
    expect(result.currency).toBe('USD')
  })

  it('detects EUR currency', () => {
    const result = regexParse('€30 debited for train booking via IRCTC')
    expect(result.amount).toBe(30)
    expect(result.currency).toBe('EUR')
    expect(result.suggested_category).toBe('Transport')
  })

  it('detects entertainment category from Netflix', () => {
    const result = regexParse('₹649 debited for Netflix subscription')
    expect(result.amount).toBe(649)
    expect(result.suggested_category).toBe('Entertainment')
  })

  it('detects utilities category from electricity bill', () => {
    const result = regexParse('Rs 2300 paid for electricity bill')
    expect(result.amount).toBe(2300)
    expect(result.suggested_category).toBe('Utilities')
  })

  it('detects transport category from Uber', () => {
    const result = regexParse('₹120 debited to Uber')
    expect(result.amount).toBe(120)
    expect(result.suggested_category).toBe('Transport')
  })

  it('returns null amount when no number found', () => {
    const result = regexParse('Your transaction was successful')
    expect(result.amount).toBeNull()
    expect(result.confidence).toBe(0)
  })

  it('returns expense type by default', () => {
    const result = regexParse('₹200 spent at cafe')
    expect(result.type).toBe('expense')
  })

  it('extracts VPA as merchant description', () => {
    const result = regexParse('₹100 sent to john@okhdfcbank')
    expect(result.merchant_or_description).toBe('john@okhdfcbank')
  })

  it('detects refund as income', () => {
    const result = regexParse('₹500 refund received from Amazon')
    expect(result.type).toBe('income')
  })

  it('handles amount with "paid:" prefix', () => {
    const result = regexParse('Amount paid: 750 for fuel at HP PETROL')
    expect(result.amount).toBe(750)
    expect(result.suggested_category).toBe('Transport')
  })
})
