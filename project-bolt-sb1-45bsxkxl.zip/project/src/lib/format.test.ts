import { describe, it, expect } from 'vitest'
import {
  formatCurrency,
  formatDate,
  getMonthStart,
  getMonthLabel,
  getCurrencySymbol,
  CURRENCIES,
} from '@/lib/format'

describe('formatCurrency', () => {
  it('formats positive amounts with INR symbol by default', () => {
    expect(formatCurrency(50000)).toBe('₹50,000')
  })

  it('formats with decimal amounts', () => {
    expect(formatCurrency(1234.56)).toBe('₹1,234.56')
  })

  it('formats negative amounts with minus sign', () => {
    expect(formatCurrency(-5000)).toBe('−₹5,000')
  })

  it('formats zero', () => {
    expect(formatCurrency(0)).toBe('₹0')
  })

  it('respects currency parameter', () => {
    expect(formatCurrency(100, 'USD')).toBe('$100')
    expect(formatCurrency(100, 'EUR')).toBe('€100')
    expect(formatCurrency(100, 'GBP')).toBe('£100')
  })

  it('uses Indian number formatting (lakh/crore)', () => {
    expect(formatCurrency(100000)).toBe('₹1,00,000')
    expect(formatCurrency(10000000)).toBe('₹1,00,00,000')
  })
})

describe('formatDate', () => {
  it('formats a date string in readable format', () => {
    const result = formatDate('2026-09-26')
    expect(result).toMatch(/Sep/)
    expect(result).toMatch(/26/)
    expect(result).toMatch(/2026/)
  })
})

describe('getMonthStart', () => {
  it('returns first day of current month', () => {
    const date = new Date(2026, 8, 15) // Sep 15, 2026
    const result = getMonthStart(date)
    expect(result).toBe('2026-09-01')
  })

  it('pads single-digit months', () => {
    const date = new Date(2026, 0, 5) // Jan 5, 2026
    const result = getMonthStart(date)
    expect(result).toBe('2026-01-01')
  })

  it('handles December', () => {
    const date = new Date(2026, 11, 31) // Dec 31, 2026
    const result = getMonthStart(date)
    expect(result).toBe('2026-12-01')
  })
})

describe('getMonthLabel', () => {
  it('returns full month name and year', () => {
    const result = getMonthLabel('2026-09-01')
    expect(result).toBe('September 2026')
  })

  it('handles January', () => {
    const result = getMonthLabel('2026-01-01')
    expect(result).toBe('January 2026')
  })
})

describe('getCurrencySymbol', () => {
  it('returns correct symbol for known currencies', () => {
    expect(getCurrencySymbol('INR')).toBe('₹')
    expect(getCurrencySymbol('USD')).toBe('$')
    expect(getCurrencySymbol('EUR')).toBe('€')
    expect(getCurrencySymbol('GBP')).toBe('£')
    expect(getCurrencySymbol('JPY')).toBe('¥')
  })

  it('returns the code itself for unknown currencies', () => {
    expect(getCurrencySymbol('XYZ')).toBe('XYZ')
  })
})

describe('CURRENCIES', () => {
  it('contains at least 10 currencies', () => {
    expect(CURRENCIES.length).toBeGreaterThanOrEqual(10)
  })

  it('each currency has code, symbol, and label', () => {
    for (const c of CURRENCIES) {
      expect(c.code).toBeTruthy()
      expect(c.symbol).toBeTruthy()
      expect(c.label).toBeTruthy()
    }
  })

  it('includes INR, USD, EUR, GBP', () => {
    const codes = CURRENCIES.map((c) => c.code)
    expect(codes).toContain('INR')
    expect(codes).toContain('USD')
    expect(codes).toContain('EUR')
    expect(codes).toContain('GBP')
  })
})
