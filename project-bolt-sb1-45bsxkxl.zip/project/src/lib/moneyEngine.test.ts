import { describe, it, expect } from 'vitest'
import { computeAAC, simulateExpense } from '@/lib/moneyEngine'
import type { Plan, Transaction, Commitment, Category, Budget } from '@/types'

const mockPlan: Plan = {
  id: 'plan-1',
  user_id: 'user-1',
  month: '2026-09-01',
  opening_balance: 50000,
  expected_income: 80000,
  protected_savings: 10000,
  base_currency: 'INR',
  created_at: '2026-09-01T00:00:00Z',
  updated_at: '2026-09-01T00:00:00Z',
}

const mockCategories: Category[] = [
  { id: 'cat-1', user_id: 'user-1', name: 'Rent', is_essential: true, is_fixed: true, type: 'expense', created_at: '' },
  { id: 'cat-2', user_id: 'user-1', name: 'Groceries', is_essential: true, is_fixed: true, type: 'expense', created_at: '' },
  { id: 'cat-3', user_id: 'user-1', name: 'Dining Out', is_essential: false, is_fixed: false, type: 'expense', created_at: '' },
  { id: 'cat-4', user_id: 'user-1', name: 'Subscription', is_essential: false, is_fixed: true, type: 'expense', created_at: '' },
  { id: 'cat-5', user_id: 'user-1', name: 'Salary', is_essential: false, is_fixed: false, type: 'income', created_at: '' },
]

const mockBudgets: Budget[] = [
  { id: 'b-1', plan_id: 'plan-1', category_id: 'cat-1', planned_amount: 15000 },
  { id: 'b-2', plan_id: 'plan-1', category_id: 'cat-2', planned_amount: 8000 },
  { id: 'b-3', plan_id: 'plan-1', category_id: 'cat-4', planned_amount: 500 },
]

const baseTxn = {
  user_id: 'user-1',
  plan_id: 'plan-1',
  source: 'manual' as const,
  currency: 'INR',
  bill_url: null,
  bill_path: null,
  commitment_id: null,
  created_at: '',
  updated_at: '',
}

const mockTransactions: Transaction[] = [
  { ...baseTxn, id: 't-1', category_id: 'cat-5', amount: 80000, type: 'income', txn_date: '2026-09-01', note: 'Salary', amount_base: null },
  { ...baseTxn, id: 't-2', category_id: 'cat-1', amount: 15000, type: 'expense', txn_date: '2026-09-02', note: 'Rent', amount_base: null },
  { ...baseTxn, id: 't-3', category_id: 'cat-2', amount: 4000, type: 'expense', txn_date: '2026-09-03', note: 'Groceries', amount_base: null },
  { ...baseTxn, id: 't-4', category_id: 'cat-3', amount: 2000, type: 'expense', txn_date: '2026-09-04', note: 'Dinner', amount_base: null },
]

const mockCommitments: Commitment[] = [
  { id: 'c-1', user_id: 'user-1', plan_id: 'plan-1', title: 'Electricity', amount: 2500, due_date: '2026-09-10', is_paid: false, paid_at: null, created_at: '' },
  { id: 'c-2', user_id: 'user-1', plan_id: 'plan-1', title: 'Credit Card', amount: 5000, due_date: '2026-09-15', is_paid: true, paid_at: '2026-09-14T00:00:00Z', created_at: '' },
]

describe('computeAAC', () => {
  it('uses expected_income for AAC, not actual income', () => {
    const result = computeAAC(mockPlan, mockTransactions, [], [], [])
    // AAC = opening 50000 + expected_income 80000 - savings 10000 - expenses 21000 = 99000
    expect(result.expectedIncome).toBe(80000)
    expect(result.actualIncome).toBe(80000)
    expect(result.aac).toBe(99000)
    expect(result.verdict).toBe('PLAN HOLDS')
  })

  it('AAC stays stable when salary is late (actual income < expected)', () => {
    const lateSalaryTxns = mockTransactions.filter((t) => t.type !== 'income')
    const result = computeAAC(mockPlan, lateSalaryTxns, [], [], [])
    // No actual income, but AAC should still use expected_income
    expect(result.actualIncome).toBe(0)
    expect(result.aac).toBe(99000)
    expect(result.verdict).toBe('PLAN HOLDS')
  })

  it('currentBalance uses actual income from transactions', () => {
    const result = computeAAC(mockPlan, mockTransactions, [], [], [])
    // 50000 + 80000 - 21000 = 109000
    expect(result.currentBalance).toBe(109000)
  })

  it('subtracts protected savings from available money', () => {
    const result = computeAAC(mockPlan, mockTransactions, [], [], [])
    expect(result.protectedSavings).toBe(10000)
  })

  it('subtracts unpaid commitments', () => {
    const result = computeAAC(mockPlan, mockTransactions, mockCommitments, [], [])
    expect(result.unpaidCommitments).toBe(2500)
    // 99000 - 2500 = 96500
    expect(result.aac).toBe(96500)
    expect(result.verdict).toBe('PLAN HOLDS')
  })

  it('reserves money for both essential AND fixed categories', () => {
    const result = computeAAC(mockPlan, mockTransactions, mockCommitments, mockCategories, mockBudgets)
    // Rent: budget 15000, spent 15000, remaining 0
    // Groceries: budget 8000, spent 4000, remaining 4000
    // Subscription (fixed but not essential): budget 500, spent 0, remaining 500
    expect(result.remainingEssential).toBe(4500)
    // 96500 - 4500 = 92000
    expect(result.aac).toBe(92000)
    expect(result.verdict).toBe('PLAN HOLDS')
  })

  it('reports SHORTFALL when AAC goes negative', () => {
    const bigCommitments: Commitment[] = [
      { id: 'c-big', user_id: 'user-1', plan_id: 'plan-1', title: 'Huge bill', amount: 200000, due_date: '2026-09-20', is_paid: false, paid_at: null, created_at: '' },
    ]
    const result = computeAAC(mockPlan, mockTransactions, bigCommitments, [], [])
    // 99000 - 200000 = -101000
    expect(result.aac).toBe(-101000)
    expect(result.verdict).toBe('SHORTFALL')
  })

  it('reports WARNING when a category is over 120% of budget', () => {
    const overBudgetTxns: Transaction[] = [
      { ...baseTxn, id: 't-1', category_id: 'cat-5', amount: 80000, type: 'income', txn_date: '2026-09-01', note: 'Salary', amount_base: null },
      { ...baseTxn, id: 't-2', category_id: 'cat-1', amount: 15000, type: 'expense', txn_date: '2026-09-02', note: 'Rent', amount_base: null },
      // Groceries: budget 8000, spent 14000 = 175%
      { ...baseTxn, id: 't-3', category_id: 'cat-2', amount: 14000, type: 'expense', txn_date: '2026-09-03', note: 'Groceries', amount_base: null },
    ]
    const result = computeAAC(mockPlan, overBudgetTxns, [], mockCategories, mockBudgets)
    expect(result.verdict).toBe('WARNING')
  })

  it('does not double-count commitment-linked expense transactions', () => {
    // Commitment c-1 is unpaid but has a linked expense transaction
    const linkedTxns: Transaction[] = [
      ...mockTransactions,
      { ...baseTxn, id: 't-5', category_id: null, amount: 2500, type: 'expense', txn_date: '2026-09-05', note: 'Electricity', amount_base: null, commitment_id: 'c-1' },
    ]
    const result = computeAAC(mockPlan, linkedTxns, mockCommitments, [], [])
    // The commitment c-1 is unpaid but has a linked txn, so it should NOT be
    // subtracted again as unpaidCommitments
    expect(result.unpaidCommitments).toBe(0)
    // AAC = 50000 + 80000 - 10000 - 0 (no unpaid) - 23500 (expenses) = 96500
    expect(result.aac).toBe(96500)
  })

  it('handles null plan gracefully', () => {
    const result = computeAAC(null, [], [], [], [])
    expect(result.currentBalance).toBe(0)
    expect(result.aac).toBe(0)
    expect(result.verdict).toBe('PLAN HOLDS')
  })

  it('handles empty transactions', () => {
    const result = computeAAC(mockPlan, [], [], [], [])
    // opening 50000 + expected 80000 - savings 10000 = 120000
    expect(result.currentBalance).toBe(50000)
    expect(result.aac).toBe(120000)
  })

  it('uses integer paise internally to avoid floating-point drift', () => {
    const planWithDecimals: Plan = {
      ...mockPlan,
      opening_balance: 100.01,
      protected_savings: 50.05,
    }
    const txnsWithDecimals: Transaction[] = [
      { ...baseTxn, id: 'd-1', category_id: null, amount: 33.33, type: 'income', txn_date: '2026-09-01', note: '', amount_base: null },
      { ...baseTxn, id: 'd-2', category_id: null, amount: 11.11, type: 'expense', txn_date: '2026-09-02', note: '', amount_base: null },
    ]
    const result = computeAAC(planWithDecimals, txnsWithDecimals, [], [], [])
    // AAC = 100.01 + 80000 - 50.05 - 11.11 = 80038.85
    const rounded = Math.round(result.aac * 100) / 100
    expect(result.aac).toBe(rounded)
  })
})

describe('simulateExpense', () => {
  it('returns PLAN HOLDS when expense is within AAC', () => {
    const result = simulateExpense(50000, 30000)
    expect(result.before).toBe(50000)
    expect(result.after).toBe(20000)
    expect(result.verdict).toBe('PLAN HOLDS')
    expect(result.shortfall).toBe(0)
    expect(result.exposedAmount).toBe(0)
  })

  it('returns SHORTFALL when expense exceeds AAC', () => {
    const result = simulateExpense(50000, 80000)
    expect(result.before).toBe(50000)
    expect(result.after).toBe(-30000)
    expect(result.verdict).toBe('SHORTFALL')
    expect(result.shortfall).toBe(30000)
    expect(result.exposedAmount).toBe(30000)
  })

  it('handles exact boundary (expense equals AAC)', () => {
    const result = simulateExpense(50000, 50000)
    expect(result.after).toBe(0)
    expect(result.verdict).toBe('PLAN HOLDS')
    expect(result.shortfall).toBe(0)
  })

  it('handles zero AAC', () => {
    const result = simulateExpense(0, 100)
    expect(result.after).toBe(-100)
    expect(result.verdict).toBe('SHORTFALL')
    expect(result.shortfall).toBe(100)
  })

  it('handles decimal amounts without floating-point drift', () => {
    const result = simulateExpense(100.05, 50.03)
    expect(result.after).toBe(50.02)
    expect(result.after).not.toBe(50.02000000000001)
  })
})
