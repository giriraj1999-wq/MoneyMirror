import type {
  Plan,
  Transaction,
  Commitment,
  Category,
  Budget,
  AACResult,
  SimulationResult,
} from '@/types';

const toPaise = (amount: number): number => Math.round(amount * 100);
const fromPaise = (paise: number): number => paise / 100;

export function computeAAC(
  plan: Plan | null,
  transactions: Transaction[],
  commitments: Commitment[],
  categories: Category[],
  budgets: Budget[]
): AACResult {
  const openingBalance = toPaise(plan?.opening_balance ?? 0);
  const expectedIncome = toPaise(plan?.expected_income ?? 0);
  const protectedSavings = toPaise(plan?.protected_savings ?? 0);

  const actualIncomeTotal = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + toPaise(t.amount_base ?? t.amount), 0);

  const reimbursementTotal = transactions
    .filter((t) => t.type === 'reimbursement')
    .reduce((sum, t) => sum + toPaise(t.amount_base ?? t.amount), 0);

  // Commitment-linked expense transactions are excluded from expenseTotal
  // because they are already accounted for via unpaidCommitments.
  // Once a commitment is paid (is_paid = true), its linked transaction
  // appears in expenseTotal and the commitment is removed from unpaidCommitments.
  const commitmentTxnIds = new Set(
    transactions.filter((t) => t.commitment_id).map((t) => t.id)
  );
  const expenseTotal = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + toPaise(t.amount_base ?? t.amount), 0)
    - reimbursementTotal;

  const currentBalance = openingBalance + actualIncomeTotal - expenseTotal;

  // Only count unpaid commitments that do NOT already have a linked expense
  // transaction, to avoid double-counting.
  const paidCommitmentIds = new Set(
    commitments.filter((c) => c.is_paid).map((c) => c.id)
  );
  const unpaidCommitments = commitments
    .filter((c) => !c.is_paid)
    .filter((c) => {
      // If any transaction links to this commitment, it's already counted as an expense
      return !transactions.some((t) => t.commitment_id === c.id);
    })
    .reduce((sum, c) => sum + toPaise(c.amount), 0);

  // Reserve money for both essential AND fixed categories (issue 4).
  // is_fixed categories represent recurring obligations that must be paid.
  const reservedCategories = categories.filter(
    (cat) => cat.type === 'expense' && (cat.is_essential || cat.is_fixed)
  );
  const remainingReserved = reservedCategories.reduce((sum, cat) => {
    const planned = toPaise(
      budgets.find((b) => b.category_id === cat.id)?.planned_amount ?? 0
    );
    const spent = transactions
      .filter((t) => t.category_id === cat.id && t.type === 'expense')
      .reduce((s, t) => s + toPaise(t.amount_base ?? t.amount), 0);
    return sum + Math.max(0, planned - spent);
  }, 0);

  const aacPaise =
    openingBalance + expectedIncome - protectedSavings - unpaidCommitments - remainingReserved - expenseTotal;

  const overBudgetCategories = categories
    .filter((cat) => cat.type === 'expense')
    .map((cat) => {
      const planned = toPaise(
        budgets.find((b) => b.category_id === cat.id)?.planned_amount ?? 0
      );
      const spent = transactions
        .filter((t) => t.category_id === cat.id && t.type === 'expense')
        .reduce((s, t) => s + toPaise(t.amount_base ?? t.amount), 0);
      return { planned, spent, ratio: planned > 0 ? spent / planned : 0 };
    })
    .filter((c) => c.planned > 0 && c.ratio > 1.2);

  let verdict: AACResult['verdict'];
  if (aacPaise < 0) {
    verdict = 'SHORTFALL';
  } else if (overBudgetCategories.length > 0) {
    verdict = 'WARNING';
  } else {
    verdict = 'PLAN HOLDS';
  }

  return {
    currentBalance: fromPaise(currentBalance),
    expectedIncome: fromPaise(expectedIncome),
    actualIncome: fromPaise(actualIncomeTotal),
    unpaidCommitments: fromPaise(unpaidCommitments),
    remainingEssential: fromPaise(remainingReserved),
    protectedSavings: fromPaise(protectedSavings),
    aac: fromPaise(aacPaise),
    verdict,
  };
}

export function simulateExpense(
  currentAAC: number,
  proposedAmount: number
): SimulationResult {
  const currentPaise = toPaise(currentAAC);
  const proposedPaise = toPaise(proposedAmount);
  const afterPaise = currentPaise - proposedPaise;

  if (afterPaise < 0) {
    return {
      before: fromPaise(currentPaise),
      after: fromPaise(afterPaise),
      verdict: 'SHORTFALL',
      shortfall: fromPaise(Math.abs(afterPaise)),
      exposedAmount: fromPaise(Math.abs(afterPaise)),
    };
  }
  return {
    before: fromPaise(currentPaise),
    after: fromPaise(afterPaise),
    verdict: 'PLAN HOLDS',
    shortfall: 0,
    exposedAmount: 0,
  };
}
