export const CURRENCIES = [
  { code: 'INR', symbol: '₹', label: 'Indian Rupee' },
  { code: 'USD', symbol: '$', label: 'US Dollar' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
  { code: 'GBP', symbol: '£', label: 'British Pound' },
  { code: 'AED', symbol: 'AED', label: 'UAE Dirham' },
  { code: 'SGD', symbol: 'S$', label: 'Singapore Dollar' },
  { code: 'AUD', symbol: 'A$', label: 'Australian Dollar' },
  { code: 'CAD', symbol: 'C$', label: 'Canadian Dollar' },
  { code: 'JPY', symbol: '¥', label: 'Japanese Yen' },
  { code: 'CHF', symbol: 'CHF', label: 'Swiss Franc' },
] as const;

export type CurrencyCode = (typeof CURRENCIES)[number]['code'];

const CURRENCY_MAP = new Map(CURRENCIES.map((c) => [c.code, c.symbol]));

export function getCurrencySymbol(code: string): string {
  return CURRENCY_MAP.get(code as CurrencyCode) ?? code;
}

export function formatCurrency(amount: number, currency = 'INR'): string {
  const abs = Math.abs(amount);
  const symbol = getCurrencySymbol(currency);
  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(abs);
  const result = `${symbol}${formatted}`;
  return amount < 0 ? `−${result}` : result;
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function getMonthStart(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}-01`;
}

export function getMonthLabel(monthStr: string): string {
  return new Date(monthStr + 'T00:00:00').toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric',
  });
}
