import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('@/lib/supabase', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn(() => ({
        eq: vi.fn(() => ({
          eq: vi.fn(() => ({ maybeSingle: vi.fn(async () => ({ data: null })) })),
        })),
      })),
    })),
  },
}));

import { getCarryForward, getPreviousMonth } from '@/lib/carryForward';

describe('getPreviousMonth', () => {
  it('returns the previous month string', () => {
    expect(getPreviousMonth('2026-09-01')).toBe('2026-08-01');
  });

  it('handles year boundary', () => {
    expect(getPreviousMonth('2026-01-01')).toBe('2025-12-01');
  });
});

describe('getCarryForward', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns zeros when no previous plan exists', async () => {
    const result = await getCarryForward('user-1', '2026-09-01');
    expect(result.opening_balance).toBe(0);
    expect(result.expected_income).toBe(0);
    expect(result.protected_savings).toBe(0);
  });
});
