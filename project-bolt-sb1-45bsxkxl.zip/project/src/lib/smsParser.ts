export interface ParseDraft {
  amount: number | null;
  currency: string;
  merchant_or_description: string | null;
  type: "income" | "expense";
  suggested_category: string | null;
  confidence: number;
}

// Regex fallback parser for common bank SMS / UPI message formats.
// Handles Indian and international patterns: Rs, INR, ₹, $, USD, etc.
export function regexParse(text: string): ParseDraft {
  const lower = text.toLowerCase();

  // Amount: look for currency-prefixed or suffixed numbers (supports decimals and commas)
  const amountMatch =
    text.match(/(?:rs\.?\s*|inr\s*|₹\s*|\$\s*|€\s*|usd\s*|eur\s*|gbp\s*)\s*([\d,]+\.?\d*)/i) ||
    text.match(/([\d,]+\.?\d*)\s*(?:rs\.?|inr|₹|\$|€|usd|eur|gbp)/i) ||
    text.match(/(?:amount|amt|paid|debited|credited|received|sent)\s*[:\-]?\s*([\d,]+\.?\d*)/i);

  let amount: number | null = null;
  if (amountMatch) {
    amount = parseFloat(amountMatch[1].replace(/,/g, ""));
    if (isNaN(amount) || amount <= 0) amount = null;
  }

  // Currency detection
  let currency = "INR";
  if (/\$|usd/i.test(text)) currency = "USD";
  else if (/€|eur/i.test(text)) currency = "EUR";
  else if (/£|gbp/i.test(text)) currency = "GBP";

  // Type: credited/received/refund = income; debited/paid/sent/spent = expense
  let type: "income" | "expense" = "expense";
  if (/(credited|received|refund|salary|deposited|cashback|rewards?|interest)/i.test(lower)) {
    type = "income";
  }

  // Merchant / description: try VPA (name@bank), then "to"/"from"/"at" patterns
  let merchant: string | null = null;
  const vpaMatch = text.match(/([a-zA-Z0-9._-]+@[a-zA-Z]{3,})/);
  if (vpaMatch) {
    merchant = vpaMatch[1];
  } else {
    const toFromMatch =
      text.match(/(?:to|at)\s+([A-Z][A-Za-z0-9\s&'.-]{2,30})/i) ||
      text.match(/from\s+([A-Z][A-Za-z0-9\s&'.-]{2,30})/i);
    if (toFromMatch) merchant = toFromMatch[1].trim();
  }

  // Category suggestion based on keywords
  let suggestedCategory: string | null = null;
  const categoryMap: Record<string, string> = {
    grocery: "Groceries", groceries: "Groceries", supermarket: "Groceries", bigbasket: "Groceries", blinkit: "Groceries", zepto: "Groceries",
    rent: "Rent", landlord: "Rent", housing: "Rent",
    electric: "Utilities", electricity: "Utilities", water: "Utilities", gas: "Utilities", broadband: "Utilities", wifi: "Utilities", internet: "Utilities", mobile: "Utilities", recharge: "Utilities", bill: "Utilities",
    uber: "Transport", ola: "Transport", rapido: "Transport", fuel: "Transport", petrol: "Transport", diesel: "Transport", metro: "Transport", bus: "Transport", train: "Transport", irctc: "Transport",
    restaurant: "Dining Out", swiggy: "Dining Out", zomato: "Dining Out", domino: "Dining Out", kfc: "Dining Out", mcdonald: "Dining Out", pizza: "Dining Out", cafe: "Dining Out", coffee: "Dining Out", dining: "Dining Out",
    netflix: "Entertainment", prime: "Entertainment", hotstar: "Entertainment", spotify: "Entertainment", movie: "Entertainment", pvr: "Entertainment", inox: "Entertainment", steam: "Entertainment", game: "Entertainment",
    salary: "Salary", payroll: "Salary",
    stock: "Stock Market", stocks: "Stock Market", zerodha: "Stock Market", groww: "Stock Market", trading: "Stock Market",
    interest: "Interest on Deposits", fd: "Interest on Deposits", savings: "Interest on Deposits",
    bonus: "Employee Bonus",
    crypto: "Crypto", wazirx: "Crypto", coinbase: "Crypto",
    freelance: "Freelancing", consulting: "Consultancy", consultancy: "Consultancy",
    rental: "Rental Income", rent_income: "Rental Income",
    dividend: "Dividends",
    gift: "Gift",
  };

  for (const keyword of Object.keys(categoryMap)) {
    if (lower.includes(keyword)) {
      suggestedCategory = categoryMap[keyword];
      break;
    }
  }

  const confidence = amount !== null ? 0.6 : 0;

  return {
    amount,
    currency,
    merchant_or_description: merchant,
    type,
    suggested_category: suggestedCategory,
    confidence,
  };
}
