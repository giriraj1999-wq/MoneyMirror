import { supabase } from '@/lib/supabase';
import type { Plan, Transaction } from '@/types';

export interface CarryForward {
  opening_balance: number;
  expected_income: number;
  protected_savings: number;
}

export function getPreviousMonth(monthStr: string): string {
  // Use UTC to avoid timezone shifts that can land on the wrong day
  const d = new Date(monthStr + 'T00:00:00Z');
  d.setUTCMonth(d.getUTCMonth() - 1);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  return `${y}-${m}-01`;
}

export async function getCarryForward(
  userId: string,
  monthStr: string
): Promise<CarryForward> {
  const prevMonth = getPreviousMonth(monthStr);

  const { data: prevPlan } = await supabase
    .from('plans')
    .select('*')
    .eq('user_id', userId)
    .eq('month', prevMonth)
    .maybeSingle();

  if (!prevPlan) {
    return { opening_balance: 0, expected_income: 0, protected_savings: 0 };
  }

  const plan = prevPlan as Plan;

  const { data: txnData } = await supabase
    .from('transactions')
    .select('*')
    .eq('plan_id', plan.id);

  const transactions = (txnData as Transaction[]) ?? [];

  const incomeTotal = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
  const expenseTotal = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);
  const reimbursementTotal = transactions
    .filter((t) => t.type === 'reimbursement')
    .reduce((sum, t) => sum + (t.amount_base ?? t.amount), 0);

  const closingBalance = plan.opening_balance + incomeTotal - expenseTotal + reimbursementTotal;

  return {
    // Preserve negative balances so overspending is visible next month (issue 9)
    opening_balance: closingBalance,
    // Do not copy stale expected_income and protected_savings —
    // the user should set fresh targets for the new month (issue 9)
    expected_income: 0,
    protected_savings: 0,
  };
}
