import '@testing-library/jest-dom/vitest'
import { vi } from 'vitest'
import { cleanup } from '@testing-library/react'
import { afterEach } from 'vitest'

afterEach(() => {
  cleanup()
})

// Chainable thenable mock for supabase query methods.
// supabase query builders are thenable — you can `await` them directly.
function chainableMock(resolvedValue: any = { data: null, error: null }) {
  const obj: any = {}
  const methods = ['select', 'insert', 'update', 'delete', 'eq', 'neq', 'order', 'limit', 'range', 'gt', 'lt', 'gte', 'lte', 'in', 'is', 'not', 'like', 'ilike', 'contains', 'contained']
  for (const m of methods) {
    obj[m] = vi.fn(() => obj)
  }
  obj.single = vi.fn(() => Promise.resolve(resolvedValue))
  obj.maybeSingle = vi.fn(() => Promise.resolve(resolvedValue))
  // Make the object thenable so `await supabase.from(...).select(...).order(...)` works
  obj.then = (resolve: any, reject: any) => Promise.resolve(resolvedValue).then(resolve, reject)
  return obj
}

// Mock react-router-dom
vi.mock('react-router-dom', () => ({
  Link: ({ children, to, ...props }: any) => (
    <a href={to} {...props}>{children}</a>
  ),
  useLocation: () => ({ pathname: '/', state: null }),
  useNavigate: () => () => {},
  BrowserRouter: ({ children }: any) => children,
}))

// Mock @/lib/supabase with chainable thenable queries
vi.mock('@/lib/supabase', () => {
  const fromMock = vi.fn(() => chainableMock())
  return {
    supabase: {
      from: fromMock,
      storage: {
        from: vi.fn(() => ({
          remove: vi.fn(() => Promise.resolve({ error: null })),
          upload: vi.fn(() => Promise.resolve({ data: { path: 'test' }, error: null })),
          getPublicUrl: vi.fn(() => ({ data: { publicUrl: 'https://example.com/test' } })),
        })),
      },
      auth: {
        getSession: vi.fn(() => Promise.resolve({ data: { session: null }, error: null })),
        onAuthStateChange: vi.fn(() => ({ unsubscribe: vi.fn() })),
        signInWithPassword: vi.fn(() => Promise.resolve({ data: {}, error: null })),
        signUp: vi.fn(() => Promise.resolve({ data: {}, error: null })),
        signOut: vi.fn(() => Promise.resolve({ error: null })),
      },
      rpc: vi.fn(() => Promise.resolve({ data: null, error: null })),
    },
  }
})

// Mock @/hooks/useAuth
vi.mock('@/hooks/useAuth', () => ({
  useAuth: vi.fn(() => ({
    session: {
      user: { id: 'test-user-id', email: 'test@test.com' },
      access_token: 'test-token',
    },
    loading: false,
  })),
}))

// Global fetch mock — handles currency-convert edge function calls.
// Tests can override by setting global.fetch = vi.fn(...) in individual tests.
const defaultFetch = vi.fn(async (url: string, options?: RequestInit) => {
  const body = options?.body ? JSON.parse(options.body as string) : {};
  if (typeof url === 'string' && url.includes('currency-convert')) {
    const { from, to, amount } = body;
    const rates: Record<string, number> = {
      INR_USD: 0.012,
      USD_INR: 83.0,
      INR_EUR: 0.011,
      EUR_INR: 90.0,
    };
    const rate = from === to ? 1 : (rates[`${from}_${to}`] ?? 1);
    return {
      ok: true,
      json: async () => ({ amount: Number(amount) * rate, rate, from, to }),
    } as any;
  }
  return { ok: true, json: async () => ({}) } as any;
}) as any;

global.fetch = defaultFetch as any;
