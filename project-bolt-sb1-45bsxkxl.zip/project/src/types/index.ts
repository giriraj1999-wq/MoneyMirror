export type TransactionType = 'income' | 'expense' | 'reimbursement';
export type TransactionSource = 'manual' | 'ai';

export interface Plan {
  id: string;
  user_id: string;
  month: string;
  opening_balance: number;
  expected_income: number;
  protected_savings: number;
  base_currency: string;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  user_id: string;
  name: string;
  is_essential: boolean;
  is_fixed: boolean;
  type: 'income' | 'expense';
  created_at: string;
}

export interface Budget {
  id: string;
  plan_id: string;
  category_id: string;
  planned_amount: number;
}

export interface Transaction {
  id: string;
  user_id: string;
  plan_id: string;
  category_id: string | null;
  amount: number;
  type: TransactionType;
  txn_date: string;
  note: string | null;
  source: TransactionSource;
  currency: string;
  amount_base: number | null;
  bill_url: string | null;
  bill_path: string | null;
  commitment_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Commitment {
  id: string;
  user_id: string;
  plan_id: string;
  title: string;
  amount: number;
  due_date: string;
  is_paid: boolean;
  paid_at: string | null;
  created_at: string;
}

export interface TransactionWithCategory extends Transaction {
  category?: Pick<Category, 'id' | 'name'> | null;
}

export interface BudgetWithCategory extends Budget {
  category: Category;
}

export interface AACResult {
  currentBalance: number;
  expectedIncome: number;
  actualIncome: number;
  unpaidCommitments: number;
  remainingEssential: number;
  protectedSavings: number;
  aac: number;
  verdict: 'PLAN HOLDS' | 'SHORTFALL' | 'WARNING';
}

export interface SimulationResult {
  before: number;
  after: number;
  verdict: 'PLAN HOLDS' | 'SHORTFALL';
  shortfall: number;
  exposedAmount: number;
}

export type ShareStatus = 'pending' | 'accepted' | 'paid' | 'acknowledged';

export interface TransactionShare {
  id: string;
  transaction_id: string;
  owner_user_id: string;
  partner_email: string;
  partner_user_id: string | null;
  share_amount: number;
  share_currency: string;
  share_amount_base: number | null;
  status: ShareStatus;
  paid_at: string | null;
  acknowledged_at: string | null;
  settlement_txn_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface FinancialGoal {
  id: string;
  user_id: string;
  title: string;
  target_date: string;
  target_amount: number;
  current_amount: number;
  actual_pace: number;
  created_at: string;
  updated_at: string;
}

export interface VariableBudget {
  category: string;
  amount: number;
}

export interface YearlyPlanSettings {
  id: string;
  user_id: string;
  plan_year: number;
  current_step: number;
  monthly_income: number;
  savings_target: number;
  variable_budgets: VariableBudget[];
  generated: boolean;
  created_at: string;
  updated_at: string;
}

export interface TransactionShareWithTxn extends TransactionShare {
  transaction?: Pick<Transaction, 'id' | 'amount' | 'type' | 'txn_date' | 'note' | 'category_id'> | null;
}

export interface AppNotification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  body: string | null;
  entity_id: string | null;
  is_read: boolean;
  created_at: string;
}
