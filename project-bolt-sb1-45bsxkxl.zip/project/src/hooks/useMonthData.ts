import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { getMonthStart } from '@/lib/format';
import { getCarryForward } from '@/lib/carryForward';
import type {
  Plan,
  Category,
  Budget,
  Transaction,
  Commitment,
  TransactionShare,
} from '@/types';

const DEFAULT_CATEGORIES = [
  { name: 'Groceries', is_essential: true, type: 'expense' as const },
  { name: 'Rent', is_essential: true, type: 'expense' as const },
  { name: 'Utilities', is_essential: true, type: 'expense' as const },
  { name: 'Transport', is_essential: true, type: 'expense' as const },
  { name: 'Dining Out', is_essential: false, type: 'expense' as const },
  { name: 'Entertainment', is_essential: false, type: 'expense' as const },
  { name: 'Salary', is_essential: false, type: 'income' as const },
  { name: 'Stock Market', is_essential: false, type: 'income' as const },
  { name: 'Interest on Deposits', is_essential: false, type: 'income' as const },
  { name: 'Employee Bonus', is_essential: false, type: 'income' as const },
  { name: 'Crypto', is_essential: false, type: 'income' as const },
  { name: 'Freelancing', is_essential: false, type: 'income' as const },
  { name: 'Consultancy', is_essential: false, type: 'income' as const },
  { name: 'Rental Income', is_essential: false, type: 'income' as const },
  { name: 'Dividends', is_essential: false, type: 'income' as const },
  { name: 'Gift', is_essential: false, type: 'income' as const },
];

export function useMonthData(monthStr?: string) {
  const { session } = useAuth();
  const month = monthStr ?? getMonthStart();
  const [loading, setLoading] = useState(true);
  const [plan, setPlan] = useState<Plan | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [commitments, setCommitments] = useState<Commitment[]>([]);
  const [outgoingShares, setOutgoingShares] = useState<TransactionShare[]>([]);
  const [incomingShares, setIncomingShares] = useState<TransactionShare[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refetch = useCallback(async () => {
    if (!session?.user) return;
    setLoading(true);
    setError(null);

    try {
      const [{ data: planData }, { data: catData }] = await Promise.all([
        supabase
          .from('plans')
          .select('*')
          .eq('user_id', session.user.id)
          .eq('month', month)
          .maybeSingle(),
        supabase
          .from('categories')
          .select('*')
          .eq('user_id', session.user.id)
          .order('created_at'),
      ]);

      const currentPlan = planData as Plan | null;
      setPlan(currentPlan);
      setCategories((catData as Category[]) ?? []);

      if (currentPlan) {
        const [
          { data: budgetData },
          { data: txnData },
          { data: commitData },
        ] = await Promise.all([
          supabase
            .from('budgets')
            .select('*')
            .eq('plan_id', currentPlan.id),
          supabase
            .from('transactions')
            .select('*')
            .eq('plan_id', currentPlan.id)
            .order('txn_date', { ascending: false }),
          supabase
            .from('commitments')
            .select('*')
            .eq('plan_id', currentPlan.id)
            .order('due_date'),
        ]);

        setBudgets((budgetData as Budget[]) ?? []);
        setTransactions((txnData as Transaction[]) ?? []);
        setCommitments((commitData as Commitment[]) ?? []);

        // Fetch shares: outgoing (where user is owner) and incoming (where user is partner)
        const [
          { data: outShares },
          { data: inShares },
        ] = await Promise.all([
          supabase
            .from('transaction_shares')
            .select('*')
            .eq('owner_user_id', session.user.id)
            .order('created_at', { ascending: false }),
          supabase
            .from('transaction_shares')
            .select('*')
            .eq('partner_user_id', session.user.id)
            .order('created_at', { ascending: false }),
        ]);
        setOutgoingShares((outShares as TransactionShare[]) ?? []);
        setIncomingShares((inShares as TransactionShare[]) ?? []);
      } else {
        setBudgets([]);
        setTransactions([]);
        setCommitments([]);
        setOutgoingShares([]);
        setIncomingShares([]);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [session?.user, month]);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const ensurePlan = useCallback(async (): Promise<Plan | null> => {
    if (!session?.user) return null;
    if (plan) return plan;

    const { data: existing, error: fetchErr } = await supabase
      .from('plans')
      .select('*')
      .eq('user_id', session.user.id)
      .eq('month', month)
      .maybeSingle();

    if (fetchErr) throw fetchErr;
    if (existing) {
      setPlan(existing as Plan);
      return existing as Plan;
    }

    const carry = await getCarryForward(session.user.id, month);

    const { data: newPlan, error: createErr } = await supabase
      .from('plans')
      .insert({
        user_id: session.user.id,
        month,
        opening_balance: carry.opening_balance,
        expected_income: carry.expected_income,
        protected_savings: carry.protected_savings,
      })
      .select()
      .maybeSingle();

    if (createErr) throw createErr;
    if (!newPlan) throw new Error('Failed to create plan');
    const createdPlan = newPlan as Plan;
    setPlan(createdPlan);

    if (categories.length === 0) {
      const inserts = DEFAULT_CATEGORIES.map((c) => ({
        user_id: session.user.id,
        name: c.name,
        is_essential: c.is_essential,
        type: c.type,
      }));
      const { data: newCats } = await supabase
        .from('categories')
        .insert(inserts)
        .select('*');
      if (newCats) setCategories(newCats as Category[]);
    }

    return createdPlan;
  }, [session?.user, month, plan, categories.length]);

  return {
    month,
    loading,
    error,
    plan,
    categories,
    budgets,
    transactions,
    commitments,
    outgoingShares,
    incomingShares,
    refetch,
    ensurePlan,
    setPlan,
    setCategories,
    setBudgets,
    setTransactions,
    setCommitments,
    setOutgoingShares,
    setIncomingShares,
  };
}
