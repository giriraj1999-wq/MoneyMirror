import { useState, useEffect, useCallback } from 'react';
import { CURRENCIES, type CurrencyCode } from '@/lib/format';

function getInitialCurrency(): CurrencyCode {
  if (typeof window === 'undefined') return 'INR';
  const stored = localStorage.getItem('mm-currency');
  if (stored && CURRENCIES.some((c) => c.code === stored)) return stored as CurrencyCode;
  return 'INR';
}

export function useDisplayCurrency() {
  const [currency, setCurrency] = useState<CurrencyCode>(getInitialCurrency);

  useEffect(() => {
    localStorage.setItem('mm-currency', currency);
  }, [currency]);

  const changeCurrency = useCallback((code: CurrencyCode) => {
    setCurrency(code);
  }, []);

  return { currency, changeCurrency };
}
