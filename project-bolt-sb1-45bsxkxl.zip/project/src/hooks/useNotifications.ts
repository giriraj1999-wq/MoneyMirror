import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { AppNotification } from '@/types';

export function useNotifications() {
  const { session } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifications = useCallback(async () => {
    if (!session?.user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false })
      .limit(30);
    if (!error && data) {
      setNotifications(data as AppNotification[]);
    }
    setLoading(false);
  }, [session?.user]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const addNotification = useCallback(
    async (type: string, title: string, body: string | null, entityId: string | null) => {
      if (!session?.user) return;
      const { error } = await supabase.from('notifications').insert({
        user_id: session.user.id,
        type,
        title,
        body,
        entity_id: entityId,
      });
      if (!error) {
        await fetchNotifications();
      }
    },
    [session?.user, fetchNotifications]
  );

  const markAllRead = useCallback(async () => {
    if (!session?.user) return;
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', session.user.id)
      .eq('is_read', false);
    if (!error) {
      setNotifications(notifications.map((n) => ({ ...n, is_read: true })));
    }
  }, [session?.user, notifications]);

  const markRead = useCallback(
    async (id: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', id);
      if (!error) {
        setNotifications(notifications.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
      }
    },
    [notifications]
  );

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return {
    notifications,
    loading,
    unreadCount,
    addNotification,
    markAllRead,
    markRead,
    refetch: fetchNotifications,
  };
}
