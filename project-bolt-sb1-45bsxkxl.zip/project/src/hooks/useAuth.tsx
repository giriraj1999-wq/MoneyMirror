import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';

interface AuthContextValue {
  session: Session | null;
  loading: boolean;
  connectionError: boolean;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  retry: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [connectionError, setConnectionError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  useEffect(() => {
    let settled = false;

    const sessionTimeout = setTimeout(() => {
      if (settled) return;
      settled = true;
      setConnectionError(true);
      setLoading(false);
    }, 10000);

    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (settled) return;
        settled = true;
        clearTimeout(sessionTimeout);
        setSession(data.session);
        setLoading(false);
      })
      .catch(() => {
        if (settled) return;
        settled = true;
        setConnectionError(true);
        setLoading(false);
      });

    const { data: listener } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s);
      setConnectionError(false);
      if (event === 'SIGNED_IN' && s) {
        (async () => {
          await supabase.rpc('claim_transaction_shares');
        })();
      }
    });

    return () => {
      clearTimeout(sessionTimeout);
      listener.subscription.unsubscribe();
    };
  }, [retryCount]);

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    return { error: error?.message ?? null };
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch {
      // ignore network/server errors — clear locally regardless
    }
    setSession(null);
  };

  const retry = () => {
    setConnectionError(false);
    setLoading(true);
    setRetryCount((c) => c + 1);
  };

  return (
    <AuthContext.Provider value={{ session, loading, connectionError, signUp, signIn, signOut, retry }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
