import { useEffect, useMemo, useState } from 'react';
import type { CurrencyCode } from '@/lib/format';

interface ConversionRequest {
  key: string;
  amount: number;
  from: string;
}

interface ConversionResult {
  amount: number;
  from: string;
}

function getConversionUrl(): string {
  return `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/currency-convert`;
}

export function useCurrencyConversions(
  requests: ConversionRequest[],
  to: CurrencyCode
): Record<string, ConversionResult> {
  const [results, setResults] = useState<Record<string, ConversionResult>>({});
  const requestKey = useMemo(
    () => requests.map((request) => `${request.key}:${request.amount}:${request.from}:${to}`).join('|'),
    [requests, to]
  );

  useEffect(() => {
    let cancelled = false;
    const pending = requests.filter((request) => request.from !== to);
    const directResults = Object.fromEntries(
      requests
        .filter((request) => request.from === to)
        .map((request) => [request.key, { amount: request.amount, from: request.from }])
    );

    setResults((current) => ({ ...current, ...directResults }));

    const convert = async (request: ConversionRequest) => {
      try {
        const response = await fetch(getConversionUrl(), {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ amount: request.amount, from: request.from, to }),
        });
        if (!response.ok) return;
        const data: { amount?: number } = await response.json();
        if (typeof data.amount !== 'number' || cancelled) return;
        const convertedAmount = data.amount;
        if (typeof convertedAmount !== 'number') return;
        setResults((current) => ({
          ...current,
          [request.key]: { amount: convertedAmount, from: request.from },
        }));
      } catch {
        return;
      }
    };

    void Promise.all(pending.map(convert));
    return () => {
      cancelled = true;
    };
  }, [requestKey, to]);

  return results;
}
