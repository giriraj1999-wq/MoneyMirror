# MoneyMirror — Bolt Development Guide

> A commitment-aware monthly money planner that answers one question: **"How much money do I actually have free to spend?"**

---

## Table of Contents

1. [Product Overview](#1-product-overview)
2. [Core Concepts](#2-core-concepts)
3. [App Flow & Screens](#3-app-flow--screens)
4. [The Money Engine (AAC)](#4-the-money-engine-aac)
5. [The Simulator ("Can I Spend This?")](#5-the-simulator-can-i-spend-this)
6. [AI Integration](#6-ai-integration)
7. [Data Model & Database Schema](#7-data-model--database-schema)
8. [Tech Stack](#8-tech-stack)
9. [Build Order (Step-by-Step)](#9-build-order-step-by-step)
10. [V1 Feature Checklist](#10-v1-feature-checklist)
11. [V2 Features (Gated)](#11-v2-features-gated)
12. [Test Cases](#12-test-cases)
13. [Design & UX Guidelines](#13-design--ux-guidelines)
14. [Key Rules & Guardrails](#14-key-rules--guardrails)

---

## 1. Product Overview

**MoneyMirror** is a personal finance app for salaried individuals who know their account balance but don't know how much of that money is *already spoken for* — by upcoming commitments, essential spending, and savings they don't want to touch.

### The Core Loop

```
PLAN → TRACK → CHECK → SIMULATE → DECIDE
```

| Step | What Happens | Screen |
|------|-------------|--------|
| **Plan** | Set opening balance, expected income, protected savings, category budgets | Plan My Month |
| **Track** | Log transactions (manual or AI-parsed from pasted text) | Transactions |
| **Check** | See how much money is truly available after all commitments | Dashboard |
| **Simulate** | Ask "Can I spend ₹X?" before making a purchase | Simulator |
| **Decide** | Read the verdict and AI explanation, make an informed choice | Simulator result |

### Hero Metric

**Available After Commitments (AAC)** — the single most important number in the app. It tells the user exactly how much money is genuinely free to spend.

### Wow Feature

**"Can I Spend This?"** — a simulator where the user enters a proposed expense and instantly sees whether it's safe or causes a shortfall.

---

## 2. Core Concepts

### Available After Commitments (AAC)

The money you have minus everything already promised:

```
AAC = Current Balance
      − Protected Savings
      − Unpaid Commitments Total
      − Remaining Essential Budget
```

### Current Balance

```
Current Balance = Opening Balance
                  + Sum of all income transactions
                  − Sum of all expense transactions
```

> **Important:** "Expected income" is a planning field only. It never touches the balance. Only an actual income transaction changes the real balance. Never count the same rupee twice.

### Protected Savings

A single field: the amount of present money the user wants to preserve this month. This is subtracted from the balance because it's "locked away" — not available to spend.

### Essential vs Non-Essential Categories

- **Essential** categories (Rent, Groceries, Utilities) have their remaining budget subtracted from AAC
- **Non-essential** categories (Entertainment, Dining Out) do NOT reduce AAC — that money is already available

### Remaining Essential Budget

```
Remaining Essential Budget = Σ max(0, planned_i − spent_i)
                             for each essential category
```

> The `max(0, ...)` cap prevents overspending in one essential category from creating false available money in another.

### Commitments

Future payments the user has promised (EMI, rent, insurance premium, etc.). Only **unpaid** commitments reduce AAC. Once marked paid, they're excluded (the payment transaction already reduced the balance).

### Verdict Rules (Frozen)

| Condition | Verdict | What's Shown |
|-----------|--------|-------------|
| AAC < 0 | **SHORTFALL** | Exact rupee shortfall amount |
| AAC ≥ 0 | **PLAN HOLDS** | Exact rupees still available |

> No "healthy / low flexibility / at risk" labels in V1. Keep it binary and unambiguous.

---

## 3. App Flow & Screens

### Screen 1: Plan My Month

**Purpose:** Set up the monthly financial picture.

**Fields:**
- Opening balance (₹)
- Expected income (₹) — planning only, does not affect balance
- Protected savings (₹) — amount to preserve this month
- Month selector (defaults to current month)

**Behavior:**
- One plan per user per month
- Editing updates the plan in place
- On save, redirects to Dashboard

### Screen 2: Categories & Budgets

**Purpose:** Define spending categories with planned amounts.

**Fields per category:**
- Name (e.g., "Groceries", "Rent", "Transport")
- Planned amount (₹)
- Is essential? (toggle)

**Behavior:**
- Seed with default categories on first plan creation
- User can add/edit/delete custom categories
- Each category has one budget per monthly plan
- Essential flag determines whether remaining budget reduces AAC

### Screen 3: Transactions

**Purpose:** Log income and expenses.

**Two entry modes:**

**Manual Entry:**
- Amount (₹, must be > 0)
- Type (income | expense)
- Category (dropdown)
- Date (defaults to today)
- Note (optional)

**AI Parse Entry:**
- User pastes bank SMS / UPI text into a text box
- Click "Parse" → AI returns a draft transaction
- Draft appears in a pre-filled review form
- User reviews, edits if needed, then confirms
- On confirm → transaction is saved to database
- On cancel → draft is discarded
- **AI never writes to the database directly**

**Transaction List:**
- All transactions for the current month
- Filter by type (income / expense / all)
- Edit and delete supported
- Each transaction shows: amount, category, date, note, source (manual / AI)

### Screen 4: Commitments

**Purpose:** Track upcoming payments promised for the month.

**Fields:**
- Title (e.g., "Car EMI", "House Rent")
- Amount (₹)
- Due date
- Status (unpaid / paid)

**Behavior:**
- Add, edit, delete commitments
- "Mark as Paid" toggles status
- Paid commitments are excluded from AAC (the payment transaction already reduced the balance)
- Unpaid commitments reduce AAC
- Overdue commitments (due date passed, still unpaid) are treated same as upcoming for AAC

### Screen 5: Dashboard

**Purpose:** The financial command center showing AAC and all components.

**Cards/Metrics displayed:**

| Metric | Description |
|--------|-------------|
| Current Balance | Opening balance + income − expenses |
| Unpaid Commitments | Total of all unpaid commitments this month |
| Remaining Essential Budget | Total planned − spent for essential categories |
| Protected Savings | Amount user wants to preserve |
| **AAC** | The hero number — prominently displayed |
| Next Due Commitment | Closest upcoming unpaid commitment |

**Behavior:**
- AAC recomputes on every data change (add/edit/delete transaction or commitment)
- Verdict badge: green "Plan Holds" or red "Shortfall"
- Quick link to Simulator

### Screen 6: Simulator ("Can I Spend This?")

**Purpose:** Test a proposed purchase before committing.

**Input:**
- Proposed expense amount (₹)

**Output:**

| Field | Description |
|-------|-------------|
| Before | Current AAC |
| After | AAC − proposed amount |
| Verdict | PLAN HOLDS or SHORTFALL |
| Shortfall | If SHORTFALL, the rupee amount short |
| Exposed Amount | If SHORTFALL, how much of protected savings would be exposed |
| AI Explanation | 2-3 plain sentences explaining the result (with fallback to static text) |

**Behavior:**
- Calculation is instant and deterministic
- AI explanation is fetched after the math is done — never the other way around
- If AI fails, show the numbers with a simple static explanation
- Verdict is shown with both color AND text (never color alone)

---

## 4. The Money Engine (AAC)

This is the single most important component. It must be provably correct.

### Formula

```
AAC = Current Balance
      − Protected Savings
      − Unpaid Commitments Total
      − Remaining Essential Budget
```

### Component Calculations

```
Current Balance =
    Opening Balance
  + SUM(transaction.amount WHERE type = 'income')
  − SUM(transaction.amount WHERE type = 'expense')

Unpaid Commitments Total =
    SUM(commitment.amount WHERE is_paid = false
        AND due_date IN [month_start, month_end))

Remaining Essential Budget =
    SUM(
      MAX(0, category.planned_amount − SUM(expenses in that category))
    ) FOR EACH essential category

Protected Savings =
    plan.protected_savings
```

### Implementation Notes

- All money arithmetic must use integer paise (multiply by 100) or a decimal library to avoid floating-point drift
- The `MAX(0, ...)` cap on remaining essential budget is critical — without it, overspending one category inflates AAC
- Paid commitments are excluded because the payment transaction already reduced the balance — including both would double-count
- Month boundary: store month as the first day of the month; filter transactions by `[month, month + 1 month)`

### Pseudocode

```typescript
function computeAAC(plan, transactions, commitments, categories, budgets): number {
  // Current balance
  const incomeTotal = sum(transactions.filter(t => t.type === 'income').map(t => t.amount));
  const expenseTotal = sum(transactions.filter(t => t.type === 'expense').map(t => t.amount));
  const currentBalance = plan.openingBalance + incomeTotal - expenseTotal;

  // Unpaid commitments
  const unpaidCommitments = sum(
    commitments.filter(c => !c.isPaid).map(c => c.amount)
  );

  // Remaining essential budget (with max(0, ...) cap per category)
  const remainingEssential = sum(
    categories
      .filter(cat => cat.isEssential)
      .map(cat => {
        const planned = budgets.find(b => b.categoryId === cat.id)?.plannedAmount ?? 0;
        const spent = sum(
          transactions
            .filter(t => t.categoryId === cat.id && t.type === 'expense')
            .map(t => t.amount)
        );
        return Math.max(0, planned - spent);
      })
  );

  // Protected savings
  const protectedSavings = plan.protectedSavings;

  // AAC
  const aac = currentBalance - protectedSavings - unpaidCommitments - remainingEssential;
  return aac;
}
```

---

## 5. The Simulator ("Can I Spend This?")

### Pseudocode

```typescript
function simulateExpense(currentAAC: number, proposedAmount: number) {
  const newAAC = currentAAC - proposedAmount;

  if (newAAC < 0) {
    return {
      before: currentAAC,
      after: newAAC,
      verdict: 'SHORTFALL',
      shortfall: Math.abs(newAAC),
      exposedAmount: Math.abs(newAAC),
    };
  } else {
    return {
      before: currentAAC,
      after: newAAC,
      verdict: 'PLAN HOLDS',
      shortfall: 0,
      exposedAmount: 0,
    };
  }
}
```

### Key Rules

- The simulator receives the **already-computed AAC** as input — it does not recompute
- The proposed amount is simply subtracted from AAC
- The verdict is binary: SHORTFALL or PLAN HOLDS — no intermediate states
- All numbers are final before AI explanation is requested

---

## 6. AI Integration

### Design Principle

> **Normal code calculates. AI understands and explains.**
> If the AI layer is unavailable, the product still works — the app falls back to fixtures with no visible break.

### Two AI Jobs Only

| Job | Input | Output | On Failure |
|-----|-------|--------|-----------|
| **Parse transaction** | Free-text bank SMS / UPI text | Draft transaction object (amount, type, category, merchant, note) | Show blank manual form |
| **Explain impact** | Precomputed verdict + numbers (AAC, proposed amount, after, shortfall) | 2-3 plain sentences explaining what changes | Show numbers only with static text |

### AI Guardrails (Non-Negotiable)

1. **AI never writes to the database** — Only the standard transaction create endpoint writes. AI returns a draft; the user confirms.
2. **AI never invents numbers** — Every numeric field in the explain output must already exist in the input payload. Validate with a regex scan for digits not present in the input.
3. **AI never blocks the demo** — 3-second hard timeout + fixture fallback. The app must work entirely offline.

### Parse Prompt (for reference)

```
You extract structured transaction data from user-provided payment text.
Return JSON only with: amount, currency, merchant_or_description, type (income|expense),
suggested_category, confidence.
Do not invent missing values; use null.
Do not make financial recommendations.
The user will confirm before saving.
```

### Explain Prompt (for reference)

```
You are explaining a deterministic personal-finance calculation.
You are given: current balance, commitments, essential budget remaining,
protected savings, proposed expense, before-AAC, and after-AAC.
Do not recalculate or change any numbers.
Explain in 2-3 plain sentences what changes, whether a shortfall appears,
and which protected amount would become exposed.
Do not recommend borrowing, investing, or a financial product.
```

### Fallback Strategy

- Build hardcoded JSON responses for the exact demo strings BEFORE wiring live endpoints
- Feature flag to toggle AI on/off
- 3-second hard timeout on AI calls
- On timeout or error → return fixture result, no error state shown to user

### AI Edge Function Pattern

```
POST /api/ai/parse   → receives text, returns draft transaction (never writes to DB)
POST /api/ai/explain → receives precomputed numbers, returns 2-3 sentences
```

Both endpoints:
- Must include CORS headers
- Must validate response with Zod schema
- Must have a 3-second timeout
- Must fall back to fixture on any failure

---

## 7. Data Model & Database Schema

### Tables

#### users
Managed by Supabase Auth. No custom table needed — use `auth.users`.

#### plans
| Column | Type | Notes |
|--------|------|-------|
| id | uuid (PK) | Default gen_random_uuid() |
| user_id | uuid (FK → auth.users.id) | NOT NULL |
| month | date | First day of month (e.g., 2026-09-01) |
| opening_balance | numeric(14,2) | NOT NULL, default 0 |
| expected_income | numeric(14,2) | Planning only, default 0 |
| protected_savings | numeric(14,2) | Amount to preserve, default 0 |
| created_at | timestamptz | Default now() |
| updated_at | timestamptz | Default now() |

- Unique constraint on (user_id, month) — one plan per user per month

#### categories
| Column | Type | Notes |
|--------|------|-------|
| id | uuid (PK) | |
| user_id | uuid (FK → auth.users.id) | NOT NULL |
| name | text | NOT NULL |
| is_essential | boolean | Default false |
| created_at | timestamptz | Default now() |

#### budgets
| Column | Type | Notes |
|--------|------|-------|
| id | uuid (PK) | |
| plan_id | uuid (FK → plans.id) | NOT NULL, ON DELETE CASCADE |
| category_id | uuid (FK → categories.id) | NOT NULL |
| planned_amount | numeric(14,2) | NOT NULL, default 0 |

- Unique constraint on (plan_id, category_id) — one budget per category per plan

#### transactions
| Column | Type | Notes |
|--------|------|-------|
| id | uuid (PK) | |
| user_id | uuid (FK → auth.users.id) | NOT NULL |
| plan_id | uuid (FK → plans.id) | NOT NULL |
| category_id | uuid (FK → categories.id) | Nullable (uncategorized allowed) |
| amount | numeric(14,2) | NOT NULL, must be > 0 |
| type | text | NOT NULL, CHECK (type IN ('income', 'expense')) |
| txn_date | date | NOT NULL |
| note | text | Nullable |
| source | text | Default 'manual', CHECK (source IN ('manual', 'ai')) |
| created_at | timestamptz | Default now() |
| updated_at | timestamptz | Default now() |

#### commitments
| Column | Type | Notes |
|--------|------|-------|
| id | uuid (PK) | |
| user_id | uuid (FK → auth.users.id) | NOT NULL |
| plan_id | uuid (FK → plans.id) | NOT NULL |
| title | text | NOT NULL |
| amount | numeric(14,2) | NOT NULL |
| due_date | date | NOT NULL |
| is_paid | boolean | Default false |
| paid_at | timestamptz | Nullable |
| created_at | timestamptz | Default now() |

### RLS Policies

Every table gets 4 policies (SELECT, INSERT, UPDATE, DELETE) scoped to `auth.uid() = user_id`:

```sql
-- Example for transactions
CREATE POLICY "select_own" ON transactions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own" ON transactions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own" ON transactions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own" ON transactions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
```

> Apply the same pattern to plans, categories, budgets, and commitments. For budgets, scope by checking the plan's user_id (via a join or subquery in the policy).

### Money Storage Rule

- Use `numeric(14,2)` for ALL money columns — never FLOAT
- Convert to JavaScript `number` only at render time
- For arithmetic, either use integer paise (amount × 100) or a decimal library

---

## 8. Tech Stack

| Layer | Choice | Why |
|-------|--------|-----|
| Frontend | React 18 + Vite (Bolt) | Fast HMR, minimal config |
| Styling | Tailwind CSS | Consistent, rapid UI |
| Icons | lucide-react | Clean, lightweight |
| Routing | React Router v6 | 5-6 screens, nested routes |
| Database | Supabase (Postgres) | One dependency for DB + Auth + RLS |
| Auth | Supabase Auth (email/password) | Skip building custom auth |
| AI | OpenAI API (via Supabase Edge Functions) | Parse + explain, both non-blocking |
| Hosting | Bolt | Zero-config deploy |

### What We Removed (vs original blueprint)

- ~~Fastify API server~~ — use Supabase client + Edge Functions instead
- ~~Prisma ORM~~ — direct Supabase client queries
- ~~Railway~~ — Bolt hosting
- ~~Zustand / TanStack Query~~ — React state + Supabase real-time for V1 simplicity
- ~~Recharts~~ — not needed for V1 (no charts)

### Project Structure

```
src/
├── components/
│   ├── layout/
│   │   ├── AppLayout.tsx        # Shell with nav
│   │   └── Sidebar.tsx          # Navigation
│   ├── ui/
│   │   ├── Card.tsx
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   ├── Modal.tsx
│   │   └── Badge.tsx
│   └── shared/
│       ├── MetricCard.tsx      # Dashboard metric display
│       ├── VerdictBadge.tsx    # PLAN HOLDS / SHORTFALL
│       └── TransactionForm.tsx
├── pages/
│   ├── Dashboard.tsx
│   ├── PlanMonth.tsx
│   ├── Transactions.tsx
│   ├── Commitments.tsx
│   ├── Simulator.tsx
│   └── Auth.tsx                # Sign in / Sign up
├── lib/
│   ├── supabase.ts             # Supabase client
│   ├── moneyEngine.ts          # computeAAC, simulateExpense (pure functions)
│   └── format.ts               # Currency formatting
├── hooks/
│   ├── useAuth.ts
│   ├── usePlan.ts
│   ├── useTransactions.ts
│   └── useCommitments.ts
├── types/
│   └── index.ts                # Shared TypeScript types
├── App.tsx
└── main.tsx
```

---

## 9. Build Order (Step-by-Step)

Build in this order. Each step should be complete and working before moving to the next.

### Step 1: Database Schema & RLS

- Create all 5 tables (plans, categories, budgets, transactions, commitments) via Supabase migration
- Enable RLS on every table
- Write 4 policies per table (SELECT, INSERT, UPDATE, DELETE) scoped to `auth.uid()`
- Add unique constraints (plan per user per month, budget per category per plan)
- Add CHECK constraints (transaction type, transaction source)

### Step 2: Auth & App Shell

- Set up Supabase Auth (email/password, email confirmation OFF)
- Create sign-in / sign-up page
- Create app layout with sidebar navigation
- Protected routes (redirect to sign-in if not authenticated)
- 5 nav items: Dashboard, Plan Month, Transactions, Commitments, Simulator

### Step 3: Plan My Month

- Form to create/edit the monthly plan
- Fields: opening balance, expected income, protected savings, month
- On first visit, seed default categories for the user
- Save to Supabase, redirect to Dashboard
- Prevent duplicate plans (one per user per month)

### Step 4: Categories & Budgets

- List existing categories with essential toggle
- Add/edit/delete custom categories
- Set planned amount per category for the current month's plan
- Show spent vs planned per category (read-only display)

### Step 5: Transactions CRUD

- Transaction list for current month (sorted by date, newest first)
- Manual add form (amount, type, category, date, note)
- Edit existing transaction
- Delete transaction (with confirmation)
- Filter by type (all / income / expense)
- Show source badge (manual / AI)

### Step 6: Commitments CRUD

- Commitment list for current month
- Add form (title, amount, due date)
- Edit / delete
- "Mark as Paid" toggle (sets is_paid = true, paid_at = now)
- Visual distinction: paid (strikethrough/grey) vs unpaid (active)

### Step 7: Money Engine (Pure Functions)

- Implement `computeAAC()` as a pure TypeScript function
- Implement `simulateExpense()` as a pure TypeScript function
- No I/O, no React, no Supabase — pure input/output
- Test with the 8 test cases from Section 12

### Step 8: Dashboard

- Fetch plan, transactions, commitments, categories, budgets for current month
- Call `computeAAC()` with the fetched data
- Display 5 metric cards: Current Balance, Unpaid Commitments, Remaining Essential Budget, Protected Savings, AAC
- AAC card is the largest / most prominent
- Verdict badge: green "Plan Holds" or red "Shortfall"
- "Next Due" commitment card
- Recompute on every data change (refetch after mutations)

### Step 9: Simulator ("Can I Spend This?")

- Input field for proposed expense amount
- "Check" button
- On submit: fetch current AAC, call `simulateExpense()`
- Display: Before AAC, After AAC, Verdict, Shortfall (if any), Exposed Amount (if any)
- Verdict badge with both color AND text
- AI explanation section (fetched from edge function, with fallback)

### Step 10: AI Parse (Edge Function)

- Create Supabase Edge Function: `ai-parse`
- Receives free text, calls OpenAI, returns draft transaction
- Zod-validate the response
- 3-second timeout
- Fallback to error (frontend shows manual form)
- Frontend: text box → "Parse" button → draft review form → confirm → save as transaction

### Step 11: AI Explain (Edge Function)

- Create Supabase Edge Function: `ai-explain`
- Receives precomputed numbers (before, after, verdict, shortfall, exposed)
- Calls OpenAI for 2-3 sentence explanation
- 3-second timeout
- Fallback to static explanation text
- Frontend: displayed in Simulator result section

### Step 12: Polish & Empty States

- Empty states for every list (no transactions yet, no commitments yet, etc.)
- Loading states for every async operation
- Error states with retry
- Responsive design (mobile + desktop)
- Currency formatting (₹ with Indian number format)
- Smooth transitions and hover states

---

## 10. V1 Feature Checklist

These 8 items are the complete V1 scope. No more, no less.

- [ ] **Plan My Month** — opening balance, expected income, protected savings
- [ ] **Categories + Budgets** — planned amount + essential / non-essential flag
- [ ] **Transactions CRUD** — create, read, edit, delete (manual entry)
- [ ] **AI Transaction Parsing** — paste text → AI draft → user confirms → save
- [ ] **Commitments CRUD** — add, edit, delete, mark paid
- [ ] **Dashboard** — current balance, unpaid commitments, remaining essentials, protected savings, AAC
- [ ] **Can I Spend This?** — deterministic before/after simulation
- [ ] **AI Explanation** — max 2-3 sentences explaining the already-calculated result

---

## 11. V2 Features (Gated)

Only build these AFTER V1 works end-to-end twice without issues.

| Priority | Feature | Description |
|----------|---------|-------------|
| V2-P1 | Monthly Review | Plan vs actual per category — completes the MoneyMirror loop |
| V2-P2 | Recurring Commitments | Clone EMI/rent commitments to next month automatically |

### Won't Now (Actively Refused)

Shared expenses, investments, bank sync, Account Aggregator, credit score, lending, automated payments, enterprise roles, seat pricing, mobile app, full AI chatbot, advanced yearly planning.

---

## 12. Test Cases

### Money Engine Tests (Must Pass)

| ID | Scenario | Input | Expected |
|----|----------|-------|---------|
| T1 | Baseline AAC | Balance ₹60k, commitments ₹25k, essential remaining ₹12k, savings ₹10k | AAC = ₹13,000 |
| T2 | Safe expense | T1 + simulate ₹10,000 | After = ₹3,000, PLAN HOLDS |
| T3 | Shortfall expense | T1 + simulate ₹18,000 | After = −₹5,000, SHORTFALL, exposed ₹5,000 |
| T4 | Exact zero | T1 + simulate ₹13,000 | After = ₹0, PLAN HOLDS |
| T5 | Essential overspend | Planned [₹5k, ₹5k], spent [₹8k, ₹0] | Remaining essential = ₹5,000 (not ₹2,000) |
| T6 | Paid commitment | Commitment ₹10k paid + txn ₹10k | Not double-counted in AAC |
| T7 | Zero income month | No income transactions | No crash, AAC computed |
| T8 | AI failure | Kill network to AI endpoint | Manual form / fixture fallback works |

### Demo Scenarios (Rahul Seed Data)

| Scenario | Steps | Expected |
|----------|-------|---------|
| Golden path | Sign in → plan month → add transactions → add commitments → view dashboard | AAC = ₹13,000 |
| Safe spend | Simulate ₹10,000 | ₹3,000 remains, PLAN HOLDS |
| Risky spend | Simulate ₹18,000 | ₹5,000 shortfall, SHORTFALL |
| AI parse | Paste bank SMS → confirm draft → transaction saved | Transaction appears in list |
| Persistence | Refresh browser | All data persists |
| AI fallback | Disable network to AI | App shows manual form / static text, no crash |

---

## 13. Design & UX Guidelines

### Visual Style

- Clean, professional fintech aesthetic — think trustworthy, not flashy
- Neutral tones with blue/green accents (avoid purple/violet)
- 8px spacing system
- Inter or system font, 3 weights max (400, 600, 700)
- Line height: 150% for body, 120% for headings
- Minimum 6 color ramps: primary (blue), success (green), warning (amber), error (red), plus neutral grays

### Dashboard Design

- AAC is the hero — largest card, centered or top-left
- Metric cards in a grid (responsive: 1 col mobile, 2-4 col desktop)
- Each card: label (small, muted), value (large, bold), optional sub-text
- Verdict badge: green background + "Plan Holds" text, or red background + "Shortfall" text
- Never rely on color alone — always pair with text

### Simulator Design

- Large input for proposed amount
- Before/After comparison (side by side on desktop, stacked on mobile)
- Verdict badge prominent
- If SHORTFALL: show shortfall amount and "protected savings exposed" warning
- AI explanation in a muted card below the numbers
- Subtle animation on verdict reveal (fade + slide)

### Transactions Design

- List view with cards or rows
- Income: green amount prefix (+)
- Expense: red amount prefix (−)
- Category badge, date, note
- Source indicator (manual icon vs AI icon)
- AI parse: prominent text area with "Parse" button, then draft review form

### Micro-Interactions

- Hover states on all interactive elements
- Smooth transitions (200-300ms) on state changes
- Loading spinners on async operations
- Toast notifications on save/delete/error
- Modal confirmations for destructive actions (delete)
- Number count-up animation on dashboard metrics (optional, subtle)

### Responsive Breakpoints

- Mobile: < 640px — single column, bottom nav or hamburger
- Tablet: 640-1024px — 2 column grids
- Desktop: > 1024px — full layout with sidebar

---

## 14. Key Rules & Guardrails

### Money Math Rules

1. **Use `numeric(14,2)` in database** — never FLOAT
2. **Cap remaining essential budget per category** — `max(0, planned − spent)`, never negative
3. **Paid commitments excluded from AAC** — payment transaction already reduced balance
4. **Expected income ≠ actual income** — expected is planning only, only income transactions change balance
5. **Protected savings is a single field** — the amount to preserve this month

### AI Rules

1. **AI never writes to the database** — returns draft only, user confirms
2. **AI never invents numbers** — validate every numeric field exists in input
3. **AI never blocks the app** — 3-second timeout + fixture fallback
4. **AI never gives financial advice** — no product recommendations, no borrowing/investing suggestions
5. **AI key stays server-side** — never in the client bundle

### Scope Rules

1. **V1 is 8 items** — no more, no less
2. **V2 only after V1 works twice** — no exceptions
3. **No new features without removing an equal-sized one**
4. **Demo reliability > extra features** — always

### Data Safety Rules

1. **RLS on every table** — no exceptions
2. **Every policy scoped to `auth.uid()`** — never `current_user`
3. **4 policies per table** (SELECT, INSERT, UPDATE, DELETE) — never `FOR ALL`
4. **Never DROP columns or change column types** — additive changes only

---

## Appendix: Rahul Demo Dataset

The demo uses a seeded user "Rahul" with the following data to produce AAC = ₹13,000:

| Item | Amount |
|------|--------|
| Opening balance | ₹60,000 |
| Income transactions | ₹0 (no income received yet) |
| Expense transactions | ₹0 (none logged yet) |
| Current balance | ₹60,000 |
| Unpaid commitments | ₹25,000 (Rent ₹15k + EMI ₹10k) |
| Remaining essential budget | ₹12,000 (Groceries ₹7k planned, ₹0 spent + Transport ₹5k planned, ₹0 spent) |
| Protected savings | ₹10,000 |
| **AAC** | **₹60,000 − ₹25,000 − ₹12,000 − ₹10,000 = ₹13,000** |

### Demo Scenarios

| Scenario | Input | Result |
|----------|-------|--------|
| Safe purchase | Simulate ₹10,000 | After = ₹3,000, PLAN HOLDS |
| Risky purchase | Simulate ₹18,000 | After = −₹5,000, SHORTFALL, ₹5,000 of protected savings exposed |
