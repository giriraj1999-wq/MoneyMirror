# MoneyMirror — Functional Document

## 1. What MoneyMirror Does

MoneyMirror is a personal finance app that answers one practical question before you make a purchase: **"Can I spend this?"**

Instead of just showing your bank balance, MoneyMirror subtracts everything you still owe and everything you still need to spend this month, then tells you what is genuinely left over. That number is called **Available After Commitments (AAC)**.

## 2. The Core Idea

A bank balance of 50,000 does not mean you can spend 50,000. You might still need to pay rent (15,000), have budgeted 8,000 for groceries, and want to protect 5,000 in savings. Your real free money is only 22,000.

MoneyMirror calculates this for you automatically and keeps it updated as you log transactions and commitments throughout the month.

## 3. Key Terms

| Term | What it means |
|------|---------------|
| **Opening Balance** | How much money you have at the start of the month |
| **Expected Income** | Income you expect to receive (planning only — does not change your real balance until you log an actual income transaction) |
| **Protected Savings** | An amount you set aside that should not be spent. MoneyMirror subtracts this from your available money |
| **Commitments** | Fixed payments you must make, like rent, EMI, or insurance. Each has a due date and can be marked as paid |
| **Essential Category** | A spending category that reduces your available money (e.g., Groceries, Rent). Budgeted amounts that you haven't spent yet are subtracted from AAC |
| **Non-Essential Category** | A spending category that is tracked for awareness but does not reduce your available money (e.g., Dining Out, Entertainment) |
| **AAC** | Available After Commitments — the money genuinely free to spend after subtracting protected savings, unpaid commitments, and remaining essential budgets |
| **Shortfall** | When AAC goes negative — meaning you would be spending into money that is protected or committed elsewhere |

## 4. The AAC Formula

```
Current Balance = Opening Balance + Total Income - Total Expenses

Available After Commitments = Current Balance
  - Protected Savings
  - Unpaid Commitments
  - Remaining Essential Budget
```

Where **Remaining Essential Budget** is, for each essential category, the budgeted amount minus what you have already spent in that category (never below zero).

If AAC is zero or positive, the verdict is **PLAN HOLDS**. If AAC is negative, the verdict is **SHORTFALL**.

## 5. User Journey

### 5.1 Sign Up / Sign In

A new user creates an account with email and password, or signs in if they already have one. After authentication, they land on the Dashboard.

### 5.2 Create a Monthly Plan

If no plan exists for the current month, the Dashboard shows an empty state prompting the user to create one. On the **Plan My Month** page, the user:

1. Enters their **Opening Balance** (how much money they have right now).
2. Enters **Expected Income** (for planning — this does not change the real balance).
3. Enters **Protected Savings** (money to lock away this month).
4. Reviews the default categories (Groceries, Rent, Utilities, Transport, Dining Out, Entertainment).
5. Toggles categories as essential or non-essential.
6. Sets a budget amount for each category.
7. Can add custom categories or delete ones they don't need.
8. Saves the plan.

### 5.3 Track Transactions

On the **Transactions** page, the user can:

- **Add a transaction manually** — choose expense or income, enter amount, pick a category, set a date, and add an optional note.
- **Paste a bank SMS** into the AI Parse box — the AI reads the message and fills in a draft (amount, merchant, category, type). The user reviews and confirms before anything is saved.
- **Edit or delete** any transaction.
- **Filter** by all, income, or expense.

Each transaction affects the Current Balance:
- An **income** transaction increases the balance.
- An **expense** transaction decreases the balance.

### 5.4 Track Commitments

On the **Commitments** page, the user can:

- **Add a commitment** — a fixed payment like rent, EMI, or insurance with a title, amount, and due date.
- **Mark a commitment as paid** — this removes it from the unpaid total and stops it from reducing AAC.
- **Edit or delete** commitments.
- View upcoming (unpaid) and paid commitments in separate sections.

Unpaid commitments reduce AAC. Once marked as paid, they no longer count against available money.

### 5.5 Simulate a Purchase ("Can I Spend This?")

On the **Can I Spend This?** page, the user:

1. Sees their current AAC displayed at the top.
2. Enters an amount they are considering spending.
3. Clicks "Check."

MoneyMirror then shows:

- **Before:** the current AAC.
- **After:** what AAC would be if this expense were made.
- **Verdict:** PLAN HOLDS (after is zero or positive) or SHORTFALL (after is negative).
- **Shortfall amount:** how far negative AAC would go.
- **Protected savings exposed:** how much of the protected savings would be consumed.
- **AI Explanation:** a 2-3 sentence plain-English summary of what changes and what is at risk. If the AI service is unavailable, a static explanation is shown instead.

### 5.6 Monitor the Dashboard

The Dashboard provides a real-time summary:

- **AAC hero card** with the verdict badge (PLAN HOLDS or SHORTFALL).
- **Current Balance** — opening balance plus income minus expenses.
- **Unpaid Commitments** — total amount still owed.
- **Remaining Essential Budget** — total unspent budget across essential categories.
- **Protected Savings** — the amount locked away.
- **Next due commitment** — the earliest unpaid commitment with its amount and due date.
- **Income and expense totals** for the month.

All numbers update automatically as the user adds transactions, marks commitments as paid, or changes their plan.

## 6. Business Rules

1. **One plan per user per month.** A user cannot have two plans for the same month.
2. **Expected income is planning only.** It does not affect the real balance. Only an actual income transaction changes the balance.
3. **Protected savings is locked.** It is always subtracted from the current balance when computing AAC. Spending into it triggers a shortfall.
4. **Essential categories reduce AAC.** The remaining (unspent) budget for each essential category is subtracted. Non-essential categories are tracked but do not reduce AAC.
5. **Only unpaid commitments reduce AAC.** Once a commitment is marked as paid, it no longer counts.
6. **AI is advisory only.** The AI parse fills a draft that the user must review and confirm. The AI explain provides a narrative summary of precomputed numbers — it never recalculates. The user always has the final say.
7. **No financial recommendations.** The AI is explicitly instructed not to recommend borrowing, investing, or any financial product.
8. **All money is in INR.** Currency formatting uses Indian number format (e.g., 1,00,000).

## 7. Example Walkthrough

**Setup:**
- Opening Balance: 50,000
- Expected Income: 30,000 (planning only)
- Protected Savings: 5,000
- Categories: Groceries (essential, budget 8,000), Rent (essential, budget 15,000), Dining Out (non-essential, budget 3,000)

**Commitments:**
- Rent: 15,000, due on the 5th (unpaid)
- Internet bill: 1,200, due on the 15th (unpaid)

**Transactions so far:**
- Salary income: 30,000
- Groceries: 2,000
- Petrol: 1,500 (Transport, essential, budget 4,000)

**Calculation:**
```
Current Balance = 50,000 + 30,000 - 2,000 - 1,500 = 76,500
Unpaid Commitments = 15,000 + 1,200 = 16,200
Remaining Essential Budget:
  Groceries: max(0, 8,000 - 2,000) = 6,000
  Rent: max(0, 15,000 - 0) = 15,000
  Transport: max(0, 4,000 - 1,500) = 2,500
  Total = 23,500
AAC = 76,500 - 5,000 - 16,200 - 23,500 = 31,800
Verdict: PLAN HOLDS
```

**Simulation — "Can I spend 35,000 on a phone?"**
```
After = 31,800 - 35,000 = -3,200
Verdict: SHORTFALL
Shortfall = 3,200
Protected savings exposed = 3,200
```

The user would see a red shortfall card showing that 3,200 of their protected savings would be consumed, plus an AI explanation like: "Spending 35,000 would push your available money to -3,200, exposing 3,200 of your protected savings. Your plan would no longer hold."

**Simulation — "Can I spend 20,000 on a phone?"**
```
After = 31,800 - 20,000 = 11,800
Verdict: PLAN HOLDS
```

The user would see a green card confirming the purchase is safe, with 11,800 still available after all commitments.

## 8. Edge Cases

| Scenario | Behavior |
|----------|----------|
| No plan for the month | Dashboard, Transactions, Commitments, and Simulator show an empty state with a link to create a plan |
| No transactions yet | Current balance equals opening balance; AAC subtracts only savings, commitments, and essential budgets |
| All commitments paid | Unpaid commitments = 0; only savings and essential budgets reduce AAC |
| All essential budgets fully spent | Remaining essential budget = 0; only savings and commitments reduce AAC |
| AI service unavailable | Parse returns a null draft (user enters manually); Explain falls back to a static sentence generated from the simulation result |
| Negative AAC (shortfall) | Dashboard shows a SHORTFALL badge; the user needs to reduce spending, increase income, or adjust protected savings |
| Spending more than AAC in simulator | Shows shortfall amount and how much protected savings is exposed |

## 9. Privacy and Security

- Each user only sees their own data. The database enforces this at the row level — no user can read, create, update, or delete another user's plans, transactions, commitments, categories, or budgets.
- The OpenAI API key is stored securely on the server side (edge function secret) and is never sent to the browser.
- Authentication uses email and password with session tokens that persist across page reloads and refresh automatically.
