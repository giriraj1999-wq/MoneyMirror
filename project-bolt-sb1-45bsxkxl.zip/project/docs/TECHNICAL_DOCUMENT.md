# SpendWise — Technical Document

## 1. Overview

SpendWise is a personal finance web application that helps users answer one question before making a purchase: **"Can I spend this?"** It computes an Available After Commitments (AAC) figure and lets the user simulate a proposed expense against it.

The app is a single-page React application backed by Supabase (PostgreSQL database, authentication, and edge functions).

## 2. Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + TypeScript |
| Build tool | Vite 5 |
| Routing | react-router-dom 6 |
| Styling | Tailwind CSS 3 |
| Icons | lucide-react |
| Backend | Supabase (PostgreSQL + Auth + Edge Functions) |
| Edge Functions | Deno runtime (`Deno.serve`) |
| AI Provider | OpenAI (gpt-4o-mini) |

## 3. Project Structure

```
src/
├── App.tsx                      # Root: AuthProvider + BrowserRouter + ProtectedRoutes
├── main.tsx                     # Entry point
├── index.css                    # Tailwind directives + custom component classes
├── types/
│   └── index.ts                 # All TypeScript interfaces and types
├── lib/
│   ├── supabase.ts              # Supabase client initialization
│   ├── moneyEngine.ts           # Core financial calculations (AAC + simulation)
│   └── format.ts                # INR currency + date formatting helpers
├── hooks/
│   ├── useAuth.tsx              # Auth context: session state, signUp, signIn, signOut
│   └── useMonthData.ts          # Data hook: fetches plan, categories, budgets, transactions, commitments
├── components/
│   ├── layout/
│   │   └── AppLayout.tsx        # Sidebar nav (desktop) + top bar (mobile)
│   ├── shared/
│   │   ├── EmptyState.tsx       # Reusable empty-state placeholder
│   │   ├── MetricCard.tsx       # Dashboard metric tile
│   │   └── VerdictBadge.tsx     # PLAN HOLDS / SHORTFALL badge
│   └── ui/
│       └── Modal.tsx            # Reusable modal dialog
└── pages/
    ├── Auth.tsx                 # Sign-in / sign-up screen
    ├── Dashboard.tsx            # AAC display + metric cards
    ├── PlanMonth.tsx            # Set opening balance, income, savings, categories, budgets
    ├── Transactions.tsx         # Add/edit/delete transactions + AI parse
    ├── Commitments.tsx          # Add/edit/delete commitments + mark-as-paid
    └── Simulator.tsx            # "Can I Spend This?" expense simulator + AI explanation

supabase/
├── config.toml                  # Edge function configuration
├── migrations/
│   └── 20260925121230_create_spendwise_finance_schema.sql
└── functions/
    ├── ai-parse/index.ts        # Extracts transaction data from bank SMS text
    └── ai-explain/index.ts      # Explains the impact of a proposed expense
```

## 4. Authentication

- **Provider:** Supabase Auth with email/password.
- **Session management:** `useAuth` hook wraps `AuthProvider` (React Context). On mount it calls `supabase.auth.getSession()` and subscribes to `onAuthStateChange`.
- **Route protection:** `ProtectedRoutes` in `App.tsx` redirects unauthenticated users to the `Auth` page. All routes are children of `AppLayout` when authenticated.
- **Token persistence:** Enabled via `persistSession: true` and `autoRefreshToken: true` in the Supabase client config.

## 5. Database Schema

Five tables, all with Row Level Security (RLS) enabled. Money values use `numeric(14,2)` — never floating point.

### 5.1 `plans`
| Column | Type | Notes |
|--------|------|-------|
| id | uuid PK | `gen_random_uuid()` |
| user_id | uuid FK → auth.users | `ON DELETE CASCADE` |
| month | date | First of the month |
| opening_balance | numeric(14,2) | `CHECK >= 0` |
| expected_income | numeric(14,2) | `CHECK >= 0`, planning only |
| protected_savings | numeric(14,2) | `CHECK >= 0` |
| created_at, updated_at | timestamptz | |
| | | `UNIQUE(user_id, month)` — one plan per user per month |

### 5.2 `categories`
| Column | Type | Notes |
|--------|------|-------|
| id | uuid PK | |
| user_id | uuid FK → auth.users | `ON DELETE CASCADE` |
| name | text | `CHECK length(trim(name)) > 0` |
| is_essential | boolean | Default `false` |
| created_at | timestamptz | |
| | | `UNIQUE(user_id, name)` |

### 5.3 `budgets`
| Column | Type | Notes |
|--------|------|-------|
| id | uuid PK | |
| plan_id | uuid FK → plans | `ON DELETE CASCADE` |
| category_id | uuid FK → categories | `ON DELETE CASCADE` |
| planned_amount | numeric(14,2) | `CHECK >= 0` |
| | | `UNIQUE(plan_id, category_id)` |

### 5.4 `transactions`
| Column | Type | Notes |
|--------|------|-------|
| id | uuid PK | |
| user_id | uuid FK → auth.users | `ON DELETE CASCADE` |
| plan_id | uuid FK → plans | `ON DELETE CASCADE` |
| category_id | uuid FK → categories | `ON DELETE SET NULL` |
| amount | numeric(14,2) | `CHECK > 0` |
| type | text | `CHECK IN ('income', 'expense')` |
| txn_date | date | |
| note | text | Nullable |
| source | text | `CHECK IN ('manual', 'ai')`, default `'manual'` |
| created_at, updated_at | timestamptz | |

### 5.5 `commitments`
| Column | Type | Notes |
|--------|------|-------|
| id | uuid PK | |
| user_id | uuid FK → auth.users | `ON DELETE CASCADE` |
| plan_id | uuid FK → plans | `ON DELETE CASCADE` |
| title | text | `CHECK length(trim(title)) > 0` |
| amount | numeric(14,2) | `CHECK > 0` |
| due_date | date | |
| is_paid | boolean | Default `false` |
| paid_at | timestamptz | Nullable |
| created_at | timestamptz | |

### 5.6 Indexes
- `plans_user_month_idx` on `plans(user_id, month)`
- `budgets_plan_idx` on `budgets(plan_id)`
- `transactions_plan_date_idx` on `transactions(plan_id, txn_date DESC)`
- `commitments_plan_due_idx` on `commitments(plan_id, due_date)`

### 5.7 Row Level Security Policies

Every table has four separate policies (SELECT, INSERT, UPDATE, DELETE), scoped to `TO authenticated`.

- **plans, categories, transactions, commitments:** Direct ownership via `auth.uid() = user_id`.
- **budgets:** Ownership inferred through the parent plan (and parent category for INSERT/UPDATE) using `EXISTS` subqueries. This ensures a user cannot create a budget for another user's plan.
- INSERT and UPDATE policies on transactions and commitments also verify plan ownership via `EXISTS` subquery to prevent cross-user data creation.

## 6. Core Financial Engine (`moneyEngine.ts`)

### 6.1 `computeAAC()`

Calculates the Available After Commitments figure from the current plan, transactions, commitments, categories, and budgets.

```
currentBalance = openingBalance + sum(income transactions) - sum(expense transactions)
unpaidCommitments = sum(commitments where is_paid = false)
remainingEssential = sum over essential categories of max(0, planned_amount - spent_in_category)
aac = currentBalance - protectedSavings - unpaidCommitments - remainingEssential
verdict = aac < 0 ? "SHORTFALL" : "PLAN HOLDS"
```

### 6.2 `simulateExpense()`

Tests a proposed expense against the current AAC:

```
after = currentAAC - proposedAmount
if after < 0:
  verdict = "SHORTFALL"
  shortfall = |after|
  exposedAmount = |after|
else:
  verdict = "PLAN HOLDS"
  shortfall = 0
  exposedAmount = 0
```

## 7. Data Hook (`useMonthData.ts`)

A custom hook that loads all data for the current month (or a specified month) for the authenticated user:

1. Fetches the plan and categories in parallel.
2. If a plan exists, fetches budgets, transactions, and commitments in parallel.
3. Provides an `ensurePlan()` function that creates a plan (and seeds default categories) if none exists for the current month.
4. Returns state setters for optimistic UI updates after mutations.

Default categories seeded on first plan creation: Groceries (essential), Rent (essential), Utilities (essential), Transport (essential), Dining Out (non-essential), Entertainment (non-essential).

## 8. Edge Functions

Both functions run on Deno, use `Deno.serve`, include CORS headers on every response, and enforce a 3-second timeout via `AbortController`.

### 8.1 `ai-parse`
- **Endpoint:** `POST /functions/v1/ai-parse`
- **Input:** `{ text: string }` — a bank SMS or UPI message
- **Behavior:** Sends the text to OpenAI gpt-4o-mini with a structured prompt requesting JSON output (amount, currency, merchant_or_description, type, suggested_category, confidence).
- **Fallback:** If no API key is configured or any error occurs, returns a null-valued draft so the UI can still open the form for manual entry.
- **JWT verification:** Enabled (`verify_jwt = true`).

### 8.2 `ai-explain`
- **Endpoint:** `POST /functions/v1/ai-explain`
- **Input:** Precomputed numbers from the simulation (currentBalance, unpaidCommitments, remainingEssential, protectedSavings, proposedExpense, beforeAAC, afterAAC, verdict, shortfall, exposedAmount).
- **Behavior:** Sends the numbers to OpenAI gpt-4o-mini with instructions to explain (not recalculate) in 2-3 plain sentences.
- **Fallback:** If the call fails, the client generates a static explanation from the simulation result.
- **JWT verification:** Enabled (`verify_jwt = true`).

### 8.3 CORS Configuration

```typescript
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};
```

## 9. Frontend Pages

### 9.1 Auth (`Auth.tsx`)
- Email/password sign-in and sign-up toggle.
- On success, the `onAuthStateChange` listener updates the session and `ProtectedRoutes` renders the app.

### 9.2 Dashboard (`Dashboard.tsx`)
- Shows the AAC hero card with verdict badge.
- Four metric cards: Current Balance, Unpaid Commitments, Remaining Essential Budget, Protected Savings.
- Next upcoming commitment callout.
- Income and expense summary cards.
- Empty state with CTA to create a plan if none exists.

### 9.3 Plan Month (`PlanMonth.tsx`)
- Edit opening balance, expected income, and protected savings.
- Manage categories: add, delete, toggle essential/non-essential.
- Set per-category budget amounts (saved on blur).
- Calls `ensurePlan()` before saving to create the plan row if needed.

### 9.4 Transactions (`Transactions.tsx`)
- List with all/income/expense filter tabs.
- Add/edit transaction modal with amount, type, category, date, note.
- AI Parse box: paste bank SMS, call `ai-parse` edge function, pre-fill the form for review.
- Delete with optimistic state update.

### 9.5 Commitments (`Commitments.tsx`)
- Upcoming (unpaid) and Paid sections.
- Add/edit commitment modal with title, amount, due date.
- Mark as paid/unpaid toggle with `paid_at` timestamp.
- Delete with optimistic state update.

### 9.6 Simulator (`Simulator.tsx`)
- Input a proposed expense amount.
- Calls `simulateExpense()` with the current AAC.
- Shows before/after comparison, verdict badge, shortfall and exposed amounts (if shortfall).
- Calls `ai-explain` edge function for a plain-English explanation.
- Falls back to a static explanation if the AI service is unavailable.

## 10. Routing

| Path | Page | Auth Required |
|------|------|--------------|
| `/` | Dashboard | Yes |
| `/plan` | Plan Month | Yes |
| `/transactions` | Transactions | Yes |
| `/commitments` | Commitments | Yes |
| `/simulator` | Can I Spend This? | Yes |
| `*` | Redirects to `/` | Yes |

Unauthenticated users see the Auth page regardless of route.

## 11. Security Considerations

- All database tables have RLS enabled with per-verb policies scoped to `auth.uid()`.
- Budgets use inferred ownership through `EXISTS` subqueries on parent plan and category.
- Edge functions verify JWT tokens (`verify_jwt = true`).
- The OpenAI API key is stored as an edge function secret — never exposed to the browser.
- All money values are `numeric(14,2)` to avoid floating-point rounding errors.
- CHECK constraints enforce non-negative balances, positive amounts, and valid enum values.

## 12. Build and Verification

- **Type check:** `npm run typecheck` (`tsc --noEmit -p tsconfig.app.json`)
- **Production build:** `npm run build` (`vite build`)
- **Lint:** `npm run lint` (`eslint .`)

All three pass cleanly as of the current codebase state.
