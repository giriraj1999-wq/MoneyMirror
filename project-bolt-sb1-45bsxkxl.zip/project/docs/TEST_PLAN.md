# SpendWise — Test Plan & Test Data Guide

## 1. Test Account

A test account has been created with the following credentials:

| Field | Value |
|-------|-------|
| Email | `tester@spendwise.demo` |
| Password | `TestPass123!` |

All test data below is pre-loaded for this account for the month of **September 2026**.

---

## 2. Pre-Loaded Test Data

### 2.1 Monthly Plan

| Field | Value |
|-------|-------|
| Month | September 2026 |
| Opening Balance | 50,000 |
| Expected Income | 30,000 (planning only — does not affect real balance) |
| Protected Savings | 5,000 |

### 2.2 Categories

| Category | Essential? | Budget |
|----------|-----------|--------|
| Groceries | Yes | 8,000 |
| Rent | Yes | 15,000 |
| Utilities | Yes | 3,000 |
| Transport | Yes | 4,000 |
| Dining Out | No | 3,000 |
| Entertainment | No | 2,000 |

### 2.3 Transactions

| Date | Type | Amount | Category | Note |
|------|------|--------|----------|------|
| Sep 1 | Income | 30,000 | — | Monthly salary |
| Sep 3 | Expense | 2,000 | Groceries | BigBasket weekly groceries |
| Sep 5 | Expense | 1,500 | Transport | Petrol fill |
| Sep 7 | Expense | 800 | Utilities | Electricity bill |
| Sep 8 | Expense | 500 | Entertainment | Movie tickets |
| Sep 10 | Income | 5,000 | — | Freelance project payment |
| Sep 12 | Expense | 1,200 | Dining Out | Dinner at restaurant |

**Totals:** Income 35,000 · Expenses 6,000

### 2.4 Commitments

| Title | Amount | Due Date | Paid? |
|-------|--------|----------|-------|
| House Rent | 15,000 | Sep 5 | No |
| Car Loan EMI | 8,000 | Sep 10 | No |
| Internet Bill | 1,200 | Sep 15 | No |
| Phone Bill | 500 | Sep 2 | Yes |

**Unpaid total:** 24,200

### 2.5 Expected AAC Calculation

```
Current Balance     = 50,000 + 35,000 - 6,000 = 79,000
Protected Savings   = 5,000
Unpaid Commitments  = 15,000 + 8,000 + 1,200 = 24,200

Remaining Essential Budget:
  Groceries:  max(0, 8,000 - 2,000)   = 6,000
  Rent:       max(0, 15,000 - 0)      = 15,000
  Utilities:  max(0, 3,000 - 800)     = 2,200
  Transport:  max(0, 4,000 - 1,500)  = 2,500
  Total                         = 25,700

AAC = 79,000 - 5,000 - 24,200 - 25,700 = 24,100
Verdict: PLAN HOLDS
```

---

## 3. Test Cases

### TC-01: Sign In with Test Account

**Steps:**
1. Open the app in your browser.
2. If redirected to the login page, enter `tester@spendwise.demo` and `TestPass123!`.
3. Click Sign In.

**Expected:**
- You are taken to the Dashboard.
- The AAC hero card shows **24,100** with a green **PLAN HOLDS** badge.

---

### TC-02: Dashboard Displays Correct Numbers

**Steps:**
1. Navigate to the Dashboard (click "Dashboard" in the sidebar).

**Expected:**

| Metric | Value |
|--------|-------|
| AAC | 24,100 |
| Current Balance | 79,000 |
| Unpaid Commitments | 24,200 |
| Remaining Essential Budget | 25,700 |
| Protected Savings | 5,000 |
| Income this month | 35,000 |
| Expenses this month | 6,000 |
| Next due commitment | House Rent — 15,000 — Sep 5 |

---

### TC-03: View Transactions

**Steps:**
1. Click "Transactions" in the sidebar.

**Expected:**
- 7 transactions listed, sorted by date (most recent first).
- "All" tab shows all 7. "Income" tab shows 2. "Expenses" tab shows 5.
- Each transaction shows amount, category, date, and note.

---

### TC-04: Add a New Transaction

**Steps:**
1. On the Transactions page, click "Add Transaction".
2. Enter: Amount = 1,000, Type = Expense, Category = Groceries, Date = today, Note = "Extra vegetables".
3. Click Save.

**Expected:**
- New transaction appears in the list.
- Dashboard Current Balance decreases by 1,000 (to 78,000).
- Remaining Essential Budget for Groceries decreases by 1,000 (to 5,000).
- AAC decreases by 1,000 (to 23,100).

---

### TC-05: Edit a Transaction

**Steps:**
1. On the Transactions page, click the edit (pencil) icon on any transaction.
2. Change the amount to a different value.
3. Click Save.

**Expected:**
- Transaction updates with the new amount.
- Dashboard numbers recalculate accordingly.

---

### TC-06: Delete a Transaction

**Steps:**
1. On the Transactions page, click the delete (trash) icon on any transaction.
2. Confirm if prompted.

**Expected:**
- Transaction disappears from the list.
- Dashboard numbers recalculate (balance goes up if it was an expense, down if income).

---

### TC-07: AI Parse a Bank SMS

**Steps:**
1. On the Transactions page, find the "Paste bank SMS" box.
2. Paste this sample SMS: `INR 2,500.00 spent on HDFC Card ending 1234 at AMAZON on 25-09-26. Avl bal: Rs.45,200.`
3. Click "Parse with AI".

**Expected:**
- If AI is configured: A draft transaction form appears pre-filled with amount 2,500, merchant Amazon, type expense, and a suggested category. Review and confirm to save.
- If AI is not configured: A blank draft form opens for manual entry.

---

### TC-08: View Commitments

**Steps:**
1. Click "Commitments" in the sidebar.

**Expected:**
- "Upcoming" section shows 3 unpaid commitments: House Rent (15,000), Car Loan EMI (8,000), Internet Bill (1,200).
- "Paid" section shows 1 paid commitment: Phone Bill (500), with a strikethrough.
- Header shows "3 unpaid · 24,200".

---

### TC-09: Mark a Commitment as Paid

**Steps:**
1. On the Commitments page, click the checkmark icon on "Internet Bill" (1,200).

**Expected:**
- Internet Bill moves from "Upcoming" to "Paid" section.
- Header updates to "2 unpaid · 23,000".
- Dashboard AAC increases by 1,200 (from 24,100 to 25,300).

---

### TC-10: Mark a Paid Commitment as Unpaid

**Steps:**
1. On the Commitments page, in the "Paid" section, click the X icon on "Phone Bill".

**Expected:**
- Phone Bill moves back to "Upcoming" section.
- Unpaid total increases by 500.
- Dashboard AAC decreases by 500.

---

### TC-11: Add a New Commitment

**Steps:**
1. On the Commitments page, click "Add Commitment".
2. Enter: Title = "Insurance Premium", Amount = 3,000, Due Date = 2026-09-20.
3. Click Save.

**Expected:**
- New commitment appears in "Upcoming" section.
- Unpaid total increases by 3,000.
- Dashboard AAC decreases by 3,000.

---

### TC-12: Edit a Commitment

**Steps:**
1. On the Commitments page, click the edit (pencil) icon on "Car Loan EMI".
2. Change the amount to 9,000.
3. Click Save.

**Expected:**
- Commitment updates to show 9,000.
- Unpaid total increases by 1,000.
- Dashboard AAC decreases by 1,000.

---

### TC-13: Delete a Commitment

**Steps:**
1. On the Commitments page, click the delete (trash) icon on "Internet Bill".
2. Confirm if prompted.

**Expected:**
- Commitment disappears from the list.
- Unpaid total decreases by its amount.
- Dashboard AAC increases accordingly.

---

### TC-14: Simulator — Safe Purchase (PLAN HOLDS)

**Steps:**
1. Click "Can I Spend This?" in the sidebar.
2. Confirm the AAC shown at the top is **24,100** (or whatever the current value is after your test changes).
3. Enter 20,000 in the amount field.
4. Click "Check".

**Expected:**
- Green card with "Plan Holds" and a green badge.
- Before: 24,100. After: 4,100.
- No shortfall or exposed savings shown.
- AI explanation appears (or a static fallback sentence if AI is unavailable).

---

### TC-15: Simulator — Unsafe Purchase (SHORTFALL)

**Steps:**
1. On the Simulator page, enter 30,000 in the amount field.
2. Click "Check".

**Expected:**
- Red card with "Shortfall" and a red badge.
- Before: 24,100. After: -5,900.
- Shortfall amount: 5,900.
- Protected savings exposed: 5,900.
- AI explanation appears (or static fallback).

---

### TC-16: Simulator — Exact AAC Boundary

**Steps:**
1. On the Simulator page, enter exactly 24,100 (the current AAC).
2. Click "Check".

**Expected:**
- Green card with "Plan Holds".
- Before: 24,100. After: 0.
- No shortfall shown.

---

### TC-17: Simulator — Zero Amount

**Steps:**
1. On the Simulator page, clear the amount field or enter 0.
2. The "Check" button should be disabled.

**Expected:**
- Button is disabled and cannot be clicked.

---

### TC-18: Plan Month — Edit Plan Values

**Steps:**
1. Click "Plan My Month" in the sidebar.
2. Change Protected Savings from 5,000 to 10,000.
3. The value saves automatically (or click Save if there is a save button).

**Expected:**
- Dashboard AAC decreases by 5,000 (from 24,100 to 19,100).
- Protected Savings metric on Dashboard updates to 10,000.

---

### TC-19: Plan Month — Add a New Category

**Steps:**
1. On the Plan Month page, find the category management area.
2. Add a new category named "Healthcare" and mark it as essential.
3. Set a budget of 2,000.

**Expected:**
- New category appears in the list.
- Dashboard Remaining Essential Budget increases by 2,000.
- Dashboard AAC decreases by 2,000.

---

### TC-20: Plan Month — Toggle Essential Flag

**Steps:**
1. On the Plan Month page, toggle "Dining Out" from non-essential to essential.

**Expected:**
- Remaining Essential Budget increases by the Dining Out budget (3,000), since its unspent budget now counts.
- Dashboard AAC decreases by 3,000.

---

### TC-21: Plan Month — Delete a Category

**Steps:**
1. On the Plan Month page, delete the "Entertainment" category.

**Expected:**
- Category disappears from the list.
- Its budget is removed. Since Entertainment was non-essential, AAC does not change.
- Any transactions previously linked to Entertainment remain (category_id set to null).

---

### TC-22: Sign Out

**Steps:**
1. Click the sign-out button (in the sidebar or top bar).

**Expected:**
- You are returned to the login page.
- Navigating to any app page redirects back to login.

---

### TC-23: Sign In Again — Data Persists

**Steps:**
1. After signing out, sign back in with `tester@spendwise.demo` / `TestPass123!`.

**Expected:**
- All your data (plan, categories, budgets, transactions, commitments) is still there.
- Dashboard shows the same numbers as before sign-out.

---

### TC-24: New User — Empty State

**Steps:**
1. Sign out.
2. Create a new account with a different email and password.
3. Sign in with the new account.

**Expected:**
- Dashboard shows an empty state with a "Create a Plan" button.
- Transactions, Commitments, and Simulator pages also show empty states prompting plan creation.

---

### TC-25: New User — Create First Plan

**Steps:**
1. Using the new account from TC-24, click "Create a Plan".
2. Enter opening balance 10,000, expected income 20,000, protected savings 2,000.
3. Default categories should be seeded automatically.
4. Set budgets for a few categories.

**Expected:**
- Plan is created.
- Dashboard now shows AAC based on the new plan.
- Categories page shows the 6 default categories (Groceries, Rent, Utilities, Transport, Dining Out, Entertainment).

---

## 4. Test Summary Checklist

| ID | Test Case | Pass/Fail |
|----|-----------|-----------|
| TC-01 | Sign in with test account | |
| TC-02 | Dashboard displays correct numbers | |
| TC-03 | View transactions list | |
| TC-04 | Add a new transaction | |
| TC-05 | Edit a transaction | |
| TC-06 | Delete a transaction | |
| TC-07 | AI parse a bank SMS | |
| TC-08 | View commitments list | |
| TC-09 | Mark a commitment as paid | |
| TC-10 | Mark a paid commitment as unpaid | |
| TC-11 | Add a new commitment | |
| TC-12 | Edit a commitment | |
| TC-13 | Delete a commitment | |
| TC-14 | Simulator — safe purchase (PLAN HOLDS) | |
| TC-15 | Simulator — unsafe purchase (SHORTFALL) | |
| TC-16 | Simulator — exact AAC boundary | |
| TC-17 | Simulator — zero amount disabled | |
| TC-18 | Edit plan values | |
| TC-19 | Add a new category | |
| TC-20 | Toggle essential flag | |
| TC-21 | Delete a category | |
| TC-22 | Sign out | |
| TC-23 | Sign in — data persists | |
| TC-24 | New user — empty state | |
| TC-25 | New user — create first plan | |

---

## 5. Notes

- The AI features (parse and explain) require an OpenAI API key to be configured as an edge function secret. If the key is not set, both features gracefully fall back: parse opens a blank form for manual entry, and explain shows a static sentence generated from the simulation result.
- All money values are in INR and use Indian number formatting (e.g., 1,00,000).
- The test data is tied to the month of September 2026. If you test in a different month, you will see an empty state for that month and can create a new plan.
- Each user only sees their own data. The test account and any new account you create are completely separate.
