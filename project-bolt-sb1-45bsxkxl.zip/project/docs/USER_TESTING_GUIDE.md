# SpendWise — User Testing Guide

### How to test the app, one step at a time

---

## Before You Begin

You'll need:

- An email address you can check right now (for the sign-up code)
- About 30 minutes to go through the full flow
- A pen and paper to jot down the numbers you enter, so you can verify the app shows the same amounts

**Important:** This is a test. No real money moves anywhere. Everything you enter is stored only in this app's private database for your account. You can delete everything at the end if you wish.

**Currency:** SpendWise supports multiple currencies. A currency picker in the top bar lets you choose how amounts are displayed across the app — Dashboard, Plan, Simulator, and Transactions. Your monthly plan also has a "base currency" (the currency you report in, default INR). When you record a transaction in a different currency, the app converts it to your base currency so your totals always stay consistent.

---

## Part 1: Creating Your Account

### Step 1 — Open the app

Open the app in your browser. You should see the SpendWise welcome screen with a sign-in form.

### Step 2 — Sign up

1. Enter your email address.
2. Choose a password (at least 6 characters).
3. Click **Sign Up**.

**What happens:** The app creates your account and logs you in. You'll land on the Dashboard.

**If you already have an account:** Enter the same email and password, then click **Sign In**.

---

## Part 2: The Dashboard (Your Home Screen)

### Step 3 — Look at the Dashboard

After signing in, you're on the Dashboard. This is your financial command center.

You should see:

- **Available After Commitments** — the big number at the top. This is the money you have left after your essentials, commitments, and protected savings are accounted for.
- **A verdict badge** — either green "Plan Holds" or red "Shortfall." Green means you're on track. Red means you've overspent.
- **Four metric cards** below: Current Balance, Unpaid Commitments, Remaining Essential, and Protected Savings.
- **Next due commitment** — shows your earliest upcoming payment.
- **Savings rate** — what percentage of your income you've kept this month.

**What to check:** Since this is a brand-new account, most of these will show zero or be empty. That's expected — you haven't set up your plan yet.

---

## Part 3: Planning Your Month

This is the most important step. Everything else in the app depends on it.

### Step 4 — Go to the Plan page

Click **Plan** in the menu (left side or top, depending on your screen).

### Step 5 — Set your opening balance

1. Under **Plan My Month**, find the **Opening Balance** field.
2. Enter the amount of money you have right now in your bank account. For testing, enter **50000**.
3. This tells the app "this is what I'm starting the month with."

**Impact:** This number feeds into your Available After Commitments. A higher opening balance means more money available. The currency symbol shown next to each field matches your selected display currency from the top bar.

### Step 6 — Set your expected income

1. Find the **Expected Income** field.
2. Enter **80000** (this is income you expect to receive this month).
3. This tells the app "I expect this much money to come in."

**Impact:** This adds to your available money. The app uses it to check whether your plan is affordable.

### Step 7 — Set your protected savings

1. Find the **Protected Savings** field.
2. Enter **10000**.
3. This tells the app "I want to lock away this much money — don't let me spend it."

**Impact:** This amount is subtracted from your available money. The app protects it so you don't accidentally spend your savings.

### Step 8 — Save your plan

1. Click the **Save Plan** button.
2. You should see "Saved!" appear briefly.

**What to check:** Go back to the Dashboard (click **Dashboard** in the menu). Your Available After Commitments should now show a positive number, and the verdict badge should say **Plan Holds** (green).

---

## Part 4: Setting Up Categories

Categories help the app understand where your money goes.

### Step 9 — Review your default categories

On the Plan page, scroll down to the **Categories** section. You should see a list of pre-added categories like:

- Groceries (Essential)
- Rent (Essential)
- Utilities (Essential)
- Transport (Essential)
- Dining Out (Optional)
- Entertainment (Optional)
- Salary (Income)
- and several income categories

**What "Essential" means:** Essential categories are things you must pay — rent, groceries, utilities. The app protects these in your Available After Commitments calculation. Optional categories can be cut if money gets tight.

### Step 10 — Add a new category

1. In the **Add Category** box, type **Petrol**.
2. Leave the type as **Expense**.
3. Leave **Essential** unchecked (petrol is important but flexible).
4. Click **Add**.

**Impact:** This category now appears in your budget list and can be used when adding transactions.

### Step 11 — Toggle a category to Essential

1. Find the **Dining Out** category.
2. Click the **Optional** button next to it.
3. It should change to **Essential** (amber color).

**Impact:** The app now treats dining out as a must-pay category. This reduces your Available After Commitments because the app reserves money for it.

### Step 12 — Delete a category (with confirmation)

1. Find any category you don't want.
2. Click the trash icon next to it.
3. A red confirmation message appears: "Delete this category? This cannot be undone."
4. Click **Delete** to confirm, or **Cancel** to keep it.

**Impact:** The category is removed. Any transactions already logged under it stay, but they'll show as "Uncategorized."

---

## Part 5: Setting Budgets

Budgets tell the app how much you plan to spend in each category.

### Step 13 — Set budget amounts

On the Plan page, scroll to the **Set Budgets** section. You'll see a row for each expense category with an input box.

1. Find **Rent** and enter **15000**.
2. Find **Groceries** and enter **8000**.
3. Find **Utilities** and enter **3000**.
4. Find **Transport** and enter **2000**.
5. Find **Dining Out** and enter **3000**.
6. Find **Petrol** and enter **2000**.

### Step 14 — Save your budgets

1. Click **Save Budgets**.
2. You should see "Saved!" appear briefly.

**Impact:** These planned amounts are now locked in. The app uses them to calculate how much of your essential spending is still remaining. Go to the Dashboard and check the **Remaining Essential** card — it should show the total of your essential category budgets.

---

## Part 6: Adding Transactions

Transactions are the actual money that comes in and goes out.

### Step 15 — Go to Transactions

Click **Transactions** in the menu.

### Step 16 — Add an income transaction

1. Click **Add Transaction**.
2. A form appears. Make sure the **Income** tab is selected at the top.
3. **Amount:** Enter **80000**.
4. **Category:** Select **Salary**.
5. **Date:** Today's date should already be filled in.
6. **Note:** Type "Monthly salary."
7. Click **Save**.

**Impact:** This adds 80,000 to your income. Go to the Dashboard and check — your Current Balance and Available After Commitments should increase.

### Step 17 — Add an expense transaction

1. Click **Add Transaction** again.
2. Make sure the **Expense** tab is selected.
3. **Amount:** Enter **15000**.
4. **Category:** Select **Rent**.
5. **Date:** Today's date.
6. **Note:** Type "November rent."
7. Click **Save**.

**Impact:** This subtracts 15,000 from your balance. Check the Dashboard — your Current Balance should drop, and the Remaining Essential for Rent should decrease (or reach zero if you've spent the full budget).

### Step 18 — Add a few more expenses

Repeat Step 17 for these:

- **Groceries:** 4000, note "Weekly groceries"
- **Dining Out:** 1500, note "Dinner with friends"
- **Transport:** 500, note "Fuel"
- **Petrol:** 1000, note "Bike petrol"

**What to check:** Your Transactions list should now show 6 entries (1 income + 5 expenses). The Dashboard should reflect all of these in the balance and category progress.

### Step 19 — Edit a transaction

1. Find the **Dining Out** transaction (1,500).
2. Click the pencil icon.
3. Change the amount to **2000**.
4. Click **Save**.

**Impact:** Your balance drops by another 500. The Dining Out category spending increases.

### Step 20 — Delete a transaction (with confirmation)

1. Find the **Petrol** transaction (1,000).
2. Click the trash icon.
3. A confirmation popup appears: "Delete transaction? This will permanently delete the expense of 1,000 (Bike petrol). This cannot be undone."
4. Click **Delete** to confirm.

**Impact:** The transaction is removed. Your balance goes back up by 1,000 since that expense no longer counts.

### Step 21 — Filter transactions

1. Above the transaction list, click **Income**.
2. You should only see income transactions.
3. Click **Expense** — only expenses show.
4. Click **All** — everything shows again.

---

## Part 6b: Multi-Currency Transactions

If you travel or spend in a currency other than your reporting currency, you can record the transaction in the foreign currency and the app converts it for you.

### Step 21b — Change your display currency

1. Look for the currency picker in the top bar (it shows a currency code like INR, USD, EUR).
2. Click it and select **USD**.
3. The Dashboard, Plan page, and Simulator should now display all amounts with the $ symbol instead of ₹.
4. Switch it back to **INR** when you're done observing.

**Impact:** This changes only how amounts are *displayed*. It does not change the currency your transactions are stored in.

### Step 21c — Add a transaction in a foreign currency

1. Click **Add Transaction**.
2. Select the **Expense** tab.
3. **Amount:** Enter **50**.
4. Next to the amount field, there's a currency dropdown (defaults to your display currency). Change it from INR to **USD**.
5. A blue conversion panel appears below the amount showing the equivalent in your reporting currency (e.g. "≈ ₹4,150 in INR · 1 USD = 83.00 INR"). The exchange rate is fetched live.
6. **Category:** Select **Dining Out**.
7. **Note:** Type "Dinner abroad."
8. Click **Save**.

**What to check:** The transaction list shows the amount in the original currency ($50.00 USD) with a smaller line underneath showing the converted equivalent (≈ ₹4,150 INR). Your Dashboard and totals use the converted amount so everything adds up in one currency.

### Step 21d — Edit a foreign-currency transaction

1. Find the "Dinner abroad" transaction.
2. Click the pencil icon.
3. The form shows the original amount (50) and currency (USD), plus the previously saved conversion.
4. Change the amount to **60** — the conversion panel updates automatically with the new rate.
5. Click **Save**.

**Impact:** The converted amount updates. Your Dashboard reflects the new converted total.

---

## Part 7: AI Parse (Smart Transaction Entry)

This feature lets you paste a bank SMS or UPI message and have the app automatically fill in the transaction details.

### Step 22 — Try AI Parse

1. On the Transactions page, find the **AI Parse from Bank SMS** box at the top.
2. Paste or type this sample message:

   ```
   INR 500.00 debited from A/c XX1234 on 26-09-26. Zomato Online Order. UPI Ref 987654321. Available balance 45200.50.
   ```

3. Click **Parse**.

**What happens:** The AI reads the message and fills in a draft transaction:
- Amount: 500
- Type: Expense
- Category: It will try to match "Zomato" to a category (likely Dining Out)
- Note: "Zomato Online Order"

### Step 23 — Review and save the AI draft

1. Check the filled-in form. The AI gives you a draft — you're in control.
2. If the category looks wrong, change it.
3. If the amount looks wrong, fix it.
4. Click **Save** when you're happy.

**Impact:** This adds the transaction just like a manual one. The difference is the AI saved you the typing.

**Important:** The AI is a helper, not a decision-maker. It fills a draft. Nothing is saved until you review and click Save yourself.

---

## Part 8: Commitments (Upcoming Payments)

Commitments are specific bills or payments you know are coming, with a due date.

### Step 24 — Go to Commitments

Click **Commitments** in the menu.

### Step 25 — Add a commitment

1. Click **Add Commitment**.
2. **Title:** Type "Electricity bill."
3. **Amount:** Enter **2500**.
4. **Due date:** Pick a date about 5 days from now.
5. Click **Save**.

**Impact:** This appears in your Unpaid Commitments on the Dashboard. The amount is subtracted from your Available After Commitments — the app reserves money for it so you don't accidentally spend it.

### Step 26 — Add another commitment

1. Add another: Title "Credit card payment," Amount 5000, Due date 10 days from now.
2. Save it.

### Step 27 — Mark a commitment as paid

1. Find the "Electricity bill" commitment.
2. Click **Mark as Paid**.
3. It should move to the "Paid" section below.

**Impact:** The paid amount is no longer subtracted from your Available After Commitments. Your available money goes up because you've handled that bill.

### Step 28 — Delete a commitment (with confirmation)

1. Find the "Credit card payment" commitment.
2. Click the trash icon.
3. A popup appears: "Delete commitment? This will permanently delete 'Credit card payment' (5,000). This cannot be undone."
4. Click **Delete** to confirm.

**Impact:** The commitment is removed entirely. Your available money goes up because that reserved amount is released.

---

## Part 9: The Simulator (What-If Tool)

The Simulator lets you test a hypothetical expense before you actually spend, to see if your plan can absorb it.

### Step 29 — Go to the Simulator

Click **Simulator** in the menu.

### Step 30 — Test a planned purchase

1. Enter an amount you're thinking of spending. Try **5000**.
2. The Simulator shows you:
   - **Before:** Your current Available After Commitments.
   - **After:** What it would be if you spent 5,000.
   - **Verdict:** Green "Plan Holds" if you can afford it, or red "Shortfall" if it would break your plan.
   - **Shortfall amount:** If there's a shortfall, this shows how much you'd be short.

**Note:** All amounts in the Simulator (slider labels, charts, trajectory) are shown in your selected display currency. If you switched the top bar to USD, the Simulator shows $ throughout.

### Step 31 — Apply the scenario to your plan

1. If the verdict says "Plan Holds," you can click **Apply to Plan**.
2. This creates an actual expense transaction for that amount.

**Impact:** The simulated expense becomes real. Your balance drops by that amount. If you don't want to actually record it, just leave the Simulator without clicking Apply.

### Step 32 — Test an amount that causes a shortfall

1. Enter a very large amount, like **200000**.
2. The verdict should turn red: "Shortfall."
3. The shortfall amount shows how far over you'd go.

**Impact:** Nothing is saved — this is just a warning. It tells you "if you spend this much, your plan breaks by this amount."

---

## Part 10: Monthly Review

Monthly Review compares what you planned against what actually happened.

### Step 33 — Go to Monthly Review

On the Plan page, click the **Monthly Review** tab at the top. (You can also reach it from the Plan page tabs.)

### Step 34 — Read the Gap Analysis

At the top, you'll see:

- **Gap Analysis Formula:** Actual Income minus Actual Spend minus Planned Savings.
- The result shows as a surplus (green) or deficit (red).

**What this means:** If you earned more than you spent and saved what you planned, you have a surplus. If you spent more than expected or didn't save enough, you have a deficit.

### Step 35 — Review the Category Variance Table

Below the gap, you'll see each category with:

- **Budgeted:** What you planned to spend.
- **Actual:** What you actually spent.
- **Status:** "Over" (spent more than budget), "Under" (spent less), or "On Track."

**What to check:** Look for categories where you went over budget. Those are the ones to adjust.

### Step 36 — Apply a Course Correction

Below the variance table, you'll see **Ranked Course-Correction Cards**. These are suggestions to fix your budget.

1. Read each card. They're ranked by impact.
2. Find one that says to reduce a category's budget.
3. Click **Apply Correction**.
4. The button changes to "Correction Applied."

**Impact:** The app actually reduces that category's budget in your plan by the amount you overspent. This brings your plan closer to reality. Your Available After Commitments recalculates with the new budget.

---

## Part 11: Shared Expenses (Splitting Bills)

This feature lets you split an expense with friends or family and track who owes what.

### Step 37 — Go to Shared Expenses

Click **Shared** in the menu.

### Step 38 — Split a transaction

1. Go back to **Transactions**.
2. Find an expense transaction (not income).
3. Click the **Split** button next to it.
4. Enter the details of the person you're splitting with:
   - **Email:** Enter a friend's email address (for testing, use your own email or a made-up one).
   - **Amount:** Enter how much they owe. If the transaction is 2,000, enter 1000 for a 50-50 split.
   - **Currency:** Leave as INR.
5. Click **Send Split Request**.

**What happens:** The app records the split and tries to send an invite email to that person. If they don't have an account yet, the split is saved and will appear on their Shared Expenses page once they sign up.

### Step 39 — View your shared balance

1. Go to **Shared** in the menu.
2. You'll see two sections:
   - **Outgoing** (money owed to you): Shows splits you created where others owe you.
   - **Incoming** (money you owe): Shows splits where someone else split a transaction with you.
3. The **Shared Balance** at the top shows the net: either "You're owed X" or "You owe X."

### Step 40 — Mark a share as paid (if you owe someone)

If someone split a transaction with you and you appear in the Incoming section:

1. Find the share in the Incoming list.
2. Click **Mark as Paid**.
3. The status changes to "Paid."

**Impact:** This tells the other person "I've paid my share." They'll be able to confirm receipt on their end.

### Step 41 — Acknowledge a payment (if someone paid you)

If you created a split and the other person marked it as paid:

1. Find the share in the Outgoing list with status "Paid."
2. Click **Confirm Received**.
3. The status changes to "Acknowledged."

**Impact:** The app creates a settlement income transaction on your account for the amount they paid you. Your balance goes up by that amount. The split is now fully settled.

---

## Part 12: Goals (Savings Targets)

Goals let you set savings targets and track your progress.

### Step 42 — Go to Goals

Click **Goals** in the menu (or go to the Plan page and click the **Goals** tab).

### Step 43 — Create a goal

1. Click **New Goal**.
2. **Goal name:** Type "Emergency Fund."
3. **Target date:** Pick a date 6 months from now.
4. **Target amount:** Enter **100000**.
5. **Already saved:** Enter **20000** (pretend you've already saved this much).
6. **Monthly contribution:** Enter **5000** (how much you plan to save per month).
7. Click **Create Goal**.

**Impact:** The goal appears as a card showing:
- Current saved amount (20,000)
- Target (100,000)
- Progress percentage (20%)
- Status: "On track" if your monthly pace is enough, or "Behind" if it isn't.
- Required monthly pace: How much you'd need to save per month to hit the target on time.

### Step 44 — Edit a goal

1. Click **Edit** on the goal.
2. Change "Already saved" to **30000**.
3. Click **Save Changes**.

**Impact:** The progress jumps to 30%. The status may change from "Behind" to "On track" if the new pace is sufficient.

### Step 45 — Delete a goal (with confirmation)

1. Click the trash icon on the goal.
2. A popup appears: "Delete goal? This will permanently delete 'Emergency Fund' and all its progress. This cannot be undone."
3. Click **Delete** to confirm.

**Impact:** The goal and all its tracking data are permanently removed.

---

## Part 13: Yearly Plan

Yearly Plan lets you set up a 12-month financial envelope based on your income, savings target, and variable budgets.

### Step 46 — Go to Yearly Plan

On the Plan page, click the **Yearly Plan** tab.

### Step 47 — Step 1: Enter monthly income

1. You should be on Step 1 (Income). If not, click the **Income** step at the top.
2. Enter **80000** as your monthly net income.
3. The app shows your annualized income (80000 x 12 = 9,60,000).
4. Click **Continue**.

### Step 48 — Step 2: Set savings target

1. Enter **10000** as your monthly savings target.
2. The app shows your savings rate (10000 / 80000 = 12.5%).
3. A note tells you whether you're above or below the 20% benchmark.
4. Click **Continue**.

### Step 49 — Step 3: Set variable budgets

1. You'll see default categories: Groceries, Dining Out, Entertainment, Transport, Shopping, Health.
2. Enter monthly amounts for each:
   - Groceries: 8000
   - Dining Out: 3000
   - Entertainment: 2000
   - Transport: 2000
   - Shopping: 2000
   - Health: 1000
3. To add a custom category, type a name in the box and click the + button.
4. To remove a category, click the trash icon next to it.
5. Click **Continue**.

### Step 50 — Step 4: Review

1. You'll see an allocation bar showing how your income splits across Savings, Variable, and Fixed.
2. Check the summary: Annual income, annual savings, annual variable, annual fixed.
3. If savings + variable exceed income, a yellow warning appears.
4. Click **Continue**.

### Step 51 — Step 5: Generate

1. You'll see a preview of 12 monthly envelopes showing the fixed amount and savings for each month.
2. Click **Generate Yearly Plan**.
3. The button shows "Generating..." then "Plan Generated."

**Impact:** The app creates 12 monthly plans in your account, each with your expected income and protected savings pre-filled. You can now go to any month's Plan page and find these values already set.

### Step 52 — Verify the generated plans

1. Go to the **Plan** page (Plan My Month tab).
2. Your opening balance, expected income, and protected savings should reflect the yearly plan values.
3. Change the month (if your app supports month navigation) and verify other months also have the values.

---

## Part 14: Notifications

### Step 53 — Check notifications

1. Look for the bell icon in the top-right corner of the app.
2. Click it to see your notifications.
3. You may see notifications for:
   - Shared expense invites (when someone splits a transaction with you)
   - Share status updates (when someone marks a split as paid or acknowledges)

**Impact:** Notifications help you stay on top of shared expenses without checking the Shared page constantly.

---

## Part 15: Dark Mode

### Step 54 — Toggle dark mode

1. Look for a theme toggle (sun/moon icon) in the top bar.
2. Click it to switch between light and dark mode.
3. All pages should switch colors smoothly.

**What to check:** Make sure all text is readable in both modes. If any text is hard to see against the background, note it as a bug.

---

## Part 16: Signing Out

### Step 55 — Sign out

1. Look for your account menu (usually your email or an avatar in the top-right).
2. Click **Sign Out**.
3. You should return to the welcome/sign-in screen.

### Step 56 — Sign back in

1. Enter the same email and password.
2. Click **Sign In**.
3. All your data should be exactly as you left it — plans, transactions, commitments, goals, everything.

**What to check:** Your Dashboard should show the same numbers as before you signed out. If anything is missing, that's a bug.

---

## Quick Checklist

Use this to make sure you've tested everything:

- [ ] Created an account and signed in
- [ ] Dashboard loads and shows zeros (new account)
- [ ] Set opening balance, expected income, and protected savings
- [ ] Saved the plan and verified Dashboard updated
- [ ] Reviewed default categories
- [ ] Added a custom category
- [ ] Toggled a category to Essential
- [ ] Deleted a category (saw confirmation)
- [ ] Set budget amounts for expense categories
- [ ] Saved budgets
- [ ] Added an income transaction
- [ ] Added expense transactions
- [ ] Edited a transaction
- [ ] Deleted a transaction (saw confirmation)
- [ ] Filtered transactions by type
- [ ] Changed display currency in the top bar and verified amounts updated
- [ ] Added a transaction in a foreign currency and saw the live conversion
- [ ] Verified the transaction list shows both original and converted amounts
- [ ] Used AI Parse to create a transaction from text
- [ ] Added a commitment
- [ ] Marked a commitment as paid
- [ ] Deleted a commitment (saw confirmation)
- [ ] Tested the Simulator with an affordable amount
- [ ] Tested the Simulator with an unaffordable amount
- [ ] Reviewed Monthly Review gap analysis
- [ ] Reviewed category variance table
- [ ] Applied a course correction
- [ ] Split a transaction with someone
- [ ] Viewed shared balance
- [ ] Created a financial goal
- [ ] Edited a goal
- [ ] Deleted a goal (saw confirmation)
- [ ] Completed all 5 steps of Yearly Plan
- [ ] Generated a yearly plan
- [ ] Verified generated monthly plans
- [ ] Checked notifications
- [ ] Toggled dark mode
- [ ] Signed out and signed back in
- [ ] All data was preserved after re-login

---

## If Something Goes Wrong

**The app won't load:** Refresh your browser. If it still won't load, check your internet connection.

**A number looks wrong:** Go back to the Plan page and check your inputs. The app calculates everything from your opening balance, income, savings, budgets, transactions, and commitments. If one of those is wrong, the whole picture changes.

**A button doesn't respond:** Refresh the page and try again. If it still doesn't work, note which page and which button.

**You see "Shortfall" unexpectedly:** This means your planned spending (essentials + commitments + protected savings) exceeds your available money. Check your Dashboard to see which number is too high, then adjust your plan or add income.

**A transaction shows a different amount than you entered:** If you recorded the transaction in a foreign currency, the app shows both the original amount and the converted amount in your reporting currency. The converted amount uses a live exchange rate, so it may differ slightly from what you see on Google. The original amount is always preserved.

**Currency symbols look wrong:** Check the currency picker in the top bar — it controls how all amounts are displayed. If it's set to USD, everything shows in $ even if your plan's base currency is INR.

**You can't find a feature:** All features are accessible from the menu. The Plan page has tabs for Plan My Month, Yearly Plan, Goals, and Monthly Review.

---

## What to Report

If you find a problem, note:

1. **Which page** you were on (Dashboard, Transactions, Plan, etc.)
2. **What you did** (clicked a button, entered a number, etc.)
3. **What you expected** to happen
4. **What actually happened** instead

That's it! You've now tested the complete SpendWise flow from sign-up through every feature. Thank you for helping make the app better.
