-- The original unique constraint was (user_id, name) which prevented
-- having both an income and expense category with the same name.
-- Replace it with (user_id, name, type) so the same name is allowed
-- across different types.

ALTER TABLE public.categories
  DROP CONSTRAINT IF EXISTS categories_user_id_name_key;

ALTER TABLE public.categories
  ADD CONSTRAINT categories_user_id_name_type_key UNIQUE (user_id, name, type);
