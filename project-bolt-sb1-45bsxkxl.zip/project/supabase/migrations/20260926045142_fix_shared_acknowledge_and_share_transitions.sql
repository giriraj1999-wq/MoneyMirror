/*
# Fix shared expense settlement and enforce status transitions

## 1. New Function: acknowledge_share
- SECURITY DEFINER function that allows the share OWNER to acknowledge a paid share.
- Creates a settlement income transaction on the owner's plan (bypasses RLS since the owner is authenticated).
- Updates the share status to 'acknowledged' with the settlement transaction link.
- Uses share_amount_base for cross-currency correctness.

## 2. New Function: mark_share_paid
- SECURITY DEFINER function that allows the PARTNER to mark a share as paid.
- Only allows transition from 'accepted' to 'paid'.
- Sets paid_at timestamp.

## 3. Policy Changes: transaction_shares
- Drops the overly permissive update_own_shares policy.
- Creates two separate UPDATE policies:
  - Partner can only update status to 'paid' (from accepted/pending).
  - Owner can only update status to 'acknowledged' (from paid).
- This enforces the documented lifecycle: pending → accepted → paid → acknowledged.

## 4. Grant execute on new functions
- Both functions are callable by authenticated role only.
*/

-- Function: acknowledge_share (owner confirms receipt of payment)
CREATE OR REPLACE FUNCTION public.acknowledge_share(share_uuid uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_share transaction_shares%ROWTYPE;
  v_owner_plan_id uuid;
  v_settlement_txn_id uuid;
  v_settlement_amount numeric;
BEGIN
  -- Load the share
  SELECT * INTO v_share FROM transaction_shares WHERE id = share_uuid;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Share not found';
  END IF;

  -- Only the owner can acknowledge
  IF v_share.owner_user_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the share owner can acknowledge';
  END IF;

  -- Must be in 'paid' status
  IF v_share.status <> 'paid' THEN
    RAISE EXCEPTION 'Share must be in paid status to acknowledge';
  END IF;

  -- Find the owner's plan for the current month
  SELECT id INTO v_owner_plan_id
  FROM plans
  WHERE user_id = v_share.owner_user_id
    AND month = date_trunc('month', now())::text || '-01'
  LIMIT 1;

  IF v_owner_plan_id IS NULL THEN
    -- Fallback to most recent plan
    SELECT id INTO v_owner_plan_id
    FROM plans
    WHERE user_id = v_share.owner_user_id
    ORDER BY month DESC
    LIMIT 1;
  END IF;

  IF v_owner_plan_id IS NULL THEN
    RAISE EXCEPTION 'Owner has no plan';
  END IF;

  -- Use base amount if available, otherwise share_amount
  v_settlement_amount := COALESCE(v_share.share_amount_base, v_share.share_amount);

  -- Create settlement income transaction on owner's plan
  INSERT INTO transactions (
    user_id, plan_id, category_id, amount, type, txn_date,
    note, source, currency
  ) VALUES (
    v_share.owner_user_id,
    v_owner_plan_id,
    NULL,
    v_settlement_amount,
    'income',
    CURRENT_DATE::text,
    'Settlement from ' || v_share.partner_email,
    'manual',
    'INR'
  )
  RETURNING id INTO v_settlement_txn_id;

  -- Mark share as acknowledged
  UPDATE transaction_shares
  SET status = 'acknowledged',
      acknowledged_at = now(),
      settlement_txn_id = v_settlement_txn_id,
      updated_at = now()
  WHERE id = share_uuid;

  RETURN v_settlement_txn_id;
END;
$$;

-- Function: mark_share_paid (partner marks their share as paid)
CREATE OR REPLACE FUNCTION public.mark_share_paid(share_uuid uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_share transaction_shares%ROWTYPE;
BEGIN
  SELECT * INTO v_share FROM transaction_shares WHERE id = share_uuid;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Share not found';
  END IF;

  -- Only the partner can mark as paid
  IF v_share.partner_user_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the partner can mark as paid';
  END IF;

  -- Must be in 'accepted' or 'pending' status
  IF v_share.status NOT IN ('accepted', 'pending') THEN
    RAISE EXCEPTION 'Share must be in accepted or pending status to mark as paid';
  END IF;

  UPDATE transaction_shares
  SET status = 'paid',
      paid_at = now(),
      updated_at = now()
  WHERE id = share_uuid;
END;
$$;

-- Grant execute to authenticated
GRANT EXECUTE ON FUNCTION public.acknowledge_share(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.mark_share_paid(uuid) TO authenticated;

-- Fix the overly permissive UPDATE policy on transaction_shares
DROP POLICY IF EXISTS "update_own_shares" ON public.transaction_shares;

-- Partner can only update status to 'paid'
CREATE POLICY "update_share_as_partner"
ON public.transaction_shares FOR UPDATE
TO authenticated
USING (
  partner_user_id = auth.uid()
)
WITH CHECK (
  partner_user_id = auth.uid()
  AND status = 'paid'
);

-- Owner can only update status to 'acknowledged'
CREATE POLICY "update_share_as_owner"
ON public.transaction_shares FOR UPDATE
TO authenticated
USING (
  owner_user_id = auth.uid()
)
WITH CHECK (
  owner_user_id = auth.uid()
  AND status = 'acknowledged'
);
