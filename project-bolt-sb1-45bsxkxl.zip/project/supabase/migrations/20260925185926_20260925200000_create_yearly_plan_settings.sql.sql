/*
# Create yearly plan settings

1. New Tables
- `yearly_plan_settings` stores each signed-in user's progress through the yearly envelope builder.
- `yearly_plan_settings.user_id` identifies the owner.
- `yearly_plan_settings.plan_year` identifies the calendar year.
- `yearly_plan_settings.current_step` stores the active builder step from 1 to 5.
- `yearly_plan_settings.monthly_income` stores the confirmed net monthly income.
- `yearly_plan_settings.savings_target` stores the target monthly savings amount.
- `yearly_plan_settings.variable_budgets` stores the user's yearly variable budget allocations as JSON.
- `yearly_plan_settings.generated` records whether the yearly envelopes have been generated.

2. Security
- Row Level Security is enabled.
- Separate authenticated owner policies allow users to select, create, update, and delete only their own yearly plan settings.

3. Integrity
- One yearly builder record is allowed per user and calendar year.
- Builder steps are constrained to 1 through 5.
- Monetary values cannot be negative.
*/

CREATE TABLE IF NOT EXISTS public.yearly_plan_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_year integer NOT NULL CHECK (plan_year BETWEEN 2000 AND 2100),
  current_step integer NOT NULL DEFAULT 1 CHECK (current_step BETWEEN 1 AND 5),
  monthly_income numeric(14,2) NOT NULL DEFAULT 0 CHECK (monthly_income >= 0),
  savings_target numeric(14,2) NOT NULL DEFAULT 0 CHECK (savings_target >= 0),
  variable_budgets jsonb NOT NULL DEFAULT '{}'::jsonb,
  generated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, plan_year)
);

CREATE INDEX IF NOT EXISTS yearly_plan_settings_user_year_idx
  ON public.yearly_plan_settings(user_id, plan_year);

ALTER TABLE public.yearly_plan_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own yearly plans" ON public.yearly_plan_settings;
CREATE POLICY "Users can view own yearly plans" ON public.yearly_plan_settings FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can create own yearly plans" ON public.yearly_plan_settings;
CREATE POLICY "Users can create own yearly plans" ON public.yearly_plan_settings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can update own yearly plans" ON public.yearly_plan_settings;
CREATE POLICY "Users can update own yearly plans" ON public.yearly_plan_settings FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can delete own yearly plans" ON public.yearly_plan_settings;
CREATE POLICY "Users can delete own yearly plans" ON public.yearly_plan_settings FOR DELETE TO authenticated USING (auth.uid() = user_id);