/*
# Add bill attachment support to transactions

1. Schema Changes
- Adds `bill_url` (text, nullable) column to `public.transactions`.
  Stores the Supabase Storage public URL of an uploaded invoice/bill image.
- Adds `bill_path` (text, nullable) column to `public.transactions`.
  Stores the storage path (bucket/filename) so the file can be deleted when
  the transaction is deleted or the bill is replaced.

2. Storage
- Creates a `transaction-bills` storage bucket (public read) for bill images.
- Policies: authenticated users can upload, read, and delete files in this
  bucket. Files are scoped to the user's ID in the path.

3. Security
- No RLS changes needed — the columns are on the existing `transactions` table
  which already has owner-scoped RLS.
- Storage policies restrict uploads/deletes to the authenticated user who owns
  the file (path must start with their user ID).
*/

-- Add bill columns to transactions
ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS bill_url text,
  ADD COLUMN IF NOT EXISTS bill_path text;

-- Create storage bucket for bill attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('transaction-bills', 'transaction-bills', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: users can manage their own bill files
-- Path convention: <user_id>/<filename>
DROP POLICY IF EXISTS "users_upload_own_bills" ON storage.objects;
CREATE POLICY "users_upload_own_bills" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'transaction-bills'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "users_read_own_bills" ON storage.objects;
CREATE POLICY "users_read_own_bills" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'transaction-bills'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "users_delete_own_bills" ON storage.objects;
CREATE POLICY "users_delete_own_bills" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'transaction-bills'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
