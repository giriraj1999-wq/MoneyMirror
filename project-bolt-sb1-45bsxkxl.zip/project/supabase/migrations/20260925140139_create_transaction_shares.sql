/*
# Add Split Transaction Sharing

1. New Tables
- `transaction_shares`: Records that a transaction has been split with another person.
  - `id` (uuid PK)
  - `transaction_id` (uuid FK → transactions, ON DELETE CASCADE) — the original expense transaction
  - `owner_user_id` (uuid FK → auth.users) — the person who paid and is owed money
  - `partner_email` (text) — email of the person invited to share the cost
  - `partner_user_id` (uuid, nullable, FK → auth.users) — filled in when the partner signs up / is matched
  - `share_amount` (numeric(14,2), CHECK > 0) — how much the partner owes
  - `status` (text, CHECK IN ('pending', 'accepted', 'paid', 'acknowledged')) — lifecycle of the share
  - `paid_at` (timestamptz, nullable) — when partner marked it paid
  - `acknowledged_at` (timestamptz, nullable) — when owner confirmed receiving payment
  - `settlement_txn_id` (uuid, nullable, FK → transactions) — the income transaction created on owner's sheet when acknowledged
  - `created_at`, `updated_at` (timestamptz)

2. Security
- RLS enabled on transaction_shares.
- SELECT: owner can see shares they created; partner can see shares where partner_user_id matches their auth.uid().
- INSERT: only the transaction owner can create a share (verified via transaction ownership).
- UPDATE: owner can update status to 'acknowledged'; partner (partner_user_id = auth.uid()) can update status to 'paid'.
- DELETE: only the transaction owner can delete a share.

3. Important Notes
- The share lifecycle is: pending → accepted (when partner signs up) → paid (partner marks paid) → acknowledged (owner confirms receipt, which creates an income transaction on owner's sheet).
- Only the original payer sees the full transaction; the partner sees only the shared split record.
- When acknowledged, a settlement income transaction is created on the owner's plan to reflect the received repayment.
*/

CREATE TABLE IF NOT EXISTS public.transaction_shares (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES public.transactions(id) ON DELETE CASCADE,
  owner_user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  partner_email text NOT NULL,
  partner_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  share_amount numeric(14,2) NOT NULL CHECK (share_amount > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'paid', 'acknowledged')),
  paid_at timestamptz,
  acknowledged_at timestamptz,
  settlement_txn_id uuid REFERENCES public.transactions(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS transaction_shares_owner_idx ON public.transaction_shares(owner_user_id);
CREATE INDEX IF NOT EXISTS transaction_shares_partner_idx ON public.transaction_shares(partner_user_id);
CREATE INDEX IF NOT EXISTS transaction_shares_txn_idx ON public.transaction_shares(transaction_id);

ALTER TABLE public.transaction_shares ENABLE ROW LEVEL SECURITY;

-- SELECT: owner sees their outgoing shares; partner sees incoming shares matched to them
DROP POLICY IF EXISTS "view_own_shares" ON public.transaction_shares;
CREATE POLICY "view_own_shares" ON public.transaction_shares FOR SELECT
  TO authenticated USING (
    owner_user_id = auth.uid()
    OR partner_user_id = auth.uid()
  );

-- INSERT: only the transaction owner can create a share
DROP POLICY IF EXISTS "insert_own_shares" ON public.transaction_shares;
CREATE POLICY "insert_own_shares" ON public.transaction_shares FOR INSERT
  TO authenticated WITH CHECK (
    owner_user_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.transactions t
      WHERE t.id = transaction_shares.transaction_id
        AND t.user_id = auth.uid()
    )
  );

-- UPDATE: owner can acknowledge; partner can mark paid
DROP POLICY IF EXISTS "update_own_shares" ON public.transaction_shares;
CREATE POLICY "update_own_shares" ON public.transaction_shares FOR UPDATE
  TO authenticated USING (
    owner_user_id = auth.uid()
    OR partner_user_id = auth.uid()
  ) WITH CHECK (
    owner_user_id = auth.uid()
    OR partner_user_id = auth.uid()
  );

-- DELETE: only the transaction owner can remove a share
DROP POLICY IF EXISTS "delete_own_shares" ON public.transaction_shares;
CREATE POLICY "delete_own_shares" ON public.transaction_shares FOR DELETE
  TO authenticated USING (owner_user_id = auth.uid());
