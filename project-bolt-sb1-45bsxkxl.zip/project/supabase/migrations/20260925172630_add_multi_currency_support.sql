/*
# Add Multi-Currency Support

1. Schema Changes
- `public.transactions`: add `currency` text NOT NULL DEFAULT 'INR' (ISO 4217 code).
  Stores the currency the transaction was recorded in.
- `public.transaction_shares`: add `share_currency` text NOT NULL DEFAULT 'INR'
  (the currency the partner's share is denominated in) and `share_amount_base`
  numeric(14,2) nullable (the share amount converted to the owner's base
  currency, for settlement calculations).
- `public.plans`: add `base_currency` text NOT NULL DEFAULT 'INR' — the user's
  preferred reporting currency.

2. Security
- No RLS changes — the new columns inherit the existing owner-scoped policies.
- No data loss: all existing rows get 'INR' as the default, preserving
  current behavior.
*/

ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS currency text NOT NULL DEFAULT 'INR';

ALTER TABLE public.transaction_shares
  ADD COLUMN IF NOT EXISTS share_currency text NOT NULL DEFAULT 'INR',
  ADD COLUMN IF NOT EXISTS share_amount_base numeric(14,2);

ALTER TABLE public.plans
  ADD COLUMN IF NOT EXISTS base_currency text NOT NULL DEFAULT 'INR';
