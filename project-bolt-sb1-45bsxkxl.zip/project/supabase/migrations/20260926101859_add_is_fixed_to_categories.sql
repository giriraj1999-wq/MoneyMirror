/*
# Add is_fixed column to categories

1. Schema Changes
- Adds `is_fixed` boolean column to `public.categories` (default false).
- This distinguishes fixed/recurring expenses (rent, insurance, EMI) from
  variable/discretionary expenses (groceries, dining, entertainment) on the
  Plan My Month budget-setting screen.

2. Security
- No RLS changes. The existing owner-scoped policies on `categories`
  already cover the new column.
*/

ALTER TABLE public.categories
  ADD COLUMN IF NOT EXISTS is_fixed boolean NOT NULL DEFAULT false;

-- Mark common fixed expense categories as fixed for existing users
UPDATE public.categories
SET is_fixed = true
WHERE type = 'expense'
  AND lower(name) IN ('rent', 'emi', 'insurance', 'loan', 'mortgage', 'subscription', 'salary advance', 'sip', 'property tax');
