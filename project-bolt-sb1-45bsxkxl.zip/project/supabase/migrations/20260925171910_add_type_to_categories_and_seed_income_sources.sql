/*
# Add income source categories

1. Schema Changes
- Adds `type` column to `public.categories` (text, default 'expense',
  CHECK constraint: 'income' or 'expense').
- This lets the app distinguish income source categories (Salary, Freelancing,
  etc.) from expense categories (Groceries, Rent, etc.) so the transaction
  form can show only relevant categories based on the selected type.

2. Data Changes
- Seeds income source categories for ALL existing users who don't yet have
  them. Uses a DISTINCT ON query to find users who already have categories
  and inserts the missing income sources for them.

3. Security
- No RLS changes. The existing owner-scoped policies on `categories`
  already cover the new column.
*/

ALTER TABLE public.categories
  ADD COLUMN IF NOT EXISTS type text NOT NULL DEFAULT 'expense'
  CHECK (type IN ('income', 'expense'));

-- Seed income source categories for existing users
INSERT INTO public.categories (user_id, name, is_essential, type)
SELECT DISTINCT ON (u.id, ic.name)
  u.id,
  ic.name,
  false,
  'income'
FROM auth.users u
CROSS JOIN (VALUES
  ('Salary'),
  ('Stock Market'),
  ('Interest on Deposits'),
  ('Employee Bonus'),
  ('Crypto'),
  ('Freelancing'),
  ('Consultancy'),
  ('Rental Income'),
  ('Dividends'),
  ('Gift')
) AS ic(name)
WHERE NOT EXISTS (
  SELECT 1 FROM public.categories c
  WHERE c.user_id = u.id
    AND c.name = ic.name
    AND c.type = 'income'
)
ORDER BY u.id, ic.name;
