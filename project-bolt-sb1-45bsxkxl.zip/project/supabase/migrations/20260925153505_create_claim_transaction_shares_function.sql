/*
# Auto-claim transaction shares on login

1. New Functions
- `claim_transaction_shares()` — SECURITY DEFINER function that runs when a user
  logs in. It finds all `transaction_shares` rows where `partner_email` matches
  the calling user's email but `partner_user_id` is null or doesn't match,
  links them to the user's ID, and flips any `pending` shares to `accepted`.
  This is the missing bridge: when someone is invited to split an expense,
  a share row is created with their email. When they eventually sign up or
  log in, this function claims those shares so they appear on their
  Shared Expenses page.

2. Security
- The function is SECURITY DEFINER so it can update rows the calling user
  doesn't own (the share rows belong to the transaction owner, not the
  partner). It only updates rows matching the caller's verified email,
  so a user can only claim shares intended for them.
- Returns the count of shares claimed.
*/

CREATE OR REPLACE FUNCTION public.claim_transaction_shares()
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  caller_email text;
  caller_id uuid;
  claimed_count integer;
BEGIN
  caller_id := auth.uid();
  IF caller_id IS NULL THEN
    RETURN 0;
  END IF;

  SELECT email INTO caller_email
  FROM auth.users
  WHERE id = caller_id;

  IF caller_email IS NULL THEN
    RETURN 0;
  END IF;

  caller_email := lower(trim(caller_email));

  -- Link shares to this user and flip pending → accepted
  UPDATE public.transaction_shares
  SET partner_user_id = caller_id,
      status = CASE WHEN status = 'pending' THEN 'accepted' ELSE status END,
      updated_at = now()
  WHERE lower(trim(partner_email)) = caller_email
    AND (partner_user_id IS NULL OR partner_user_id <> caller_id);

  GET DIAGNOSTICS claimed_count = ROW_COUNT;

  RETURN claimed_count;
END;
$$;

GRANT EXECUTE ON FUNCTION public.claim_transaction_shares() TO authenticated;
