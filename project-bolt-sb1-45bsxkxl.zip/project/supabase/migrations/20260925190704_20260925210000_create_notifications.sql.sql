/*
# Create notifications table

1. New Tables
- `notifications` stores in-app notifications for each signed-in user.
- `notifications.user_id` identifies the owner.
- `notifications.type` stores the notification category (e.g. 'transaction_new', 'transaction_updated').
- `notifications.title` is the headline shown in the bell dropdown.
- `notifications.body` is the optional description text.
- `notifications.entity_id` optionally links to the related record (e.g. transaction id).
- `notifications.is_read` tracks whether the user has dismissed it.

2. Security
- Row Level Security is enabled.
- Separate authenticated owner policies for select, insert, update, and delete.

3. Integrity
- Title must contain visible text.
- One notification per user per entity+type to avoid duplicates (unique constraint).
*/

CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (char_length(trim(type)) > 0),
  title text NOT NULL CHECK (char_length(trim(title)) > 0),
  body text,
  entity_id uuid,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS notifications_user_created_idx
  ON public.notifications(user_id, created_at DESC);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own notifications" ON public.notifications;
CREATE POLICY "Users can view own notifications" ON public.notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can create own notifications" ON public.notifications;
CREATE POLICY "Users can create own notifications" ON public.notifications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can update own notifications" ON public.notifications;
CREATE POLICY "Users can update own notifications" ON public.notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can delete own notifications" ON public.notifications;
CREATE POLICY "Users can delete own notifications" ON public.notifications FOR DELETE TO authenticated USING (auth.uid() = user_id);