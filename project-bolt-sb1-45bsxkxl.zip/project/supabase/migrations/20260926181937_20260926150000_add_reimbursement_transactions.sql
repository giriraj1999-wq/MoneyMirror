/*
# Add reimbursement transaction type and correct shared-expense accounting

1. Changes
- Extend `public.transactions.type` to support `reimbursement` in addition to `income` and `expense`.
- Rebuild the shared-expense acknowledgement function so repayments are recorded as reimbursements, not income.
- Keep the reimbursement on the original expense's plan and date, using the plan base currency.

2. Accounting behavior
- A split expense is reduced to the amount owed by the owner.
- Each partner share remains tracked in `transaction_shares` as money receivable.
- When a partner payment is acknowledged, the resulting reimbursement is excluded from income and expense totals.

3. Security
- Preserve the existing authenticated-only function grant.
- Keep owner and status checks in the SECURITY DEFINER function.

4. Important notes
- No existing transaction rows are deleted or rewritten by this migration.
- Existing income and expense transactions keep their current types.
*/

ALTER TABLE public.transactions
  DROP CONSTRAINT IF EXISTS transactions_type_check;

ALTER TABLE public.transactions
  ADD CONSTRAINT transactions_type_check
  CHECK (type IN ('income', 'expense', 'reimbursement'));

CREATE OR REPLACE FUNCTION public.acknowledge_share(share_uuid uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_share transaction_shares%ROWTYPE;
  v_original transactions%ROWTYPE;
  v_plan plans%ROWTYPE;
  v_settlement_txn_id uuid;
  v_settlement_amount numeric;
BEGIN
  SELECT * INTO v_share
  FROM transaction_shares
  WHERE id = share_uuid;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Share not found';
  END IF;

  IF v_share.owner_user_id <> auth.uid() THEN
    RAISE EXCEPTION 'Only the share owner can acknowledge';
  END IF;

  IF v_share.status <> 'paid' THEN
    RAISE EXCEPTION 'Share must be in paid status to acknowledge';
  END IF;

  SELECT * INTO v_original
  FROM transactions
  WHERE id = v_share.transaction_id
    AND user_id = v_share.owner_user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Original transaction not found';
  END IF;

  SELECT * INTO v_plan
  FROM plans
  WHERE id = v_original.plan_id
    AND user_id = v_share.owner_user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Owner plan not found';
  END IF;

  v_settlement_amount := COALESCE(v_share.share_amount_base, v_share.share_amount);

  INSERT INTO transactions (
    user_id, plan_id, category_id, amount, amount_base, type, txn_date,
    note, source, currency
  ) VALUES (
    v_share.owner_user_id,
    v_original.plan_id,
    NULL,
    v_settlement_amount,
    v_settlement_amount,
    'reimbursement',
    v_original.txn_date,
    'Reimbursement from ' || v_share.partner_email,
    'manual',
    v_plan.base_currency
  )
  RETURNING id INTO v_settlement_txn_id;

  UPDATE transaction_shares
  SET status = 'acknowledged',
      acknowledged_at = now(),
      settlement_txn_id = v_settlement_txn_id,
      updated_at = now()
  WHERE id = share_uuid;

  RETURN v_settlement_txn_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.acknowledge_share(uuid) TO authenticated;