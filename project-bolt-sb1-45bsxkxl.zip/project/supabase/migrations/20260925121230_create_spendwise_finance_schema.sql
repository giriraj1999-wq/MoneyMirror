/*
# Create MoneyMirror finance schema

1. New Tables
- `plans`: one monthly plan per signed-in user, storing opening balance, expected income, and protected savings.
- `categories`: user-owned spending categories with an essential/non-essential flag.
- `budgets`: monthly planned amount for each category.
- `transactions`: user-owned income and expense records linked to a monthly plan.
- `commitments`: user-owned future payments linked to a monthly plan.

2. Security
- Row Level Security is enabled on every table.
- Plans, categories, transactions, and commitments use authenticated owner policies.
- Budgets are protected through ownership of their parent plan.
- Each table has separate SELECT, INSERT, UPDATE, and DELETE policies.

3. Integrity
- Money values use numeric(14,2), never floating point.
- Each user can have one plan per month and one budget per category per plan.
- Transaction and source values are restricted to approved options.
*/

CREATE TABLE IF NOT EXISTS public.plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  month date NOT NULL,
  opening_balance numeric(14,2) NOT NULL DEFAULT 0 CHECK (opening_balance >= 0),
  expected_income numeric(14,2) NOT NULL DEFAULT 0 CHECK (expected_income >= 0),
  protected_savings numeric(14,2) NOT NULL DEFAULT 0 CHECK (protected_savings >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, month)
);

CREATE TABLE IF NOT EXISTS public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(trim(name)) > 0),
  is_essential boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, name)
);

CREATE TABLE IF NOT EXISTS public.budgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id uuid NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  planned_amount numeric(14,2) NOT NULL DEFAULT 0 CHECK (planned_amount >= 0),
  UNIQUE (plan_id, category_id)
);

CREATE TABLE IF NOT EXISTS public.transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  category_id uuid REFERENCES public.categories(id) ON DELETE SET NULL,
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  type text NOT NULL CHECK (type IN ('income', 'expense')),
  txn_date date NOT NULL,
  note text,
  source text NOT NULL DEFAULT 'manual' CHECK (source IN ('manual', 'ai')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.commitments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_id uuid NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(trim(title)) > 0),
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  due_date date NOT NULL,
  is_paid boolean NOT NULL DEFAULT false,
  paid_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS plans_user_month_idx ON public.plans(user_id, month);
CREATE INDEX IF NOT EXISTS budgets_plan_idx ON public.budgets(plan_id);
CREATE INDEX IF NOT EXISTS transactions_plan_date_idx ON public.transactions(plan_id, txn_date DESC);
CREATE INDEX IF NOT EXISTS commitments_plan_due_idx ON public.commitments(plan_id, due_date);

ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commitments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own plans" ON public.plans;
CREATE POLICY "Users can view own plans" ON public.plans FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can create own plans" ON public.plans;
CREATE POLICY "Users can create own plans" ON public.plans FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can update own plans" ON public.plans;
CREATE POLICY "Users can update own plans" ON public.plans FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can delete own plans" ON public.plans;
CREATE POLICY "Users can delete own plans" ON public.plans FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can view own categories" ON public.categories;
CREATE POLICY "Users can view own categories" ON public.categories FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can create own categories" ON public.categories;
CREATE POLICY "Users can create own categories" ON public.categories FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can update own categories" ON public.categories;
CREATE POLICY "Users can update own categories" ON public.categories FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can delete own categories" ON public.categories;
CREATE POLICY "Users can delete own categories" ON public.categories FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can view own budgets" ON public.budgets;
CREATE POLICY "Users can view own budgets" ON public.budgets FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.plans WHERE plans.id = budgets.plan_id AND plans.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can create own budgets" ON public.budgets;
CREATE POLICY "Users can create own budgets" ON public.budgets FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM public.plans WHERE plans.id = budgets.plan_id AND plans.user_id = auth.uid()) AND EXISTS (SELECT 1 FROM public.categories WHERE categories.id = budgets.category_id AND categories.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can update own budgets" ON public.budgets;
CREATE POLICY "Users can update own budgets" ON public.budgets FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM public.plans WHERE plans.id = budgets.plan_id AND plans.user_id = auth.uid())) WITH CHECK (EXISTS (SELECT 1 FROM public.plans WHERE plans.id = budgets.plan_id AND plans.user_id = auth.uid()) AND EXISTS (SELECT 1 FROM public.categories WHERE categories.id = budgets.category_id AND categories.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can delete own budgets" ON public.budgets;
CREATE POLICY "Users can delete own budgets" ON public.budgets FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM public.plans WHERE plans.id = budgets.plan_id AND plans.user_id = auth.uid()));

DROP POLICY IF EXISTS "Users can view own transactions" ON public.transactions;
CREATE POLICY "Users can view own transactions" ON public.transactions FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can create own transactions" ON public.transactions;
CREATE POLICY "Users can create own transactions" ON public.transactions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.plans WHERE plans.id = transactions.plan_id AND plans.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can update own transactions" ON public.transactions;
CREATE POLICY "Users can update own transactions" ON public.transactions FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.plans WHERE plans.id = transactions.plan_id AND plans.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can delete own transactions" ON public.transactions;
CREATE POLICY "Users can delete own transactions" ON public.transactions FOR DELETE TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can view own commitments" ON public.commitments;
CREATE POLICY "Users can view own commitments" ON public.commitments FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "Users can create own commitments" ON public.commitments;
CREATE POLICY "Users can create own commitments" ON public.commitments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.plans WHERE plans.id = commitments.plan_id AND plans.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can update own commitments" ON public.commitments;
CREATE POLICY "Users can update own commitments" ON public.commitments FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.plans WHERE plans.id = commitments.plan_id AND plans.user_id = auth.uid()));
DROP POLICY IF EXISTS "Users can delete own commitments" ON public.commitments;
CREATE POLICY "Users can delete own commitments" ON public.commitments FOR DELETE TO authenticated USING (auth.uid() = user_id);
