/*
# Link transactions to commitments

1. Modified Tables
- `transactions`: Add nullable `commitment_id` column (uuid, references commitments)
  This lets us record an expense transaction when a commitment is marked paid,
  and prevents double-counting by excluding commitment-linked expenses from
  the unpaid-commitments subtraction in the AAC formula.

2. Security
- No policy changes. The column is user-owned via the existing transaction RLS policies.
*/

ALTER TABLE transactions
  ADD COLUMN IF NOT EXISTS commitment_id uuid REFERENCES commitments(id) ON DELETE SET NULL;
