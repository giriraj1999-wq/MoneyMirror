/*
# Add amount_base column to transactions

1. Schema Changes
- `public.transactions`: add `amount_base` numeric(14,2) nullable.
  Stores the transaction amount converted to the user's base/reporting
  currency (from plans.base_currency). When the transaction currency equals
  the base currency, amount_base equals amount. When it differs, the
  frontend fetches a live conversion via the currency-convert edge function
  and stores the result here so reports and dashboards always have a
  consistent reporting-currency figure.

2. Security
- No RLS changes — the new column inherits the existing owner-scoped
  policies on the transactions table.
- No data loss: existing rows get NULL, which the frontend treats as
  "not yet converted" and falls back to the original amount.
*/

ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS amount_base numeric(14,2);
