/*
# Create financial goals

1. New Tables
- `financial_goals` stores one user's financial goals with a title, target date, target amount, current amount, and actual monthly pace.
- `financial_goals.id` is the goal identifier.
- `financial_goals.user_id` links each goal to its signed-in owner and defaults to the current authenticated user.
- `financial_goals.title` is the user-facing goal name.
- `financial_goals.target_date` is the date the user wants to reach the goal.
- `financial_goals.target_amount` is the total amount required.
- `financial_goals.current_amount` is the amount already saved.
- `financial_goals.actual_pace` is the user's current monthly contribution.

2. Security
- Row Level Security is enabled on `financial_goals`.
- Separate authenticated owner policies allow users to select, create, update, and delete only their own goals.

3. Integrity
- Monetary values use numeric(14,2) and cannot be negative.
- Goal titles must contain visible text.
- Target dates are required so progress can be measured against a deadline.
*/

CREATE TABLE IF NOT EXISTS public.financial_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(trim(title)) > 0),
  target_date date NOT NULL,
  target_amount numeric(14,2) NOT NULL CHECK (target_amount > 0),
  current_amount numeric(14,2) NOT NULL DEFAULT 0 CHECK (current_amount >= 0),
  actual_pace numeric(14,2) NOT NULL DEFAULT 0 CHECK (actual_pace >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS financial_goals_user_date_idx
  ON public.financial_goals(user_id, target_date);

ALTER TABLE public.financial_goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own financial goals" ON public.financial_goals;
CREATE POLICY "Users can view own financial goals"
  ON public.financial_goals FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create own financial goals" ON public.financial_goals;
CREATE POLICY "Users can create own financial goals"
  ON public.financial_goals FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own financial goals" ON public.financial_goals;
CREATE POLICY "Users can update own financial goals"
  ON public.financial_goals FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete own financial goals" ON public.financial_goals;
CREATE POLICY "Users can delete own financial goals"
  ON public.financial_goals FOR DELETE TO authenticated
  USING (auth.uid() = user_id);