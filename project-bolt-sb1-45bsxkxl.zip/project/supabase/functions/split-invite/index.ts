// SpendWise Split Invite Edge Function
// Supports splitting a single expense among multiple partners in one call.
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface PartnerSplit {
  partner_email: string;
  share_amount: number;
  share_currency?: string;
  share_amount_base?: number | null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing auth header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userData.user) {
      return new Response(JSON.stringify({ error: "Invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const owner = userData.user;
    const publicSupabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { auth: { persistSession: false, autoRefreshToken: false } }
    );
    const body = await req.json();
    const { transaction_id, note, app_url } = body;

    // Accept both the old single-partner shape and the new multi-partner shape.
    // Old: { partner_email, share_amount }
    // New: { partners: [{ partner_email, share_amount }, ...] }
    let partners: PartnerSplit[];
    if (Array.isArray(body.partners)) {
      partners = body.partners;
    } else if (body.partner_email && body.share_amount) {
      partners = [{ partner_email: body.partner_email, share_amount: body.share_amount }];
    } else {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate and normalize — preserve currency fields for cross-currency splits
    partners = partners
      .map((p) => ({
        partner_email: String(p.partner_email).trim().toLowerCase(),
        share_amount: Number(p.share_amount),
        share_currency: p.share_currency ?? "INR",
        share_amount_base: p.share_amount_base ?? null,
      }))
      .filter((p) => p.partner_email && p.share_amount > 0);

    if (partners.length === 0) {
      return new Response(JSON.stringify({ error: "No valid partners provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const ownerEmail = owner.email?.trim().toLowerCase();
    if (ownerEmail && partners.some((partner) => partner.partner_email === ownerEmail)) {
      return new Response(JSON.stringify({ error: "You cannot split an expense with your own account" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify the transaction belongs to the caller
    const { data: txn, error: txnErr } = await supabase
      .from("transactions")
      .select("id, amount, amount_base, type, note, txn_date, currency")
      .eq("id", transaction_id)
      .eq("user_id", owner.id)
      .single();

    if (txnErr || !txn) {
      return new Response(JSON.stringify({ error: "Transaction not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (txn.type !== "expense") {
      return new Response(JSON.stringify({ error: "Only expenses can be split" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const totalShares = partners.reduce((s, p) => s + (p.share_amount_base ?? p.share_amount), 0);
    const originalAmountBase = txn.amount_base ?? txn.amount;
    if (totalShares >= originalAmountBase) {
      return new Response(
        JSON.stringify({
          error: "The owner must retain part of the expense. Enter a smaller share amount.",
        }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Use the app_url from the request body (sent by the frontend as
    // window.location.origin) so invite/recovery links always point to the
    // real deployed app — never localhost. Fall back to Origin/Referer
    // headers only if the body didn't include it.
    const bodyUrl = typeof app_url === "string" ? app_url.trim() : null;
    const headerOrigin =
      req.headers.get("Origin") ||
      (() => {
        const referer = req.headers.get("Referer");
        if (!referer) return null;
        try {
          const url = new URL(referer);
          return `${url.protocol}//${url.host}`;
        } catch {
          return null;
        }
      })();
    const candidateRedirect = bodyUrl || headerOrigin;
    const redirectTo =
      candidateRedirect && !/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/i.test(candidateRedirect)
        ? `${candidateRedirect}/`
        : undefined;

    // Batch-fetch all users once to avoid N round-trips.
    const { data: usersList } = await supabase.auth.admin.listUsers();

    let createdSharesBase = 0;
    const results: Array<{
      partner_email: string;
      share_amount: number;
      email_sent: boolean;
      email_error: string | null;
      partner_exists: boolean;
      share_id?: string;
      error?: string;
    }> = [];

    for (const partner of partners) {
      const partnerEmail = partner.partner_email;
      const shareAmount = partner.share_amount;

      const existingUser = usersList?.users?.find(
        (u) => u.email?.toLowerCase() === partnerEmail
      );
      const partnerUserId = existingUser?.id ?? null;

      const { data: existingShare } = await supabase
        .from("transaction_shares")
        .select("id")
        .eq("transaction_id", transaction_id)
        .eq("partner_email", partnerEmail)
        .maybeSingle();

      if (existingShare) {
        results.push({
          partner_email: partnerEmail,
          share_amount: shareAmount,
          email_sent: false,
          email_error: null,
          partner_exists: !!existingUser,
          error: "A pending or active share already exists for this partner on this transaction",
        });
        continue;
      }

      const inviteData = {
        invite_type: "split_share",
        owner_email: owner.email,
        share_amount: shareAmount,
        transaction_note: note ?? txn.note ?? "a shared expense",
      };

      let emailSent = false;
      let emailError: string | null = null;

      try {
        if (!existingUser || !existingUser.email_confirmed_at) {
          const inviteResult = await supabase.auth.admin.inviteUserByEmail(
            partnerEmail,
            { ...(redirectTo ? { redirectTo } : {}), data: inviteData }
          );
          emailSent = !inviteResult.error;
          emailError = inviteResult.error?.message ?? null;
        } else {
          const recoveryResult = await publicSupabase.auth.resetPasswordForEmail(
            partnerEmail,
            redirectTo ? { redirectTo } : undefined
          );
          emailSent = !recoveryResult.error;
          emailError = recoveryResult.error?.message ?? null;
        }
      } catch (err) {
        emailError = err instanceof Error ? err.message : "Unknown error";
      }

      const { data: share, error: shareErr } = await supabase
        .from("transaction_shares")
        .insert({
          transaction_id,
          owner_user_id: owner.id,
          partner_email: partnerEmail,
          partner_user_id: partnerUserId,
          share_amount: shareAmount,
          share_currency: partner.share_currency ?? "INR",
          share_amount_base: partner.share_amount_base ?? null,
          status: "pending",
        })
        .select()
        .single();

      if (!shareErr && share) {
        createdSharesBase += partner.share_amount_base ?? shareAmount;
      }

      results.push({
        partner_email: partnerEmail,
        share_amount: shareAmount,
        email_sent: emailSent,
        email_error: emailError,
        partner_exists: !!existingUser,
        share_id: share?.id,
        error: shareErr?.message ?? undefined,
      });
    }

    const anyError = results.some((r) => r.error);
    if (createdSharesBase > 0) {
      const remainingBase = originalAmountBase - createdSharesBase;
      const remainingAmount = txn.amount_base != null
        ? txn.amount * (remainingBase / originalAmountBase)
        : txn.amount - createdSharesBase;
      const { error: updateTxnErr } = await supabase
        .from("transactions")
        .update({ amount: Math.max(0.01, remainingAmount), amount_base: Math.max(0.01, remainingBase) })
        .eq("id", transaction_id)
        .eq("user_id", owner.id);
      if (updateTxnErr) throw updateTxnErr;
    }

    const allSent = results.every((r) => r.email_sent);

    return new Response(
      JSON.stringify({
        success: !anyError,
        results,
        email_sent: allSent,
        summary: {
          total: results.length,
          sent: results.filter((r) => r.email_sent).length,
          failed: results.filter((r) => !r.email_sent).length,
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
