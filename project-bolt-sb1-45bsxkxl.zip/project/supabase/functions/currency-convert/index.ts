const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const RATES_TO_USD: Record<string, number> = {
  USD: 1,
  INR: 0.012,
  EUR: 1.08,
  GBP: 1.27,
  AED: 0.27,
  SGD: 0.74,
  AUD: 0.66,
  CAD: 0.73,
  JPY: 0.0067,
  CHF: 1.12,
};

function staticConvert(amount: number, from: string, to: string): { amount: number; rate: number } | null {
  const fromRate = RATES_TO_USD[from];
  const toRate = RATES_TO_USD[to];
  if (!fromRate || !toRate) return null;
  const rate = fromRate / toRate;
  return { amount: Math.round(amount * rate * 100) / 100, rate: Math.round(rate * 10000) / 10000 };
}

async function geminiConvert(amount: number, from: string, to: string, apiKey: string): Promise<{ amount: number; rate: number }> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  const prompt = `Convert ${amount} ${from} to ${to}. Return only a JSON object with fields: "amount" (number, the converted amount rounded to 2 decimals), "rate" (number, the exchange rate used, from→to). Use current approximate market rates. No explanation.`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0, maxOutputTokens: 100 },
      }),
      signal: controller.signal,
    }
  );

  clearTimeout(timeout);

  if (!response.ok) throw new Error("Gemini request failed");

  const data = await response.json();
  const content = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!content) throw new Error("No content from Gemini");

  const match = content.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("No JSON in response");

  const parsed = JSON.parse(match[0]);
  return { amount: Number(parsed.amount), rate: Number(parsed.rate) };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { amount, from, to } = await req.json();
    if (!amount || !from || !to) {
      return new Response(
        JSON.stringify({ error: "Missing amount, from, or to" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (from === to) {
      return new Response(
        JSON.stringify({ amount: Number(amount), rate: 1, from, to }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("GEMINI_API_KEY");

    if (!apiKey) {
      const fallback = staticConvert(Number(amount), from, to);
      if (!fallback) {
        return new Response(
          JSON.stringify({ error: "Unsupported currency pair" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      return new Response(
        JSON.stringify({ amount: fallback.amount, rate: fallback.rate, from, to, source: "static" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    try {
      const result = await geminiConvert(Number(amount), from, to, apiKey);
      return new Response(
        JSON.stringify({ ...result, from, to, source: "live" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch {
      const fallback = staticConvert(Number(amount), from, to);
      if (!fallback) {
        return new Response(
          JSON.stringify({ error: "Conversion unavailable" }),
          { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      return new Response(
        JSON.stringify({ amount: fallback.amount, rate: fallback.rate, from, to, source: "static" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
