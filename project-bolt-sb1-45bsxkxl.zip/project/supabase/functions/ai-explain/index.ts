const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function fallbackExplain(input: {
  currentBalance: number;
  proposedExpense: number;
  beforeAAC: number;
  afterAAC: number;
  verdict: string;
  shortfall: number;
  exposedAmount: number;
}): string {
  const { currentBalance, proposedExpense, beforeAAC, afterAAC, verdict, shortfall, exposedAmount } = input;
  const parts: string[] = [];

  parts.push(`Spending ${proposedExpense} would bring your available balance from ${beforeAAC} to ${afterAAC}.`);

  if (verdict === "blocked" || shortfall > 0) {
    parts.push(`This creates a shortfall of ${shortfall}, meaning you don't have enough to cover this expense after your commitments.`);
    if (exposedAmount > 0) {
      parts.push(`Your protected savings would be exposed by ${exposedAmount} — that money is no longer safely set aside.`);
    }
  } else if (verdict === "tight") {
    parts.push("You can afford this, but it leaves very little room for unexpected expenses.");
  } else {
    parts.push("You can comfortably afford this expense without affecting your savings or commitments.");
  }

  return parts.join(" ");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const input = await req.json();

    const {
      currentBalance,
      unpaidCommitments,
      remainingEssential,
      protectedSavings,
      proposedExpense,
      beforeAAC,
      afterAAC,
      verdict,
      shortfall,
      exposedAmount,
    } = input;

    const apiKey = Deno.env.get("GEMINI_API_KEY");

    if (!apiKey) {
      return new Response(
        JSON.stringify({ explanation: fallbackExplain({ currentBalance, proposedExpense, beforeAAC, afterAAC, verdict, shortfall, exposedAmount }) }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const numbersContext = `Current balance: ${currentBalance}
Unpaid commitments: ${unpaidCommitments}
Remaining essential budget: ${remainingEssential}
Protected savings: ${protectedSavings}
Proposed expense: ${proposedExpense}
Before AAC: ${beforeAAC}
After AAC: ${afterAAC}
Verdict: ${verdict}
Shortfall: ${shortfall}
Exposed amount: ${exposedAmount}`;

    const prompt = `You are explaining a deterministic personal-finance calculation.
You are given precomputed numbers. Do NOT recalculate or change any numbers.
Explain in 2-3 plain sentences what changes, whether a shortfall appears, and which protected amount would become exposed.
Do not recommend borrowing, investing, or any financial product.

${numbersContext}`;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.3, maxOutputTokens: 150 },
          }),
          signal: controller.signal,
        }
      );

      clearTimeout(timeout);

      if (!response.ok) throw new Error("Gemini request failed");

      const data = await response.json();
      const content = data.candidates?.[0]?.content?.parts?.[0]?.text;

      if (!content) throw new Error("No content from Gemini");

      return new Response(
        JSON.stringify({ explanation: content.trim() }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch {
      return new Response(
        JSON.stringify({ explanation: fallbackExplain({ currentBalance, proposedExpense, beforeAAC, afterAAC, verdict, shortfall, exposedAmount }) }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch {
    return new Response(
      JSON.stringify({ explanation: null }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
