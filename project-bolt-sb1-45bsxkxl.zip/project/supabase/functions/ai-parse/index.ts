const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ParseDraft {
  amount: number | null;
  currency: string;
  merchant_or_description: string | null;
  type: "income" | "expense";
  suggested_category: string | null;
  confidence: number;
}

function regexParse(text: string): ParseDraft {
  const lower = text.toLowerCase();

  const amountMatch =
    text.match(/(?:rs\.?\s*|inr\s*|₹\s*|\$\s*|€\s*|usd\s*|eur\s*|gbp\s*)\s*([\d,]+\.?\d*)/i) ||
    text.match(/([\d,]+\.?\d*)\s*(?:rs\.?|inr|₹|\$|€|usd|eur|gbp)/i) ||
    text.match(/(?:amount|amt|paid|debited|credited|received|sent)\s*[:\-]?\s*([\d,]+\.?\d*)/i);

  let amount: number | null = null;
  if (amountMatch) {
    amount = parseFloat(amountMatch[1].replace(/,/g, ""));
    if (isNaN(amount) || amount <= 0) amount = null;
  }

  let currency = "INR";
  if (/\$|usd/i.test(text)) currency = "USD";
  else if (/€|eur/i.test(text)) currency = "EUR";
  else if (/£|gbp/i.test(text)) currency = "GBP";

  let type: "income" | "expense" = "expense";
  if (/(credited|received|refund|salary|deposited|cashback|rewards?|interest)/i.test(lower)) {
    type = "income";
  }

  let merchant: string | null = null;
  const vpaMatch = text.match(/([a-zA-Z0-9._-]+@[a-zA-Z]{3,})/);
  if (vpaMatch) {
    merchant = vpaMatch[1];
  } else {
    const toFromMatch =
      text.match(/(?:to|at)\s+([A-Z][A-Za-z0-9\s&'.-]{2,30})/i) ||
      text.match(/from\s+([A-Z][A-Za-z0-9\s&'.-]{2,30})/i);
    if (toFromMatch) merchant = toFromMatch[1].trim();
  }

  let suggestedCategory: string | null = null;
  const categoryMap: Record<string, string> = {
    grocery: "Groceries", groceries: "Groceries", supermarket: "Groceries", bigbasket: "Groceries", blinkit: "Groceries", zepto: "Groceries",
    rent: "Rent", landlord: "Rent", housing: "Rent",
    electric: "Utilities", electricity: "Utilities", water: "Utilities", gas: "Utilities", broadband: "Utilities", wifi: "Utilities", internet: "Utilities", mobile: "Utilities", recharge: "Utilities", bill: "Utilities",
    uber: "Transport", ola: "Transport", rapido: "Transport", fuel: "Transport", petrol: "Transport", diesel: "Transport", metro: "Transport", bus: "Transport", train: "Transport", irctc: "Transport",
    restaurant: "Dining Out", swiggy: "Dining Out", zomato: "Dining Out", domino: "Dining Out", kfc: "Dining Out", mcdonald: "Dining Out", pizza: "Dining Out", cafe: "Dining Out", coffee: "Dining Out", dining: "Dining Out",
    netflix: "Entertainment", prime: "Entertainment", hotstar: "Entertainment", spotify: "Entertainment", movie: "Entertainment", pvr: "Entertainment", inox: "Entertainment", steam: "Entertainment", game: "Entertainment",
    salary: "Salary", payroll: "Salary",
    stock: "Stock Market", stocks: "Stock Market", zerodha: "Stock Market", groww: "Stock Market", trading: "Stock Market",
    interest: "Interest on Deposits", fd: "Interest on Deposits", savings: "Interest on Deposits",
    bonus: "Employee Bonus",
    crypto: "Crypto", wazirx: "Crypto", coinbase: "Crypto",
    freelance: "Freelancing", consulting: "Consultancy", consultancy: "Consultancy",
    rental: "Rental Income", rent_income: "Rental Income",
    dividend: "Dividends",
    gift: "Gift",
  };

  for (const keyword of Object.keys(categoryMap)) {
    if (lower.includes(keyword)) {
      suggestedCategory = categoryMap[keyword];
      break;
    }
  }

  const confidence = amount !== null ? 0.6 : 0;

  return {
    amount,
    currency,
    merchant_or_description: merchant,
    type,
    suggested_category: suggestedCategory,
    confidence,
  };
}

async function geminiParse(text: string, apiKey: string): Promise<ParseDraft> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  const prompt = `You extract structured transaction data from user-provided payment text (bank SMS, UPI messages, receipts).
Return JSON only with these fields:
- amount: number (the transaction amount, null if not found)
- currency: string (default "INR")
- merchant_or_description: string (the merchant or description, null if not found)
- type: string ("income" or "expense", default "expense")
- suggested_category: string (for expenses: one of Groceries, Rent, Utilities, Transport, Dining Out, Entertainment; for income: one of Salary, Stock Market, Interest on Deposits, Employee Bonus, Crypto, Freelancing, Consultancy, Rental Income, Dividends, Gift; or null)
- confidence: number (0-1)

Do not invent missing values; use null.
Do not make financial recommendations.
The user will confirm before saving.

Text: "${text.replace(/"/g, '\\"')}"`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0, maxOutputTokens: 200 },
      }),
      signal: controller.signal,
    }
  );

  clearTimeout(timeout);

  if (!response.ok) throw new Error("Gemini request failed");

  const data = await response.json();
  const content = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!content) throw new Error("No content from Gemini");

  const match = content.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("No JSON in response");

  const parsed = JSON.parse(match[0]);
  return {
    amount: parsed.amount ?? null,
    currency: parsed.currency ?? "INR",
    merchant_or_description: parsed.merchant_or_description ?? null,
    type: parsed.type === "income" ? "income" : "expense",
    suggested_category: parsed.suggested_category ?? null,
    confidence: parsed.confidence ?? 0.6,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { text } = await req.json();

    if (!text || typeof text !== "string") {
      return new Response(
        JSON.stringify({ error: "Missing 'text' field" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const apiKey = Deno.env.get("GEMINI_API_KEY");

    if (!apiKey) {
      return new Response(
        JSON.stringify(regexParse(text)),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    try {
      const draft = await geminiParse(text, apiKey);
      return new Response(
        JSON.stringify(draft),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch {
      return new Response(
        JSON.stringify(regexParse(text)),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  } catch (_err) {
    return new Response(
      JSON.stringify({
        amount: null,
        currency: "INR",
        merchant_or_description: null,
        type: "expense",
        suggested_category: null,
        confidence: 0,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
